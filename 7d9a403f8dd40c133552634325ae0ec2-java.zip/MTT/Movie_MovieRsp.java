package MTT;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class Movie_MovieRsp extends JceStruct {
    static ArrayList<Movie_Movie> cache_vecMovies = new ArrayList<>();
    public String sLink = "";
    public ArrayList<Movie_Movie> vecMovies = null;

    public Movie_MovieRsp() {
    }

    public Movie_MovieRsp(ArrayList<Movie_Movie> vecMovies2, String sLink2) {
        this.vecMovies = vecMovies2;
        this.sLink = sLink2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vecMovies != null) {
            _os.write((Collection) this.vecMovies, 0);
        }
        if (this.sLink != null) {
            _os.write(this.sLink, 1);
        }
    }

    static {
        cache_vecMovies.add(new Movie_Movie());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecMovies = (ArrayList) _is.read((Object) cache_vecMovies, 0, false);
        this.sLink = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Movie_MovieRsp temp = (Movie_MovieRsp) a.parseObject(text, Movie_MovieRsp.class);
        this.vecMovies = temp.vecMovies;
        this.sLink = temp.sLink;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
