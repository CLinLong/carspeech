package MTT;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class Movie_CinemaRsp extends JceStruct {
    static ArrayList<Movie_Cinema> cache_vecCinemas = new ArrayList<>();
    public String sLink = "";
    public ArrayList<Movie_Cinema> vecCinemas = null;

    public Movie_CinemaRsp() {
    }

    public Movie_CinemaRsp(ArrayList<Movie_Cinema> vecCinemas2, String sLink2) {
        this.vecCinemas = vecCinemas2;
        this.sLink = sLink2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vecCinemas != null) {
            _os.write((Collection) this.vecCinemas, 0);
        }
        if (this.sLink != null) {
            _os.write(this.sLink, 1);
        }
    }

    static {
        cache_vecCinemas.add(new Movie_Cinema());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecCinemas = (ArrayList) _is.read((Object) cache_vecCinemas, 0, false);
        this.sLink = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Movie_CinemaRsp temp = (Movie_CinemaRsp) a.parseObject(text, Movie_CinemaRsp.class);
        this.vecCinemas = temp.vecCinemas;
        this.sLink = temp.sLink;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
