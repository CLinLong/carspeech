package MTT;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Movie_Cinema extends JceStruct {
    public double dLatitude = 0.0d;
    public double dLongitude = 0.0d;
    public int iID = 0;
    public String sAddr = "";
    public String sDistance = "";
    public String sLink = "";
    public String sName = "";
    public String sPrice = "";

    public Movie_Cinema() {
    }

    public Movie_Cinema(int iID2, String sName2, String sPrice2, String sDistance2, String sLink2, String sAddr2, double dLongitude2, double dLatitude2) {
        this.iID = iID2;
        this.sName = sName2;
        this.sPrice = sPrice2;
        this.sDistance = sDistance2;
        this.sLink = sLink2;
        this.sAddr = sAddr2;
        this.dLongitude = dLongitude2;
        this.dLatitude = dLatitude2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iID, 0);
        if (this.sName != null) {
            _os.write(this.sName, 1);
        }
        if (this.sPrice != null) {
            _os.write(this.sPrice, 2);
        }
        if (this.sDistance != null) {
            _os.write(this.sDistance, 3);
        }
        if (this.sLink != null) {
            _os.write(this.sLink, 4);
        }
        if (this.sAddr != null) {
            _os.write(this.sAddr, 5);
        }
        _os.write(this.dLongitude, 6);
        _os.write(this.dLatitude, 7);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iID = _is.read(this.iID, 0, false);
        this.sName = _is.readString(1, false);
        this.sPrice = _is.readString(2, false);
        this.sDistance = _is.readString(3, false);
        this.sLink = _is.readString(4, false);
        this.sAddr = _is.readString(5, false);
        this.dLongitude = _is.read(this.dLongitude, 6, false);
        this.dLatitude = _is.read(this.dLatitude, 7, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Movie_Cinema temp = (Movie_Cinema) a.parseObject(text, Movie_Cinema.class);
        this.iID = temp.iID;
        this.sName = temp.sName;
        this.sPrice = temp.sPrice;
        this.sDistance = temp.sDistance;
        this.sLink = temp.sLink;
        this.sAddr = temp.sAddr;
        this.dLongitude = temp.dLongitude;
        this.dLatitude = temp.dLatitude;
    }
}
