package MTT;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Movie_CinemaReq extends JceStruct {
    public double dLatitude = 0.0d;
    public double dLongitude = 0.0d;
    public String sAddr = "";
    public String sGuid = "";
    public String sName = "";
    public String sPhone = "";
    public String sQua2 = "";
    public String sUid = "";

    public Movie_CinemaReq() {
    }

    public Movie_CinemaReq(String sGuid2, String sQua22, String sUid2, String sPhone2, double dLongitude2, double dLatitude2, String sName2, String sAddr2) {
        this.sGuid = sGuid2;
        this.sQua2 = sQua22;
        this.sUid = sUid2;
        this.sPhone = sPhone2;
        this.dLongitude = dLongitude2;
        this.dLatitude = dLatitude2;
        this.sName = sName2;
        this.sAddr = sAddr2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sGuid != null) {
            _os.write(this.sGuid, 0);
        }
        if (this.sQua2 != null) {
            _os.write(this.sQua2, 1);
        }
        if (this.sUid != null) {
            _os.write(this.sUid, 2);
        }
        if (this.sPhone != null) {
            _os.write(this.sPhone, 3);
        }
        _os.write(this.dLongitude, 4);
        _os.write(this.dLatitude, 5);
        if (this.sName != null) {
            _os.write(this.sName, 6);
        }
        if (this.sAddr != null) {
            _os.write(this.sAddr, 7);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, false);
        this.sQua2 = _is.readString(1, false);
        this.sUid = _is.readString(2, false);
        this.sPhone = _is.readString(3, false);
        this.dLongitude = _is.read(this.dLongitude, 4, false);
        this.dLatitude = _is.read(this.dLatitude, 5, false);
        this.sName = _is.readString(6, false);
        this.sAddr = _is.readString(7, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Movie_CinemaReq temp = (Movie_CinemaReq) a.parseObject(text, Movie_CinemaReq.class);
        this.sGuid = temp.sGuid;
        this.sQua2 = temp.sQua2;
        this.sUid = temp.sUid;
        this.sPhone = temp.sPhone;
        this.dLongitude = temp.dLongitude;
        this.dLatitude = temp.dLatitude;
        this.sName = temp.sName;
        this.sAddr = temp.sAddr;
    }
}
