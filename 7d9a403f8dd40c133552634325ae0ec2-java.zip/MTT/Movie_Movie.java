package MTT;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Movie_Movie extends JceStruct {
    public int iBuyFlag = 0;
    public int iID = 0;
    public int iScoreCount = 0;
    public int iSeenCount = 0;
    public int iWantCount = 0;
    public String sActor = "";
    public String sBuyLink = "";
    public String sDetail = "";
    public String sDirector = "";
    public String sLink = "";
    public String sLongs = "";
    public String sName = "";
    public String sPostUrl = "";
    public String sRemark = "";
    public String sScore = "";
    public String sTime = "";
    public String sType = "";

    public Movie_Movie() {
    }

    public Movie_Movie(int iID2, String sName2, String sScore2, String sDirector2, String sActor2, String sPostUrl2, String sLink2, String sBuyLink2, String sTime2, String sDetail2, String sType2, String sLongs2, int iBuyFlag2, String sRemark2, int iWantCount2, int iSeenCount2, int iScoreCount2) {
        this.iID = iID2;
        this.sName = sName2;
        this.sScore = sScore2;
        this.sDirector = sDirector2;
        this.sActor = sActor2;
        this.sPostUrl = sPostUrl2;
        this.sLink = sLink2;
        this.sBuyLink = sBuyLink2;
        this.sTime = sTime2;
        this.sDetail = sDetail2;
        this.sType = sType2;
        this.sLongs = sLongs2;
        this.iBuyFlag = iBuyFlag2;
        this.sRemark = sRemark2;
        this.iWantCount = iWantCount2;
        this.iSeenCount = iSeenCount2;
        this.iScoreCount = iScoreCount2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iID, 0);
        if (this.sName != null) {
            _os.write(this.sName, 1);
        }
        if (this.sScore != null) {
            _os.write(this.sScore, 2);
        }
        if (this.sDirector != null) {
            _os.write(this.sDirector, 3);
        }
        if (this.sActor != null) {
            _os.write(this.sActor, 4);
        }
        if (this.sPostUrl != null) {
            _os.write(this.sPostUrl, 5);
        }
        if (this.sLink != null) {
            _os.write(this.sLink, 6);
        }
        if (this.sBuyLink != null) {
            _os.write(this.sBuyLink, 7);
        }
        if (this.sTime != null) {
            _os.write(this.sTime, 8);
        }
        if (this.sDetail != null) {
            _os.write(this.sDetail, 9);
        }
        if (this.sType != null) {
            _os.write(this.sType, 10);
        }
        if (this.sLongs != null) {
            _os.write(this.sLongs, 11);
        }
        _os.write(this.iBuyFlag, 12);
        if (this.sRemark != null) {
            _os.write(this.sRemark, 13);
        }
        _os.write(this.iWantCount, 14);
        _os.write(this.iSeenCount, 15);
        _os.write(this.iScoreCount, 16);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iID = _is.read(this.iID, 0, false);
        this.sName = _is.readString(1, false);
        this.sScore = _is.readString(2, false);
        this.sDirector = _is.readString(3, false);
        this.sActor = _is.readString(4, false);
        this.sPostUrl = _is.readString(5, false);
        this.sLink = _is.readString(6, false);
        this.sBuyLink = _is.readString(7, false);
        this.sTime = _is.readString(8, false);
        this.sDetail = _is.readString(9, false);
        this.sType = _is.readString(10, false);
        this.sLongs = _is.readString(11, false);
        this.iBuyFlag = _is.read(this.iBuyFlag, 12, false);
        this.sRemark = _is.readString(13, false);
        this.iWantCount = _is.read(this.iWantCount, 14, false);
        this.iSeenCount = _is.read(this.iSeenCount, 15, false);
        this.iScoreCount = _is.read(this.iScoreCount, 16, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Movie_Movie temp = (Movie_Movie) a.parseObject(text, Movie_Movie.class);
        this.iID = temp.iID;
        this.sName = temp.sName;
        this.sScore = temp.sScore;
        this.sDirector = temp.sDirector;
        this.sActor = temp.sActor;
        this.sPostUrl = temp.sPostUrl;
        this.sLink = temp.sLink;
        this.sBuyLink = temp.sBuyLink;
        this.sTime = temp.sTime;
        this.sDetail = temp.sDetail;
        this.sType = temp.sType;
        this.sLongs = temp.sLongs;
        this.iBuyFlag = temp.iBuyFlag;
        this.sRemark = temp.sRemark;
        this.iWantCount = temp.iWantCount;
        this.iSeenCount = temp.iSeenCount;
        this.iScoreCount = temp.iScoreCount;
    }
}
