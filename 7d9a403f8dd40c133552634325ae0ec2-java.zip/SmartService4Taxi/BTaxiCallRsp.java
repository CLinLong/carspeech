package SmartService4Taxi;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class BTaxiCallRsp extends JceStruct implements Cloneable {
    static final /* synthetic */ boolean $assertionsDisabled;
    static ErrorInfo cache_errInfo = new ErrorInfo();
    public ErrorInfo errInfo = null;
    public float estimatePrice = 0.0f;
    public String orderId = "";

    static {
        boolean z;
        if (!BTaxiCallRsp.class.desiredAssertionStatus()) {
            z = true;
        } else {
            z = false;
        }
        $assertionsDisabled = z;
    }

    public String className() {
        return "SmartService4Taxi.BTaxiCallRsp";
    }

    public String fullClassName() {
        return "SmartService4Taxi.BTaxiCallRsp";
    }

    public ErrorInfo getErrInfo() {
        return this.errInfo;
    }

    public void setErrInfo(ErrorInfo errInfo2) {
        this.errInfo = errInfo2;
    }

    public String getOrderId() {
        return this.orderId;
    }

    public void setOrderId(String orderId2) {
        this.orderId = orderId2;
    }

    public float getEstimatePrice() {
        return this.estimatePrice;
    }

    public void setEstimatePrice(float estimatePrice2) {
        this.estimatePrice = estimatePrice2;
    }

    public BTaxiCallRsp() {
    }

    public BTaxiCallRsp(ErrorInfo errInfo2, String orderId2, float estimatePrice2) {
        this.errInfo = errInfo2;
        this.orderId = orderId2;
        this.estimatePrice = estimatePrice2;
    }

    public int hashCode() {
        try {
            throw new Exception("Need define key first!");
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override // java.lang.Object
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            if ($assertionsDisabled) {
                return null;
            }
            throw new AssertionError();
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.errInfo, 1);
        _os.write(this.orderId, 2);
        _os.write(this.estimatePrice, 3);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.errInfo = (ErrorInfo) _is.read((JceStruct) cache_errInfo, 1, true);
        this.orderId = _is.readString(2, true);
        this.estimatePrice = _is.read(this.estimatePrice, 3, true);
    }
}
