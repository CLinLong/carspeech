package SmartService4Taxi;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ErrorInfo extends JceStruct {
    public String errorMsg = "";
    public int errorNo = -1;

    public ErrorInfo() {
    }

    public ErrorInfo(int errorNo2, String errorMsg2) {
        this.errorNo = errorNo2;
        this.errorMsg = errorMsg2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.errorNo, 1);
        _os.write(this.errorMsg, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.errorNo = _is.read(this.errorNo, 1, true);
        this.errorMsg = _is.readString(2, true);
    }
}
