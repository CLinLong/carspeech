package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Boundary extends JceStruct {
    static Location cache_TopRight = new Location();
    static Location cache_bottomLeft = new Location();
    static Location cache_location = new Location();
    public Location TopRight = null;
    public boolean autoExtend = true;
    public Location bottomLeft = null;
    public String keyword = "";
    public Location location = null;
    public float radius = 0.0f;
    public String region = "";
    public int type = 1;

    public Boundary() {
    }

    public Boundary(int type2, String region2, boolean autoExtend2, Location location2, float radius2, Location bottomLeft2, Location TopRight2, String keyword2) {
        this.type = type2;
        this.region = region2;
        this.autoExtend = autoExtend2;
        this.location = location2;
        this.radius = radius2;
        this.bottomLeft = bottomLeft2;
        this.TopRight = TopRight2;
        this.keyword = keyword2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.type, 1);
        if (this.region != null) {
            _os.write(this.region, 2);
        }
        _os.write(this.autoExtend, 3);
        if (this.location != null) {
            _os.write((JceStruct) this.location, 4);
        }
        _os.write(this.radius, 5);
        if (this.bottomLeft != null) {
            _os.write((JceStruct) this.bottomLeft, 6);
        }
        if (this.TopRight != null) {
            _os.write((JceStruct) this.TopRight, 7);
        }
        _os.write(this.keyword, 8);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.type = _is.read(this.type, 1, true);
        this.region = _is.readString(2, false);
        this.autoExtend = _is.read(this.autoExtend, 3, false);
        this.location = (Location) _is.read((JceStruct) cache_location, 4, false);
        this.radius = _is.read(this.radius, 5, false);
        this.bottomLeft = (Location) _is.read((JceStruct) cache_bottomLeft, 6, false);
        this.TopRight = (Location) _is.read((JceStruct) cache_TopRight, 7, false);
        this.keyword = _is.readString(8, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Boundary temp = (Boundary) a.parseObject(text, Boundary.class);
        this.type = temp.type;
        this.region = temp.region;
        this.autoExtend = temp.autoExtend;
        this.location = temp.location;
        this.radius = temp.radius;
        this.bottomLeft = temp.bottomLeft;
        this.TopRight = temp.TopRight;
        this.keyword = temp.keyword;
    }
}
