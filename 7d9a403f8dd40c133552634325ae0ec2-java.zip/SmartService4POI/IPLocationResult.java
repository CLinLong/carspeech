package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class IPLocationResult extends JceStruct {
    static Location cache_location = new Location();
    static int cache_status = 0;
    static StructuralAddr cache_structuralAddr = new StructuralAddr();
    public Location location = null;
    public int status = -1;
    public StructuralAddr structuralAddr = null;

    public IPLocationResult() {
    }

    public IPLocationResult(int status2, Location location2, StructuralAddr structuralAddr2) {
        this.status = status2;
        this.location = location2;
        this.structuralAddr = structuralAddr2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.status, 1);
        _os.write((JceStruct) this.location, 2);
        _os.write((JceStruct) this.structuralAddr, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.status = _is.read(this.status, 1, true);
        this.location = (Location) _is.read((JceStruct) cache_location, 2, true);
        this.structuralAddr = (StructuralAddr) _is.read((JceStruct) cache_structuralAddr, 4, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        IPLocationResult temp = (IPLocationResult) a.parseObject(text, IPLocationResult.class);
        this.status = temp.status;
        this.location = temp.location;
        this.structuralAddr = temp.structuralAddr;
    }
}
