package SmartService4POI;

import java.io.Serializable;

public final class RESULT_STATUS implements Serializable {
    public static final int _KEY_ERROR = 311;
    public static final int _OK = 0;
    public static final int _OTHERS = -1;
    public static final int _PARAM_ERROR = 310;
    public static final int _PROTECTED = 306;
    public static final int _UNAUTHORIZED = 110;
}
