package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class LocationResult extends JceStruct {
    static ArrayList<LocationObj> cache_locationObjs = new ArrayList<>();
    static int cache_status = 0;
    public ArrayList<LocationObj> locationObjs = null;
    public int status = -1;

    public LocationResult() {
    }

    public LocationResult(int status2, ArrayList<LocationObj> locationObjs2) {
        this.status = status2;
        this.locationObjs = locationObjs2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.status, 1);
        _os.write((Collection) this.locationObjs, 2);
    }

    static {
        cache_locationObjs.add(new LocationObj());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.status = _is.read(this.status, 1, true);
        this.locationObjs = (ArrayList) _is.read((Object) cache_locationObjs, 2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        LocationResult temp = (LocationResult) a.parseObject(text, LocationResult.class);
        this.status = temp.status;
        this.locationObjs = temp.locationObjs;
    }
}
