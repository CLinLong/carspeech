package SmartService4POI;

import java.io.Serializable;

public final class EPathPlanMode implements Serializable {
    public static final int _E_PATHPLAN_DRIVING = 0;
    public static final int _E_PATHPLAN_WALKING = 1;
}
