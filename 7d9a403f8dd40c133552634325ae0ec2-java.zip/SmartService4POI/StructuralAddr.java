package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class StructuralAddr extends JceStruct {
    public String adcode = "";
    public String city = "";
    public String cityAlias = "";
    public String distict = "";
    public String nation = "";
    public String province = "";
    public String street = "";
    public String street_number = "";

    public StructuralAddr() {
    }

    public StructuralAddr(String nation2, String province2, String city2, String distict2, String street2, String street_number2, String adcode2, String cityAlias2) {
        this.nation = nation2;
        this.province = province2;
        this.city = city2;
        this.distict = distict2;
        this.street = street2;
        this.street_number = street_number2;
        this.adcode = adcode2;
        this.cityAlias = cityAlias2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.nation, 1);
        _os.write(this.province, 2);
        _os.write(this.city, 3);
        if (this.distict != null) {
            _os.write(this.distict, 4);
        }
        if (this.street != null) {
            _os.write(this.street, 5);
        }
        if (this.street_number != null) {
            _os.write(this.street_number, 6);
        }
        if (this.adcode != null) {
            _os.write(this.adcode, 7);
        }
        if (this.cityAlias != null) {
            _os.write(this.cityAlias, 8);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.nation = _is.readString(1, true);
        this.province = _is.readString(2, true);
        this.city = _is.readString(3, true);
        this.distict = _is.readString(4, false);
        this.street = _is.readString(5, false);
        this.street_number = _is.readString(6, false);
        this.adcode = _is.readString(7, false);
        this.cityAlias = _is.readString(8, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        StructuralAddr temp = (StructuralAddr) a.parseObject(text, StructuralAddr.class);
        this.nation = temp.nation;
        this.province = temp.province;
        this.city = temp.city;
        this.distict = temp.distict;
        this.street = temp.street;
        this.street_number = temp.street_number;
        this.adcode = temp.adcode;
        this.cityAlias = temp.cityAlias;
    }
}
