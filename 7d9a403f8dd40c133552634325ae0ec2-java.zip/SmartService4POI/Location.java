package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Location extends JceStruct {
    public int coordType = 1;
    public float lat = 0.0f;
    public float lng = 0.0f;

    public Location() {
    }

    public Location(float lat2, float lng2, int coordType2) {
        this.lat = lat2;
        this.lng = lng2;
        this.coordType = coordType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.lat, 1);
        _os.write(this.lng, 2);
        _os.write(this.coordType, 3);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.lat = _is.read(this.lat, 1, true);
        this.lng = _is.read(this.lng, 2, true);
        this.coordType = _is.read(this.coordType, 3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Location temp = (Location) a.parseObject(text, Location.class);
        this.lat = temp.lat;
        this.lng = temp.lng;
        this.coordType = temp.coordType;
    }
}
