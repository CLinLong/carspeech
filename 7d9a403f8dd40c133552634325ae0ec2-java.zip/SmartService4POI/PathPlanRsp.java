package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class PathPlanRsp extends JceStruct {
    static ArrayList<PathPlaning> cache_vPathPlaningList = new ArrayList<>();
    public ArrayList<PathPlaning> vPathPlaningList = null;

    public PathPlanRsp() {
    }

    public PathPlanRsp(ArrayList<PathPlaning> vPathPlaningList2) {
        this.vPathPlaningList = vPathPlaningList2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vPathPlaningList, 0);
    }

    static {
        cache_vPathPlaningList.add(new PathPlaning());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vPathPlaningList = (ArrayList) _is.read((Object) cache_vPathPlaningList, 0, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        this.vPathPlaningList = ((PathPlanRsp) a.parseObject(text, PathPlanRsp.class)).vPathPlaningList;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
