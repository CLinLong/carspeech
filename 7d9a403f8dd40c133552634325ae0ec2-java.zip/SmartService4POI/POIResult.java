package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class POIResult extends JceStruct {
    static Landmark cache_landmark = new Landmark();
    static int cache_status = 0;
    static StructuralAddr cache_structuralAddr = new StructuralAddr();
    public String address = "";
    public String formattedAddr = "";
    public Landmark landmark = null;
    public String recommendAddr = "";
    public int status = -1;
    public StructuralAddr structuralAddr = null;

    public POIResult() {
    }

    public POIResult(int status2, StructuralAddr structuralAddr2, String address2, String formattedAddr2, Landmark landmark2, String recommendAddr2) {
        this.status = status2;
        this.structuralAddr = structuralAddr2;
        this.address = address2;
        this.formattedAddr = formattedAddr2;
        this.landmark = landmark2;
        this.recommendAddr = recommendAddr2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.status, 1);
        _os.write((JceStruct) this.structuralAddr, 2);
        _os.write(this.address, 3);
        if (this.formattedAddr != null) {
            _os.write(this.formattedAddr, 4);
        }
        if (this.landmark != null) {
            _os.write((JceStruct) this.landmark, 5);
        }
        _os.write(this.recommendAddr, 6);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.status = _is.read(this.status, 1, true);
        this.structuralAddr = (StructuralAddr) _is.read((JceStruct) cache_structuralAddr, 2, true);
        this.address = _is.readString(3, true);
        this.formattedAddr = _is.readString(4, false);
        this.landmark = (Landmark) _is.read((JceStruct) cache_landmark, 5, false);
        this.recommendAddr = _is.readString(6, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        POIResult temp = (POIResult) a.parseObject(text, POIResult.class);
        this.status = temp.status;
        this.structuralAddr = temp.structuralAddr;
        this.address = temp.address;
        this.formattedAddr = temp.formattedAddr;
        this.landmark = temp.landmark;
        this.recommendAddr = temp.recommendAddr;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
