package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class PathPlaningStep extends JceStruct {
    public int iDistance = 0;
    public int iDuration = 0;
    public String strAssistAction = "";
    public String strDirection = "";
    public String strEndAction = "";
    public String strInstruction = "";
    public String strRoad = "";

    public PathPlaningStep() {
    }

    public PathPlaningStep(String strInstruction2, String strRoad2, String strDirection2, int iDistance2, int iDuration2, String strEndAction2, String strAssistAction2) {
        this.strInstruction = strInstruction2;
        this.strRoad = strRoad2;
        this.strDirection = strDirection2;
        this.iDistance = iDistance2;
        this.iDuration = iDuration2;
        this.strEndAction = strEndAction2;
        this.strAssistAction = strAssistAction2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strInstruction, 0);
        _os.write(this.strRoad, 1);
        _os.write(this.strDirection, 2);
        _os.write(this.iDistance, 3);
        _os.write(this.iDuration, 4);
        _os.write(this.strEndAction, 5);
        _os.write(this.strAssistAction, 6);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strInstruction = _is.readString(0, true);
        this.strRoad = _is.readString(1, true);
        this.strDirection = _is.readString(2, true);
        this.iDistance = _is.read(this.iDistance, 3, true);
        this.iDuration = _is.read(this.iDuration, 4, true);
        this.strEndAction = _is.readString(5, true);
        this.strAssistAction = _is.readString(6, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        PathPlaningStep temp = (PathPlaningStep) a.parseObject(text, PathPlaningStep.class);
        this.strInstruction = temp.strInstruction;
        this.strRoad = temp.strRoad;
        this.strDirection = temp.strDirection;
        this.iDistance = temp.iDistance;
        this.iDuration = temp.iDuration;
        this.strEndAction = temp.strEndAction;
        this.strAssistAction = temp.strAssistAction;
    }
}
