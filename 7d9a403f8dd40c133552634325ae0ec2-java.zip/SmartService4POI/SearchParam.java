package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SearchParam extends JceStruct {
    static Boundary cache_boundary = new Boundary();
    public Boundary boundary = null;
    public String filter = "";
    public String orderby = "";
    public int pageIndex = 1;
    public int pageSize = 5;

    public SearchParam() {
    }

    public SearchParam(Boundary boundary2, String filter2, String orderby2, int pageSize2, int pageIndex2) {
        this.boundary = boundary2;
        this.filter = filter2;
        this.orderby = orderby2;
        this.pageSize = pageSize2;
        this.pageIndex = pageIndex2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.boundary, 1);
        if (this.filter != null) {
            _os.write(this.filter, 2);
        }
        if (this.orderby != null) {
            _os.write(this.orderby, 3);
        }
        _os.write(this.pageSize, 4);
        _os.write(this.pageIndex, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.boundary = (Boundary) _is.read((JceStruct) cache_boundary, 1, true);
        this.filter = _is.readString(2, false);
        this.orderby = _is.readString(3, false);
        this.pageSize = _is.read(this.pageSize, 4, false);
        this.pageIndex = _is.read(this.pageIndex, 5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SearchParam temp = (SearchParam) a.parseObject(text, SearchParam.class);
        this.boundary = temp.boundary;
        this.filter = temp.filter;
        this.orderby = temp.orderby;
        this.pageSize = temp.pageSize;
        this.pageIndex = temp.pageIndex;
    }
}
