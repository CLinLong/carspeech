package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class LocationObj extends JceStruct {
    static Location cache_location = new Location();
    static StructuralAddr cache_structualAddr = new StructuralAddr();
    public String addr = "";
    public String category = "";
    public String id = "";
    public Location location = null;
    public StructuralAddr structualAddr = null;
    public String tel = "";
    public String title = "";
    public int type = 0;

    public LocationObj() {
    }

    public LocationObj(String title2, String addr2, String tel2, String category2, int type2, Location location2, StructuralAddr structualAddr2, String id2) {
        this.title = title2;
        this.addr = addr2;
        this.tel = tel2;
        this.category = category2;
        this.type = type2;
        this.location = location2;
        this.structualAddr = structualAddr2;
        this.id = id2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.title, 1);
        _os.write(this.addr, 2);
        if (this.tel != null) {
            _os.write(this.tel, 3);
        }
        _os.write(this.category, 4);
        _os.write(this.type, 5);
        _os.write((JceStruct) this.location, 6);
        _os.write((JceStruct) this.structualAddr, 7);
        if (this.id != null) {
            _os.write(this.id, 8);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.title = _is.readString(1, true);
        this.addr = _is.readString(2, true);
        this.tel = _is.readString(3, false);
        this.category = _is.readString(4, true);
        this.type = _is.read(this.type, 5, true);
        this.location = (Location) _is.read((JceStruct) cache_location, 6, true);
        this.structualAddr = (StructuralAddr) _is.read((JceStruct) cache_structualAddr, 7, true);
        this.id = _is.readString(8, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        LocationObj temp = (LocationObj) a.parseObject(text, LocationObj.class);
        this.title = temp.title;
        this.addr = temp.addr;
        this.tel = temp.tel;
        this.category = temp.category;
        this.type = temp.type;
        this.location = temp.location;
        this.structualAddr = temp.structualAddr;
        this.id = temp.id;
    }
}
