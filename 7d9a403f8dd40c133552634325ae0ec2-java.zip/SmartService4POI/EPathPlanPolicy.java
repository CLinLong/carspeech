package SmartService4POI;

import java.io.Serializable;

public final class EPathPlanPolicy implements Serializable {
    public static final int _E_PATHPLAN_LEASTDISTANCE = 2;
    public static final int _E_PATHPLAN_LEASTFEE = 1;
    public static final int _E_PATHPLAN_LEASTTIME = 0;
    public static final int _E_PATHPLAN_REALTRAFFIC = 3;
}
