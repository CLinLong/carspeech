package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Landmark extends JceStruct {
    static Location cache_location = new Location();
    public float distance = 0.0f;
    public int level = 0;
    public Location location = null;
    public String title = "";

    public Landmark() {
    }

    public Landmark(int level2, Location location2, String title2, float distance2) {
        this.level = level2;
        this.location = location2;
        this.title = title2;
        this.distance = distance2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.level, 1);
        _os.write((JceStruct) this.location, 2);
        _os.write(this.title, 3);
        _os.write(this.distance, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.level = _is.read(this.level, 1, true);
        this.location = (Location) _is.read((JceStruct) cache_location, 2, true);
        this.title = _is.readString(3, true);
        this.distance = _is.read(this.distance, 4, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Landmark temp = (Landmark) a.parseObject(text, Landmark.class);
        this.level = temp.level;
        this.location = temp.location;
        this.title = temp.title;
        this.distance = temp.distance;
    }
}
