package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class PathPlanParam extends JceStruct {
    static Location cache_sFromLoc = new Location();
    static Location cache_sToLoc = new Location();
    static ArrayList<Location> cache_vWayPoints = new ArrayList<>();
    public int iMultiPlan = 0;
    public int iPlanMode = 0;
    public int iPolicy = 0;
    public int iSpeed = 0;
    public Location sFromLoc = null;
    public Location sToLoc = null;
    public ArrayList<Location> vWayPoints = null;

    public PathPlanParam() {
    }

    public PathPlanParam(Location sFromLoc2, Location sToLoc2, int iMultiPlan2, ArrayList<Location> vWayPoints2, int iPolicy2, int iSpeed2, int iPlanMode2) {
        this.sFromLoc = sFromLoc2;
        this.sToLoc = sToLoc2;
        this.iMultiPlan = iMultiPlan2;
        this.vWayPoints = vWayPoints2;
        this.iPolicy = iPolicy2;
        this.iSpeed = iSpeed2;
        this.iPlanMode = iPlanMode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.sFromLoc, 0);
        _os.write((JceStruct) this.sToLoc, 1);
        _os.write(this.iMultiPlan, 2);
        if (this.vWayPoints != null) {
            _os.write((Collection) this.vWayPoints, 3);
        }
        _os.write(this.iPolicy, 4);
        _os.write(this.iSpeed, 5);
        _os.write(this.iPlanMode, 6);
    }

    static {
        cache_vWayPoints.add(new Location());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sFromLoc = (Location) _is.read((JceStruct) cache_sFromLoc, 0, true);
        this.sToLoc = (Location) _is.read((JceStruct) cache_sToLoc, 1, true);
        this.iMultiPlan = _is.read(this.iMultiPlan, 2, false);
        this.vWayPoints = (ArrayList) _is.read((Object) cache_vWayPoints, 3, false);
        this.iPolicy = _is.read(this.iPolicy, 4, false);
        this.iSpeed = _is.read(this.iSpeed, 5, false);
        this.iPlanMode = _is.read(this.iPlanMode, 6, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        PathPlanParam temp = (PathPlanParam) a.parseObject(text, PathPlanParam.class);
        this.sFromLoc = temp.sFromLoc;
        this.sToLoc = temp.sToLoc;
        this.iMultiPlan = temp.iMultiPlan;
        this.vWayPoints = temp.vWayPoints;
        this.iPolicy = temp.iPolicy;
        this.iSpeed = temp.iSpeed;
        this.iPlanMode = temp.iPlanMode;
    }
}
