package SmartService4POI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class PathPlaning extends JceStruct {
    static ArrayList<PathPlaningStep> cache_vPathStepList = new ArrayList<>();
    public int iDuration = 0;
    public int iPlanMode = 0;
    public long lDistance = 0;
    public String strDirection = "";
    public ArrayList<PathPlaningStep> vPathStepList = null;

    public PathPlaning() {
    }

    public PathPlaning(int iPlanMode2, long lDistance2, int iDuration2, ArrayList<PathPlaningStep> vPathStepList2, String strDirection2) {
        this.iPlanMode = iPlanMode2;
        this.lDistance = lDistance2;
        this.iDuration = iDuration2;
        this.vPathStepList = vPathStepList2;
        this.strDirection = strDirection2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iPlanMode, 0);
        _os.write(this.lDistance, 1);
        _os.write(this.iDuration, 2);
        _os.write((Collection) this.vPathStepList, 3);
        _os.write(this.strDirection, 4);
    }

    static {
        cache_vPathStepList.add(new PathPlaningStep());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iPlanMode = _is.read(this.iPlanMode, 0, true);
        this.lDistance = _is.read(this.lDistance, 1, true);
        this.iDuration = _is.read(this.iDuration, 2, true);
        this.vPathStepList = (ArrayList) _is.read((Object) cache_vPathStepList, 3, true);
        this.strDirection = _is.readString(4, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        PathPlaning temp = (PathPlaning) a.parseObject(text, PathPlaning.class);
        this.iPlanMode = temp.iPlanMode;
        this.lDistance = temp.lDistance;
        this.iDuration = temp.iDuration;
        this.vPathStepList = temp.vPathStepList;
        this.strDirection = temp.strDirection;
    }
}
