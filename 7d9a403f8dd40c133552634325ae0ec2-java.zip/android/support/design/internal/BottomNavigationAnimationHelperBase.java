package android.support.design.internal;

import android.view.ViewGroup;

class BottomNavigationAnimationHelperBase {
    BottomNavigationAnimationHelperBase() {
    }

    /* access modifiers changed from: package-private */
    public void beginDelayedTransition(ViewGroup view) {
    }
}
