package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SemanticVoice extends JceStruct {
    static ArrayList<SemanticVoiceASRResult> cache_asr_results = new ArrayList<>();
    static int cache_compress_type = 0;
    static byte[] cache_raw_data = new byte[1];
    static int cache_sample_rate = 0;
    public ArrayList<SemanticVoiceASRResult> asr_results = null;
    public int compress_type = 0;
    public String pre_itn_query = "";
    public byte[] raw_data = null;
    public int sample_rate = 0;

    public SemanticVoice() {
    }

    public SemanticVoice(int sample_rate2, int compress_type2, byte[] raw_data2, String pre_itn_query2, ArrayList<SemanticVoiceASRResult> asr_results2) {
        this.sample_rate = sample_rate2;
        this.compress_type = compress_type2;
        this.raw_data = raw_data2;
        this.pre_itn_query = pre_itn_query2;
        this.asr_results = asr_results2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sample_rate, 0);
        _os.write(this.compress_type, 1);
        _os.write(this.raw_data, 2);
        if (this.pre_itn_query != null) {
            _os.write(this.pre_itn_query, 3);
        }
        if (this.asr_results != null) {
            _os.write((Collection) this.asr_results, 4);
        }
    }

    static {
        cache_raw_data[0] = 0;
        cache_asr_results.add(new SemanticVoiceASRResult());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sample_rate = _is.read(this.sample_rate, 0, true);
        this.compress_type = _is.read(this.compress_type, 1, true);
        this.raw_data = _is.read(cache_raw_data, 2, true);
        this.pre_itn_query = _is.readString(3, false);
        this.asr_results = (ArrayList) _is.read((Object) cache_asr_results, 4, false);
    }
}
