package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class LiveIndex extends JceStruct {
    static ArrayList<LiveIndexInfo> cache_vLiveIndex = new ArrayList<>();
    public ArrayList<LiveIndexInfo> vLiveIndex = null;

    public LiveIndex() {
    }

    public LiveIndex(ArrayList<LiveIndexInfo> vLiveIndex2) {
        this.vLiveIndex = vLiveIndex2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vLiveIndex != null) {
            _os.write((Collection) this.vLiveIndex, 0);
        }
    }

    static {
        cache_vLiveIndex.add(new LiveIndexInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vLiveIndex = (ArrayList) _is.read((Object) cache_vLiveIndex, 0, false);
    }
}
