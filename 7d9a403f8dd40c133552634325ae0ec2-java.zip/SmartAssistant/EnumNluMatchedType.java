package SmartAssistant;

import java.io.Serializable;

public final class EnumNluMatchedType implements Serializable {
    public static final int _NLU_MATCHED_MODEL_ACCEPTABLE = 1;
    public static final int _NLU_MATCHED_MODEL_POSSIBLE = 2;
    public static final int _NLU_MATCHED_PATTERN = 0;
}
