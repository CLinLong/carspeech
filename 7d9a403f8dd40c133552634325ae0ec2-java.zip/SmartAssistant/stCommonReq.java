package SmartAssistant;

import SmartService.AIAccountInfo;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class stCommonReq extends JceStruct {
    static AIAccountInfo cache_ai_account_info = new AIAccountInfo();
    static int cache_clientType = 0;
    static ArrayList<stCommonReqIntent> cache_param = new ArrayList<>();
    static UserBase cache_userBase = new UserBase();
    public String access_token = "";
    public AIAccountInfo ai_account_info = null;
    public String app_key = "";
    public int clientType = 0;
    public String content = "";
    public String domain = "";
    public ArrayList<stCommonReqIntent> param = null;
    public UserBase userBase = null;
    public String user_id = "";

    public stCommonReq() {
    }

    public stCommonReq(UserBase userBase2, int clientType2, ArrayList<stCommonReqIntent> param2, String domain2, String content2, String app_key2, String access_token2, String user_id2, AIAccountInfo ai_account_info2) {
        this.userBase = userBase2;
        this.clientType = clientType2;
        this.param = param2;
        this.domain = domain2;
        this.content = content2;
        this.app_key = app_key2;
        this.access_token = access_token2;
        this.user_id = user_id2;
        this.ai_account_info = ai_account_info2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.userBase != null) {
            _os.write((JceStruct) this.userBase, 0);
        }
        _os.write(this.clientType, 1);
        if (this.param != null) {
            _os.write((Collection) this.param, 2);
        }
        if (this.domain != null) {
            _os.write(this.domain, 3);
        }
        if (this.content != null) {
            _os.write(this.content, 4);
        }
        if (this.app_key != null) {
            _os.write(this.app_key, 5);
        }
        if (this.access_token != null) {
            _os.write(this.access_token, 6);
        }
        if (this.user_id != null) {
            _os.write(this.user_id, 7);
        }
        if (this.ai_account_info != null) {
            _os.write((JceStruct) this.ai_account_info, 8);
        }
    }

    static {
        cache_param.add(new stCommonReqIntent());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.userBase = (UserBase) _is.read((JceStruct) cache_userBase, 0, false);
        this.clientType = _is.read(this.clientType, 1, false);
        this.param = (ArrayList) _is.read((Object) cache_param, 2, false);
        this.domain = _is.readString(3, false);
        this.content = _is.readString(4, false);
        this.app_key = _is.readString(5, false);
        this.access_token = _is.readString(6, false);
        this.user_id = _is.readString(7, false);
        this.ai_account_info = (AIAccountInfo) _is.read((JceStruct) cache_ai_account_info, 8, false);
    }
}
