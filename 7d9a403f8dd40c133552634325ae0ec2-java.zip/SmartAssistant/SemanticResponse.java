package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SemanticResponse extends JceStruct {
    static ArrayList<Semantic> cache_candidate_semantic = new ArrayList<>();
    static Semantic cache_semantic = new Semantic();
    static SemanticServerLog cache_semantic_logs = new SemanticServerLog();
    static DMSession cache_session = new DMSession();
    static Status cache_status = new Status();
    public ArrayList<Semantic> candidate_semantic = null;
    public Semantic semantic = null;
    public String semantic_json = "";
    public SemanticServerLog semantic_logs = null;
    public String serverCommonRspJson = "";
    public DMSession session = null;
    public Status status = null;

    public SemanticResponse() {
    }

    public SemanticResponse(Status status2, Semantic semantic2, ArrayList<Semantic> candidate_semantic2, SemanticServerLog semantic_logs2, String semantic_json2, DMSession session2, String serverCommonRspJson2) {
        this.status = status2;
        this.semantic = semantic2;
        this.candidate_semantic = candidate_semantic2;
        this.semantic_logs = semantic_logs2;
        this.semantic_json = semantic_json2;
        this.session = session2;
        this.serverCommonRspJson = serverCommonRspJson2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.status, 0);
        _os.write((JceStruct) this.semantic, 1);
        if (this.candidate_semantic != null) {
            _os.write((Collection) this.candidate_semantic, 2);
        }
        if (this.semantic_logs != null) {
            _os.write((JceStruct) this.semantic_logs, 3);
        }
        if (this.semantic_json != null) {
            _os.write(this.semantic_json, 4);
        }
        if (this.session != null) {
            _os.write((JceStruct) this.session, 5);
        }
        if (this.serverCommonRspJson != null) {
            _os.write(this.serverCommonRspJson, 6);
        }
    }

    static {
        cache_candidate_semantic.add(new Semantic());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.status = (Status) _is.read((JceStruct) cache_status, 0, true);
        this.semantic = (Semantic) _is.read((JceStruct) cache_semantic, 1, true);
        this.candidate_semantic = (ArrayList) _is.read((Object) cache_candidate_semantic, 2, false);
        this.semantic_logs = (SemanticServerLog) _is.read((JceStruct) cache_semantic_logs, 3, false);
        this.semantic_json = _is.readString(4, false);
        this.session = (DMSession) _is.read((JceStruct) cache_session, 5, false);
        this.serverCommonRspJson = _is.readString(6, false);
    }
}
