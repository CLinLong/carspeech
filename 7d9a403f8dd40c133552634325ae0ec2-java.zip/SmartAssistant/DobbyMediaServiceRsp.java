package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyMediaServiceRsp extends JceStruct {
    static int cache_eDisplayFormat = 0;
    static int cache_eRetCode = 0;
    static int cache_eSubService = 0;
    static stMediaData cache_stMedia = new stMediaData();
    public int eDisplayFormat = 1;
    public int ePlayMode = 0;
    public int eRetCode = 0;
    public int eSubService = 0;
    public String exstr = "";
    public String sSpeak = "";
    public String sText = "";
    public stMediaData stMedia = null;
    public String strJsonToSemantic = "";

    public DobbyMediaServiceRsp() {
    }

    public DobbyMediaServiceRsp(int eRetCode2, int eSubService2, String sSpeak2, String sText2, stMediaData stMedia2, int eDisplayFormat2, String exstr2, String strJsonToSemantic2, int ePlayMode2) {
        this.eRetCode = eRetCode2;
        this.eSubService = eSubService2;
        this.sSpeak = sSpeak2;
        this.sText = sText2;
        this.stMedia = stMedia2;
        this.eDisplayFormat = eDisplayFormat2;
        this.exstr = exstr2;
        this.strJsonToSemantic = strJsonToSemantic2;
        this.ePlayMode = ePlayMode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eRetCode, 0);
        _os.write(this.eSubService, 1);
        if (this.sSpeak != null) {
            _os.write(this.sSpeak, 2);
        }
        if (this.sText != null) {
            _os.write(this.sText, 3);
        }
        if (this.stMedia != null) {
            _os.write((JceStruct) this.stMedia, 4);
        }
        _os.write(this.eDisplayFormat, 5);
        if (this.exstr != null) {
            _os.write(this.exstr, 6);
        }
        if (this.strJsonToSemantic != null) {
            _os.write(this.strJsonToSemantic, 7);
        }
        _os.write(this.ePlayMode, 8);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eRetCode = _is.read(this.eRetCode, 0, false);
        this.eSubService = _is.read(this.eSubService, 1, false);
        this.sSpeak = _is.readString(2, false);
        this.sText = _is.readString(3, false);
        this.stMedia = (stMediaData) _is.read((JceStruct) cache_stMedia, 4, false);
        this.eDisplayFormat = _is.read(this.eDisplayFormat, 5, false);
        this.exstr = _is.readString(6, false);
        this.strJsonToSemantic = _is.readString(7, false);
        this.ePlayMode = _is.read(this.ePlayMode, 8, false);
    }
}
