package SmartAssistant;

import java.io.Serializable;

public final class EnumSemanticVoiceCompressType implements Serializable {
    public static final int _ENUM_SEMANTIC_VOICE_COMPRESS_TYPE_AMR = 5;
    public static final int _ENUM_SEMANTIC_VOICE_COMPRESS_TYPE_PCM = 1;
    public static final int _ENUM_SEMANTIC_VOICE_COMPRESS_TYPE_SPEEX = 4;
    public static final int _ENUM_SEMANTIC_VOICE_COMPRESS_TYPE_WAV = 2;
}
