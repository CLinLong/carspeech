package SmartAssistant;

import java.io.Serializable;

public final class EnumSemanticQuerySourceType implements Serializable {
    public static final int _ENUM_SEMANTIC_QUERY_SOURCE_TYPE_TEXT = 2;
    public static final int _ENUM_SEMANTIC_QUERY_SOURCE_TYPE_UNKNOWN = 1;
    public static final int _ENUM_SEMANTIC_QUERY_SOURCE_TYPE_VOICE = 3;
}
