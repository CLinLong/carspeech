package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NlpTokenOccurence extends JceStruct {
    static ArrayList<NlpKeywordOccurence> cache_keyword_cand = new ArrayList<>();
    public ArrayList<NlpKeywordOccurence> keyword_cand = null;
    public int offset = 0;
    public String pos = "";
    public String text = "";

    public NlpTokenOccurence() {
    }

    public NlpTokenOccurence(String text2, String pos2, ArrayList<NlpKeywordOccurence> keyword_cand2, int offset2) {
        this.text = text2;
        this.pos = pos2;
        this.keyword_cand = keyword_cand2;
        this.offset = offset2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.text, 0);
        _os.write(this.pos, 1);
        if (this.keyword_cand != null) {
            _os.write((Collection) this.keyword_cand, 2);
        }
        _os.write(this.offset, 3);
    }

    static {
        cache_keyword_cand.add(new NlpKeywordOccurence());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.text = _is.readString(0, true);
        this.pos = _is.readString(1, true);
        this.keyword_cand = (ArrayList) _is.read((Object) cache_keyword_cand, 2, false);
        this.offset = _is.read(this.offset, 3, false);
    }
}
