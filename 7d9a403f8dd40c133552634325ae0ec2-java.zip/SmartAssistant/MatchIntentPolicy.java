package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class MatchIntentPolicy extends JceStruct {
    public String intent_name = "";
    public int match_content = 0;

    public MatchIntentPolicy() {
    }

    public MatchIntentPolicy(String intent_name2, int match_content2) {
        this.intent_name = intent_name2;
        this.match_content = match_content2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.intent_name != null) {
            _os.write(this.intent_name, 0);
        }
        _os.write(this.match_content, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.intent_name = _is.readString(0, false);
        this.match_content = _is.read(this.match_content, 1, false);
    }
}
