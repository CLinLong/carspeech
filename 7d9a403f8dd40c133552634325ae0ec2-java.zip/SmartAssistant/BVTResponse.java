package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.HashMap;
import java.util.Map;

public final class BVTResponse extends JceStruct {
    static Map<Integer, String> cache_parameter_rsp_map = new HashMap();
    static SemanticResponse cache_semantic_rsp = new SemanticResponse();
    public float domain_score = 0.0f;
    public String intent_rsp_str = "";
    public float intent_score = 0.0f;
    public Map<Integer, String> parameter_rsp_map = null;
    public String pattern = "";
    public String pattern_rsp_str = "";
    public float pattern_score = 0.0f;
    public SemanticResponse semantic_rsp = null;

    public BVTResponse() {
    }

    public BVTResponse(SemanticResponse semantic_rsp2, String pattern2, float pattern_score2, float domain_score2, float intent_score2, String pattern_rsp_str2, String intent_rsp_str2, Map<Integer, String> parameter_rsp_map2) {
        this.semantic_rsp = semantic_rsp2;
        this.pattern = pattern2;
        this.pattern_score = pattern_score2;
        this.domain_score = domain_score2;
        this.intent_score = intent_score2;
        this.pattern_rsp_str = pattern_rsp_str2;
        this.intent_rsp_str = intent_rsp_str2;
        this.parameter_rsp_map = parameter_rsp_map2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.semantic_rsp, 0);
        if (this.pattern != null) {
            _os.write(this.pattern, 1);
        }
        _os.write(this.pattern_score, 2);
        _os.write(this.domain_score, 3);
        _os.write(this.intent_score, 4);
        if (this.pattern_rsp_str != null) {
            _os.write(this.pattern_rsp_str, 5);
        }
        if (this.intent_rsp_str != null) {
            _os.write(this.intent_rsp_str, 6);
        }
        if (this.parameter_rsp_map != null) {
            _os.write((Map) this.parameter_rsp_map, 7);
        }
    }

    static {
        cache_parameter_rsp_map.put(0, "");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.semantic_rsp = (SemanticResponse) _is.read((JceStruct) cache_semantic_rsp, 0, true);
        this.pattern = _is.readString(1, false);
        this.pattern_score = _is.read(this.pattern_score, 2, false);
        this.domain_score = _is.read(this.domain_score, 3, false);
        this.intent_score = _is.read(this.intent_score, 4, false);
        this.pattern_rsp_str = _is.readString(5, false);
        this.intent_rsp_str = _is.readString(6, false);
        this.parameter_rsp_map = (Map) _is.read((Object) cache_parameter_rsp_map, 7, false);
    }
}
