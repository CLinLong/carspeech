package SmartAssistant;

import java.io.Serializable;

public final class EnumSemanticPromptType implements Serializable {
    public static final int _ENUM_SEMANTIC_PROMPT_TYPE_CONFIRM = 2;
    public static final int _ENUM_SEMANTIC_PROMPT_TYPE_INTENT = 3;
    public static final int _ENUM_SEMANTIC_PROMPT_TYPE_SLOT = 0;
    public static final int _ENUM_SEMANTIC_PROMPT_TYPE_TIPS = 1;
}
