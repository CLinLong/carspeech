package SmartAssistant;

import java.io.Serializable;

public final class EnumRepeatDateTimeType implements Serializable {
    public static final int _DAY = 4;
    public static final int _HOUR = 5;
    public static final int _MINUTE = 6;
    public static final int _MONTH = 2;
    public static final int _WEEK = 3;
    public static final int _WEEKEND = 8;
    public static final int _WORKDAY = 7;
    public static final int _YEAR = 1;
}
