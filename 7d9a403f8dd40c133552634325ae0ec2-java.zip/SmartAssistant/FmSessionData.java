package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class FmSessionData extends JceStruct {
    static FmDataItem cache_fmDataItem = new FmDataItem();
    public FmDataItem fmDataItem = null;
    public int iCurrentCursor = 0;
    public String sType = "";

    public FmSessionData() {
    }

    public FmSessionData(String sType2, int iCurrentCursor2, FmDataItem fmDataItem2) {
        this.sType = sType2;
        this.iCurrentCursor = iCurrentCursor2;
        this.fmDataItem = fmDataItem2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sType != null) {
            _os.write(this.sType, 0);
        }
        _os.write(this.iCurrentCursor, 1);
        if (this.fmDataItem != null) {
            _os.write((JceStruct) this.fmDataItem, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sType = _is.readString(0, false);
        this.iCurrentCursor = _is.read(this.iCurrentCursor, 1, false);
        this.fmDataItem = (FmDataItem) _is.read((JceStruct) cache_fmDataItem, 2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        FmSessionData temp = (FmSessionData) a.parseObject(text, FmSessionData.class);
        this.sType = temp.sType;
        this.iCurrentCursor = temp.iCurrentCursor;
        this.fmDataItem = temp.fmDataItem;
    }
}
