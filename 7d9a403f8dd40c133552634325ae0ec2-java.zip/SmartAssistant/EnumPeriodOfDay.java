package SmartAssistant;

import java.io.Serializable;

public final class EnumPeriodOfDay implements Serializable {
    public static final int _AFTERNOON = 5;
    public static final int _DAYTIME = 8;
    public static final int _DUSK = 6;
    public static final int _EARLY_MORNING = 1;
    public static final int _EVENING = 7;
    public static final int _FORENOON = 3;
    public static final int _INIT_STATE_PD = 0;
    public static final int _MORNING = 2;
    public static final int _NOON = 4;
}
