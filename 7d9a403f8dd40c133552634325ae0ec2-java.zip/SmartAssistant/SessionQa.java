package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SessionQa extends JceStruct {
    public String prompt = "";
    public String query = "";

    public SessionQa() {
    }

    public SessionQa(String query2, String prompt2) {
        this.query = query2;
        this.prompt = prompt2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.query != null) {
            _os.write(this.query, 1);
        }
        if (this.prompt != null) {
            _os.write(this.prompt, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.query = _is.readString(1, false);
        this.prompt = _is.readString(2, false);
    }
}
