package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ResponseBase extends JceStruct {
    public String scene = "";
    public String semantic_version = "";
    public int version = 0;

    public ResponseBase() {
    }

    public ResponseBase(int version2, String scene2, String semantic_version2) {
        this.version = version2;
        this.scene = scene2;
        this.semantic_version = semantic_version2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.version, 0);
        _os.write(this.scene, 1);
        if (this.semantic_version != null) {
            _os.write(this.semantic_version, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.version = _is.read(this.version, 0, true);
        this.scene = _is.readString(1, true);
        this.semantic_version = _is.readString(2, false);
    }
}
