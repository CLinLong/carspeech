package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NlpKeywordInfo extends JceStruct {
    static ArrayList<NlpRecord> cache_record = new ArrayList<>();
    public ArrayList<NlpRecord> record = null;

    public NlpKeywordInfo() {
    }

    public NlpKeywordInfo(ArrayList<NlpRecord> record2) {
        this.record = record2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.record != null) {
            _os.write((Collection) this.record, 0);
        }
    }

    static {
        cache_record.add(new NlpRecord());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.record = (ArrayList) _is.read((Object) cache_record, 0, false);
    }
}
