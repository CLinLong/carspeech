package SmartAssistant;

import java.io.Serializable;

public final class EnumNumberType implements Serializable {
    public static final int _DECIMAL = 2;
    public static final int _FRACTION = 1;
    public static final int _INTEGER = 3;
    public static final int _ORDINAL = 4;
}
