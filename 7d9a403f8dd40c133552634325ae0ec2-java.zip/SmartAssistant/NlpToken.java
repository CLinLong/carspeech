package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NlpToken extends JceStruct {
    public String word = "";
    public String word_type = "";

    public NlpToken() {
    }

    public NlpToken(String word2, String word_type2) {
        this.word = word2;
        this.word_type = word_type2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.word, 0);
        _os.write(this.word_type, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.word = _is.readString(0, true);
        this.word_type = _is.readString(1, true);
    }
}
