package SmartAssistant;

import java.io.Serializable;

public final class enumFmActionType implements Serializable {
    public static final int _E_FM_ACTION_PLAY = 3;
    public static final int _E_FM_ACTION_PLAYLIST = 4;
}
