package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyWeatherDetail extends JceStruct {
    public int nDayWeaIndex = 0;
    public int nNightWeaIndex = 0;
    public String sDayWeather = "";
    public String sDayWind = "";
    public String sDayWindPower = "";
    public String sNightWeather = "";
    public String sNightWind = "";
    public String sNightWindPower = "";

    public DobbyWeatherDetail() {
    }

    public DobbyWeatherDetail(int nDayWeaIndex2, String sDayWeather2, int nNightWeaIndex2, String sNightWeather2, String sDayWind2, String sDayWindPower2, String sNightWind2, String sNightWindPower2) {
        this.nDayWeaIndex = nDayWeaIndex2;
        this.sDayWeather = sDayWeather2;
        this.nNightWeaIndex = nNightWeaIndex2;
        this.sNightWeather = sNightWeather2;
        this.sDayWind = sDayWind2;
        this.sDayWindPower = sDayWindPower2;
        this.sNightWind = sNightWind2;
        this.sNightWindPower = sNightWindPower2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.nDayWeaIndex, 0);
        if (this.sDayWeather != null) {
            _os.write(this.sDayWeather, 1);
        }
        _os.write(this.nNightWeaIndex, 2);
        if (this.sNightWeather != null) {
            _os.write(this.sNightWeather, 3);
        }
        if (this.sDayWind != null) {
            _os.write(this.sDayWind, 4);
        }
        if (this.sDayWindPower != null) {
            _os.write(this.sDayWindPower, 5);
        }
        if (this.sNightWind != null) {
            _os.write(this.sNightWind, 6);
        }
        if (this.sNightWindPower != null) {
            _os.write(this.sNightWindPower, 7);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.nDayWeaIndex = _is.read(this.nDayWeaIndex, 0, false);
        this.sDayWeather = _is.readString(1, false);
        this.nNightWeaIndex = _is.read(this.nNightWeaIndex, 2, false);
        this.sNightWeather = _is.readString(3, false);
        this.sDayWind = _is.readString(4, false);
        this.sDayWindPower = _is.readString(5, false);
        this.sNightWind = _is.readString(6, false);
        this.sNightWindPower = _is.readString(7, false);
    }
}
