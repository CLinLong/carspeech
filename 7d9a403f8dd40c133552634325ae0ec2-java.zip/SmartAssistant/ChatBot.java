package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ChatBot extends JceStruct {
    public String sBotID = "";
    public String sBotType = "";

    public ChatBot() {
    }

    public ChatBot(String sBotType2, String sBotID2) {
        this.sBotType = sBotType2;
        this.sBotID = sBotID2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sBotType != null) {
            _os.write(this.sBotType, 0);
        }
        if (this.sBotID != null) {
            _os.write(this.sBotID, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sBotType = _is.readString(0, false);
        this.sBotID = _is.readString(1, false);
    }
}
