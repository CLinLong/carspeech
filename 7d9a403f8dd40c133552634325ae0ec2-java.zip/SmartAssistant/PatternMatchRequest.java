package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public final class PatternMatchRequest extends JceStruct {
    static Map<String, ArrayList<NlpEntity>> cache_attribute = new HashMap();
    static ArrayList<NlpTokenOccurence> cache_char_occurs = new ArrayList<>();
    static PatternMatchPolicy cache_match_policy = new PatternMatchPolicy();
    static ArrayList<NlpToken> cache_tokens = new ArrayList<>();
    public String appkey = "";
    public Map<String, ArrayList<NlpEntity>> attribute = null;
    public ArrayList<NlpTokenOccurence> char_occurs = null;
    public PatternMatchPolicy match_policy = null;
    public boolean noHotPattern = true;
    public String query = "";
    public ArrayList<NlpToken> tokens = null;

    public PatternMatchRequest() {
    }

    public PatternMatchRequest(String appkey2, String query2, Map<String, ArrayList<NlpEntity>> attribute2, PatternMatchPolicy match_policy2, ArrayList<NlpToken> tokens2, boolean noHotPattern2, ArrayList<NlpTokenOccurence> char_occurs2) {
        this.appkey = appkey2;
        this.query = query2;
        this.attribute = attribute2;
        this.match_policy = match_policy2;
        this.tokens = tokens2;
        this.noHotPattern = noHotPattern2;
        this.char_occurs = char_occurs2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.appkey, 0);
        _os.write(this.query, 1);
        if (this.attribute != null) {
            _os.write((Map) this.attribute, 2);
        }
        if (this.match_policy != null) {
            _os.write((JceStruct) this.match_policy, 3);
        }
        if (this.tokens != null) {
            _os.write((Collection) this.tokens, 4);
        }
        _os.write(this.noHotPattern, 5);
        if (this.char_occurs != null) {
            _os.write((Collection) this.char_occurs, 6);
        }
    }

    static {
        ArrayList<NlpEntity> __var_4 = new ArrayList<>();
        __var_4.add(new NlpEntity());
        cache_attribute.put("", __var_4);
        cache_tokens.add(new NlpToken());
        cache_char_occurs.add(new NlpTokenOccurence());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.appkey = _is.readString(0, true);
        this.query = _is.readString(1, true);
        this.attribute = (Map) _is.read((Object) cache_attribute, 2, false);
        this.match_policy = (PatternMatchPolicy) _is.read((JceStruct) cache_match_policy, 3, false);
        this.tokens = (ArrayList) _is.read((Object) cache_tokens, 4, false);
        this.noHotPattern = _is.read(this.noHotPattern, 5, false);
        this.char_occurs = (ArrayList) _is.read((Object) cache_char_occurs, 6, false);
    }
}
