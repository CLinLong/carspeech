package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NlpRecord extends JceStruct {
    public float freq = -1.0f;
    public String name = "";
    public float prior = -1.0f;
    public String ref_value = "";
    public int type = -1;

    public NlpRecord() {
    }

    public NlpRecord(int type2, String name2, String ref_value2, float freq2, float prior2) {
        this.type = type2;
        this.name = name2;
        this.ref_value = ref_value2;
        this.freq = freq2;
        this.prior = prior2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.type, 0);
        if (this.name != null) {
            _os.write(this.name, 1);
        }
        if (this.ref_value != null) {
            _os.write(this.ref_value, 2);
        }
        _os.write(this.freq, 3);
        _os.write(this.prior, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.type = _is.read(this.type, 0, false);
        this.name = _is.readString(1, false);
        this.ref_value = _is.readString(2, false);
        this.freq = _is.read(this.freq, 3, false);
        this.prior = _is.read(this.prior, 4, false);
    }
}
