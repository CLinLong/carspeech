package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyHourlyWeatherSimple extends JceStruct {
    public String sAQI = "";
    public String sAQIDes = "";
    public String sDWeaIndex = "";
    public String sDweather = "";
    public String sHumidity = "";
    public String sName = "";
    public String sPm25 = "";
    public String sPrecipitation = "";
    public String sTemperature = "";
    public String sTim = "";

    public DobbyHourlyWeatherSimple() {
    }

    public DobbyHourlyWeatherSimple(String sDWeaIndex2, String sTim2, String sDweather2, String sName2, String sTemperature2, String sAQIDes2, String sAQI2, String sPm252, String sHumidity2, String sPrecipitation2) {
        this.sDWeaIndex = sDWeaIndex2;
        this.sTim = sTim2;
        this.sDweather = sDweather2;
        this.sName = sName2;
        this.sTemperature = sTemperature2;
        this.sAQIDes = sAQIDes2;
        this.sAQI = sAQI2;
        this.sPm25 = sPm252;
        this.sHumidity = sHumidity2;
        this.sPrecipitation = sPrecipitation2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sDWeaIndex != null) {
            _os.write(this.sDWeaIndex, 0);
        }
        if (this.sTim != null) {
            _os.write(this.sTim, 1);
        }
        if (this.sDweather != null) {
            _os.write(this.sDweather, 2);
        }
        if (this.sName != null) {
            _os.write(this.sName, 3);
        }
        if (this.sTemperature != null) {
            _os.write(this.sTemperature, 4);
        }
        if (this.sAQIDes != null) {
            _os.write(this.sAQIDes, 5);
        }
        if (this.sAQI != null) {
            _os.write(this.sAQI, 6);
        }
        if (this.sPm25 != null) {
            _os.write(this.sPm25, 7);
        }
        if (this.sHumidity != null) {
            _os.write(this.sHumidity, 8);
        }
        if (this.sPrecipitation != null) {
            _os.write(this.sPrecipitation, 9);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sDWeaIndex = _is.readString(0, false);
        this.sTim = _is.readString(1, false);
        this.sDweather = _is.readString(2, false);
        this.sName = _is.readString(3, false);
        this.sTemperature = _is.readString(4, false);
        this.sAQIDes = _is.readString(5, false);
        this.sAQI = _is.readString(6, false);
        this.sPm25 = _is.readString(7, false);
        this.sHumidity = _is.readString(8, false);
        this.sPrecipitation = _is.readString(9, false);
    }
}
