package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NluExplicitRequest extends JceStruct {
    static ArrayList<NluSlot> cache_slots = new ArrayList<>();
    public String domain = "";
    public String intent = "";
    public ArrayList<NluSlot> slots = null;

    public NluExplicitRequest() {
    }

    public NluExplicitRequest(String domain2, String intent2, ArrayList<NluSlot> slots2) {
        this.domain = domain2;
        this.intent = intent2;
        this.slots = slots2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.domain != null) {
            _os.write(this.domain, 0);
        }
        if (this.intent != null) {
            _os.write(this.intent, 1);
        }
        if (this.slots != null) {
            _os.write((Collection) this.slots, 2);
        }
    }

    static {
        cache_slots.add(new NluSlot());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.domain = _is.readString(0, false);
        this.intent = _is.readString(1, false);
        this.slots = (ArrayList) _is.read((Object) cache_slots, 2, false);
    }
}
