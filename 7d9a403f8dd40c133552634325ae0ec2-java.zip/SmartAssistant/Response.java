package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class Response extends JceStruct {
    static ArrayList<ResponseIntent> cache_intents = new ArrayList<>();
    static Prompt cache_prompt = new Prompt();
    static ResponseBase cache_response_base = new ResponseBase();
    static int cache_status = 0;
    public ArrayList<ResponseIntent> intents = null;
    public Prompt prompt = null;
    public ResponseBase response_base = null;
    public boolean session_complete = true;
    public int status = 0;

    public Response() {
    }

    public Response(ResponseBase response_base2, int status2, boolean session_complete2, Prompt prompt2, ArrayList<ResponseIntent> intents2) {
        this.response_base = response_base2;
        this.status = status2;
        this.session_complete = session_complete2;
        this.prompt = prompt2;
        this.intents = intents2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.response_base, 0);
        _os.write(this.status, 1);
        _os.write(this.session_complete, 2);
        if (this.prompt != null) {
            _os.write((JceStruct) this.prompt, 3);
        }
        if (this.intents != null) {
            _os.write((Collection) this.intents, 4);
        }
    }

    static {
        cache_intents.add(new ResponseIntent());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.response_base = (ResponseBase) _is.read((JceStruct) cache_response_base, 0, true);
        this.status = _is.read(this.status, 1, true);
        this.session_complete = _is.read(this.session_complete, 2, true);
        this.prompt = (Prompt) _is.read((JceStruct) cache_prompt, 3, false);
        this.intents = (ArrayList) _is.read((Object) cache_intents, 4, false);
    }
}
