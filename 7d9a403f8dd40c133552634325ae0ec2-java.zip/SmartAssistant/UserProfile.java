package SmartAssistant;

import SmartService.AIAccountInfo;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class UserProfile extends JceStruct {
    static AIAccountInfo cache_ai_account_info = new AIAccountInfo();
    static UserBase cache_user_base = new UserBase();
    public String access_token = "";
    public AIAccountInfo ai_account_info = null;
    public String app_key = "";
    public UserBase user_base = null;
    public String user_id = "";

    public UserProfile() {
    }

    public UserProfile(UserBase user_base2, String app_key2, String access_token2, String user_id2, AIAccountInfo ai_account_info2) {
        this.user_base = user_base2;
        this.app_key = app_key2;
        this.access_token = access_token2;
        this.user_id = user_id2;
        this.ai_account_info = ai_account_info2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.user_base, 0);
        _os.write(this.app_key, 1);
        _os.write(this.access_token, 2);
        _os.write(this.user_id, 3);
        if (this.ai_account_info != null) {
            _os.write((JceStruct) this.ai_account_info, 4);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.user_base = (UserBase) _is.read((JceStruct) cache_user_base, 0, true);
        this.app_key = _is.readString(1, true);
        this.access_token = _is.readString(2, true);
        this.user_id = _is.readString(3, true);
        this.ai_account_info = (AIAccountInfo) _is.read((JceStruct) cache_ai_account_info, 4, false);
    }
}
