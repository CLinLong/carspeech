package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class UserInfo extends JceStruct {
    public String uid = "";

    public UserInfo() {
    }

    public UserInfo(String uid2) {
        this.uid = uid2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.uid, 0);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.uid = _is.readString(0, true);
    }
}
