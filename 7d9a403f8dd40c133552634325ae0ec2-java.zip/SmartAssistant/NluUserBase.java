package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NluUserBase extends JceStruct {
    public String app_key = "";
    public String ip = "";
    public String lbs = "";
    public String qua = "";
    public String user_id = "";

    public NluUserBase() {
    }

    public NluUserBase(String user_id2, String app_key2, String lbs2, String ip2, String qua2) {
        this.user_id = user_id2;
        this.app_key = app_key2;
        this.lbs = lbs2;
        this.ip = ip2;
        this.qua = qua2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.user_id != null) {
            _os.write(this.user_id, 0);
        }
        if (this.app_key != null) {
            _os.write(this.app_key, 1);
        }
        if (this.lbs != null) {
            _os.write(this.lbs, 2);
        }
        if (this.ip != null) {
            _os.write(this.ip, 3);
        }
        if (this.qua != null) {
            _os.write(this.qua, 4);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.user_id = _is.readString(0, false);
        this.app_key = _is.readString(1, false);
        this.lbs = _is.readString(2, false);
        this.ip = _is.readString(3, false);
        this.qua = _is.readString(4, false);
    }
}
