package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NluPolicy extends JceStruct {
    static int cache_mode = 0;
    static ArrayList<String> cache_single_entity_list = new ArrayList<>();
    public boolean get_poi_city = true;
    public boolean hot_pattern = true;
    public int mode = 0;
    public ArrayList<String> single_entity_list = null;

    public NluPolicy() {
    }

    public NluPolicy(int mode2, boolean hot_pattern2, ArrayList<String> single_entity_list2, boolean get_poi_city2) {
        this.mode = mode2;
        this.hot_pattern = hot_pattern2;
        this.single_entity_list = single_entity_list2;
        this.get_poi_city = get_poi_city2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.mode, 0);
        _os.write(this.hot_pattern, 1);
        if (this.single_entity_list != null) {
            _os.write((Collection) this.single_entity_list, 2);
        }
        _os.write(this.get_poi_city, 3);
    }

    static {
        cache_single_entity_list.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.mode = _is.read(this.mode, 0, false);
        this.hot_pattern = _is.read(this.hot_pattern, 1, false);
        this.single_entity_list = (ArrayList) _is.read((Object) cache_single_entity_list, 2, false);
        this.get_poi_city = _is.read(this.get_poi_city, 3, false);
    }
}
