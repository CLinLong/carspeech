package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Status extends JceStruct {
    static int cache_code = 0;
    public int code = 0;
    public String msg = "";

    public Status() {
    }

    public Status(int code2, String msg2) {
        this.code = code2;
        this.msg = msg2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.code, 0);
        if (this.msg != null) {
            _os.write(this.msg, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.code = _is.read(this.code, 0, false);
        this.msg = _is.readString(1, false);
    }
}
