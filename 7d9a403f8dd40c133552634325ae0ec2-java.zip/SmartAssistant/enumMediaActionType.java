package SmartAssistant;

import java.io.Serializable;

public final class enumMediaActionType implements Serializable {
    public static final int _E_MEDIA_ACTION_COLLECT = 10;
    public static final int _E_MEDIA_ACTION_DELETE = 2;
    public static final int _E_MEDIA_ACTION_NEXT = 9;
    public static final int _E_MEDIA_ACTION_PAUSE = 5;
    public static final int _E_MEDIA_ACTION_PLAY = 3;
    public static final int _E_MEDIA_ACTION_PLAYLIST = 4;
    public static final int _E_MEDIA_ACTION_PREV = 8;
    public static final int _E_MEDIA_ACTION_RESUME = 6;
    public static final int _E_MEDIA_ACTION_SEARCH_ALBUM = 14;
    public static final int _E_MEDIA_ACTION_SEARCH_LYRICS = 13;
    public static final int _E_MEDIA_ACTION_SEARCH_SINGER = 12;
    public static final int _E_MEDIA_ACTION_SEARCH_SONG = 11;
    public static final int _E_MEDIA_ACTION_SEARCH_TVFILM = 15;
    public static final int _E_MEDIA_ACTION_SELECT = 1;
    public static final int _E_MEDIA_ACTION_STOP = 7;
    public static final int _E_MEDIA_ACTION_UNKNOWN = 0;
}
