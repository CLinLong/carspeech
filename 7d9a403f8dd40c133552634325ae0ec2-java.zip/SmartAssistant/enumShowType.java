package SmartAssistant;

import java.io.Serializable;

public final class enumShowType implements Serializable {
    public static final int _E_FM_TYPE_LIVE = 2;
    public static final int _E_FM_TYPE_RADIO = 1;
    public static final int _E_FM_TYPE_SHOW = 0;
}
