package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NluExtraInfo extends JceStruct {
    static int cache_matched_type = 0;
    public float domain_score = 0.0f;
    public float intent_score = 0.0f;
    public String matched_pattern = "";
    public int matched_type = 0;
    public float pattern_score = 0.0f;
    public float slot_score = 0.0f;

    public NluExtraInfo() {
    }

    public NluExtraInfo(float domain_score2, float intent_score2, float slot_score2, String matched_pattern2, float pattern_score2, int matched_type2) {
        this.domain_score = domain_score2;
        this.intent_score = intent_score2;
        this.slot_score = slot_score2;
        this.matched_pattern = matched_pattern2;
        this.pattern_score = pattern_score2;
        this.matched_type = matched_type2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.domain_score, 0);
        _os.write(this.intent_score, 1);
        _os.write(this.slot_score, 2);
        if (this.matched_pattern != null) {
            _os.write(this.matched_pattern, 3);
        }
        _os.write(this.pattern_score, 4);
        _os.write(this.matched_type, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.domain_score = _is.read(this.domain_score, 0, false);
        this.intent_score = _is.read(this.intent_score, 1, false);
        this.slot_score = _is.read(this.slot_score, 2, false);
        this.matched_pattern = _is.readString(3, false);
        this.pattern_score = _is.read(this.pattern_score, 4, false);
        this.matched_type = _is.read(this.matched_type, 5, false);
    }
}
