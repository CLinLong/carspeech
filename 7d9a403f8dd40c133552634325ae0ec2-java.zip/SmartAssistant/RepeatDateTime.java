package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class RepeatDateTime extends JceStruct {
    static IntervalDatetime cache_interval = new IntervalDatetime();
    static int cache_repeat_datetime_type = 0;
    public IntervalDatetime interval = null;
    public int repeat_datetime_type = 0;

    public RepeatDateTime() {
    }

    public RepeatDateTime(IntervalDatetime interval2, int repeat_datetime_type2) {
        this.interval = interval2;
        this.repeat_datetime_type = repeat_datetime_type2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.interval != null) {
            _os.write((JceStruct) this.interval, 0);
        }
        _os.write(this.repeat_datetime_type, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.interval = (IntervalDatetime) _is.read((JceStruct) cache_interval, 0, false);
        this.repeat_datetime_type = _is.read(this.repeat_datetime_type, 1, false);
    }
}
