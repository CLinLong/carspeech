package SmartAssistant;

import java.io.Serializable;

public final class EnumNluMode implements Serializable {
    public static final int _NLU_MODE_RETURN_ALL = 0;
    public static final int _NLU_MODE_RETURN_MODEL = 2;
    public static final int _NLU_MODE_RETURN_PATTERN = 1;
}
