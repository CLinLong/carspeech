package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class QAPair extends JceStruct {
    static SemanticPrompt cache_prompt = new SemanticPrompt();
    public SemanticPrompt prompt = null;
    public String query = "";

    public QAPair() {
    }

    public QAPair(String query2, SemanticPrompt prompt2) {
        this.query = query2;
        this.prompt = prompt2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.query != null) {
            _os.write(this.query, 0);
        }
        if (this.prompt != null) {
            _os.write((JceStruct) this.prompt, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.query = _is.readString(0, false);
        this.prompt = (SemanticPrompt) _is.read((JceStruct) cache_prompt, 1, false);
    }
}
