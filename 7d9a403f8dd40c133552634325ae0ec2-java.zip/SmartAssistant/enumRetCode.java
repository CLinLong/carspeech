package SmartAssistant;

import java.io.Serializable;

public final class enumRetCode implements Serializable {
    public static final int _E_RET_CODE_DELETE_FAILED = -1003;
    public static final int _E_RET_CODE_ERROR_UID = -1001;
    public static final int _E_RET_CODE_NOT_CURRENT_SCENE = -1004;
    public static final int _E_RET_CODE_OK = 0;
    public static final int _E_RET_CODE_QUERY_TIMEOUT = -1002;
}
