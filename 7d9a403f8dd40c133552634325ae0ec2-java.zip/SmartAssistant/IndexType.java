package SmartAssistant;

import java.io.Serializable;

public final class IndexType implements Serializable {
    public static final int _E_INDEX_CARWASHING = 0;
    public static final int _E_INDEX_COLDRISK = 3;
    public static final int _E_INDEX_DRESSING = 1;
    public static final int _E_INDEX_ULTRAVIOLET = 2;
}
