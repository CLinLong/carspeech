package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class stMeidaSessionData extends JceStruct {
    static stMediaDataItem cache_stMediaList = new stMediaDataItem();
    public int iCurrentCursor = 0;
    public int iLastChangeCursorTime = 0;
    public int iLastQueryTime = 0;
    public String sType = "";
    public stMediaDataItem stMediaList = null;

    public stMeidaSessionData() {
    }

    public stMeidaSessionData(String sType2, int iCurrentCursor2, stMediaDataItem stMediaList2, int iLastQueryTime2, int iLastChangeCursorTime2) {
        this.sType = sType2;
        this.iCurrentCursor = iCurrentCursor2;
        this.stMediaList = stMediaList2;
        this.iLastQueryTime = iLastQueryTime2;
        this.iLastChangeCursorTime = iLastChangeCursorTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sType != null) {
            _os.write(this.sType, 0);
        }
        _os.write(this.iCurrentCursor, 1);
        if (this.stMediaList != null) {
            _os.write((JceStruct) this.stMediaList, 2);
        }
        _os.write(this.iLastQueryTime, 3);
        _os.write(this.iLastChangeCursorTime, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sType = _is.readString(0, false);
        this.iCurrentCursor = _is.read(this.iCurrentCursor, 1, false);
        this.stMediaList = (stMediaDataItem) _is.read((JceStruct) cache_stMediaList, 2, false);
        this.iLastQueryTime = _is.read(this.iLastQueryTime, 3, false);
        this.iLastChangeCursorTime = _is.read(this.iLastChangeCursorTime, 4, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        stMeidaSessionData temp = (stMeidaSessionData) a.parseObject(text, stMeidaSessionData.class);
        this.sType = temp.sType;
        this.iCurrentCursor = temp.iCurrentCursor;
        this.stMediaList = temp.stMediaList;
        this.iLastQueryTime = temp.iLastQueryTime;
        this.iLastChangeCursorTime = temp.iLastChangeCursorTime;
    }
}
