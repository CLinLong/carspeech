package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class DMSession extends JceStruct {
    static ArrayList<SessionAtom> cache_session_stack = new ArrayList<>();
    static UserInfo cache_user_info = new UserInfo();
    public ArrayList<SessionAtom> session_stack = null;
    public UserInfo user_info = null;

    public DMSession() {
    }

    public DMSession(UserInfo user_info2, ArrayList<SessionAtom> session_stack2) {
        this.user_info = user_info2;
        this.session_stack = session_stack2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.user_info, 0);
        _os.write((Collection) this.session_stack, 1);
    }

    static {
        cache_session_stack.add(new SessionAtom());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.user_info = (UserInfo) _is.read((JceStruct) cache_user_info, 0, true);
        this.session_stack = (ArrayList) _is.read((Object) cache_session_stack, 1, true);
    }
}
