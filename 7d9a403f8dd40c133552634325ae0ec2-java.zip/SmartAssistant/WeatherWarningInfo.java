package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class WeatherWarningInfo extends JceStruct {
    public String sAlarmLeveNum = "";
    public String sAlarmTypeNum = "";
    public String sAlertId = "";
    public String sCity = "";
    public String sCityId = "";
    public String sContent = "";
    public String sIssueTime = "";
    public String sLevel = "";
    public String sLinkSuffix = "";
    public String sProvince = "";
    public String sStation = "";
    public String sTitle = "";
    public String sType = "";

    public WeatherWarningInfo() {
    }

    public WeatherWarningInfo(String sCityId2, String sProvince2, String sCity2, String sStation2, String sType2, String sLevel2, String sIssueTime2, String sTitle2, String sContent2, String sAlertId2, String sAlarmTypeNum2, String sAlarmLeveNum2, String sLinkSuffix2) {
        this.sCityId = sCityId2;
        this.sProvince = sProvince2;
        this.sCity = sCity2;
        this.sStation = sStation2;
        this.sType = sType2;
        this.sLevel = sLevel2;
        this.sIssueTime = sIssueTime2;
        this.sTitle = sTitle2;
        this.sContent = sContent2;
        this.sAlertId = sAlertId2;
        this.sAlarmTypeNum = sAlarmTypeNum2;
        this.sAlarmLeveNum = sAlarmLeveNum2;
        this.sLinkSuffix = sLinkSuffix2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sCityId != null) {
            _os.write(this.sCityId, 0);
        }
        if (this.sProvince != null) {
            _os.write(this.sProvince, 1);
        }
        if (this.sCity != null) {
            _os.write(this.sCity, 2);
        }
        if (this.sStation != null) {
            _os.write(this.sStation, 3);
        }
        if (this.sType != null) {
            _os.write(this.sType, 4);
        }
        if (this.sLevel != null) {
            _os.write(this.sLevel, 5);
        }
        if (this.sIssueTime != null) {
            _os.write(this.sIssueTime, 6);
        }
        if (this.sTitle != null) {
            _os.write(this.sTitle, 7);
        }
        if (this.sContent != null) {
            _os.write(this.sContent, 8);
        }
        if (this.sAlertId != null) {
            _os.write(this.sAlertId, 9);
        }
        if (this.sAlarmTypeNum != null) {
            _os.write(this.sAlarmTypeNum, 10);
        }
        if (this.sAlarmLeveNum != null) {
            _os.write(this.sAlarmLeveNum, 11);
        }
        if (this.sLinkSuffix != null) {
            _os.write(this.sLinkSuffix, 12);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sCityId = _is.readString(0, false);
        this.sProvince = _is.readString(1, false);
        this.sCity = _is.readString(2, false);
        this.sStation = _is.readString(3, false);
        this.sType = _is.readString(4, false);
        this.sLevel = _is.readString(5, false);
        this.sIssueTime = _is.readString(6, false);
        this.sTitle = _is.readString(7, false);
        this.sContent = _is.readString(8, false);
        this.sAlertId = _is.readString(9, false);
        this.sAlarmTypeNum = _is.readString(10, false);
        this.sAlarmLeveNum = _is.readString(11, false);
        this.sLinkSuffix = _is.readString(12, false);
    }
}
