package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class stBinData extends JceStruct {
    static byte[] cache_binData = new byte[1];
    public byte[] binData = null;
    public String sDataCls = "";

    public stBinData() {
    }

    public stBinData(String sDataCls2, byte[] binData2) {
        this.sDataCls = sDataCls2;
        this.binData = binData2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sDataCls != null) {
            _os.write(this.sDataCls, 0);
        }
        if (this.binData != null) {
            _os.write(this.binData, 1);
        }
    }

    static {
        cache_binData[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sDataCls = _is.readString(0, false);
        this.binData = _is.read(cache_binData, 1, false);
    }
}
