package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyLiveIndexInfo extends JceStruct {
    public int iType = 0;
    public String sDesc = "";
    public String sLevel = "";
    public String sName = "";

    public DobbyLiveIndexInfo() {
    }

    public DobbyLiveIndexInfo(int iType2, String sName2, String sDesc2, String sLevel2) {
        this.iType = iType2;
        this.sName = sName2;
        this.sDesc = sDesc2;
        this.sLevel = sLevel2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iType, 0);
        if (this.sName != null) {
            _os.write(this.sName, 1);
        }
        if (this.sDesc != null) {
            _os.write(this.sDesc, 2);
        }
        if (this.sLevel != null) {
            _os.write(this.sLevel, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iType = _is.read(this.iType, 0, false);
        this.sName = _is.readString(1, false);
        this.sDesc = _is.readString(2, false);
        this.sLevel = _is.readString(3, false);
    }
}
