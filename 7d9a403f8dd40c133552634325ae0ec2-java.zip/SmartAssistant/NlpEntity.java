package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NlpEntity extends JceStruct {
    public String entity_name = "";
    public boolean is_coreference = false;
    public int offset = 0;
    public String text = "";
    public String value = "";

    public NlpEntity() {
    }

    public NlpEntity(String text2, int offset2, String value2, String entity_name2, boolean is_coreference2) {
        this.text = text2;
        this.offset = offset2;
        this.value = value2;
        this.entity_name = entity_name2;
        this.is_coreference = is_coreference2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.text, 0);
        _os.write(this.offset, 1);
        _os.write(this.value, 2);
        _os.write(this.entity_name, 3);
        _os.write(this.is_coreference, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.text = _is.readString(0, true);
        this.offset = _is.read(this.offset, 1, true);
        this.value = _is.readString(2, true);
        this.entity_name = _is.readString(3, true);
        this.is_coreference = _is.read(this.is_coreference, 4, false);
    }
}
