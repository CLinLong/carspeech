package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyMaxMin extends JceStruct {
    public float fAvg = 0.0f;
    public float fCurrent = 0.0f;
    public float fMax = 0.0f;
    public float fMin = 0.0f;

    public DobbyMaxMin() {
    }

    public DobbyMaxMin(float fMax2, float fAvg2, float fMin2, float fCurrent2) {
        this.fMax = fMax2;
        this.fAvg = fAvg2;
        this.fMin = fMin2;
        this.fCurrent = fCurrent2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.fMax, 0);
        _os.write(this.fAvg, 1);
        _os.write(this.fMin, 2);
        _os.write(this.fCurrent, 3);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.fMax = _is.read(this.fMax, 0, false);
        this.fAvg = _is.read(this.fAvg, 1, false);
        this.fMin = _is.read(this.fMin, 2, false);
        this.fCurrent = _is.read(this.fCurrent, 3, false);
    }
}
