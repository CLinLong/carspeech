package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class UpdateResponse extends JceStruct {
    public String message = "";
    public int return_type = 0;

    public UpdateResponse() {
    }

    public UpdateResponse(int return_type2, String message2) {
        this.return_type = return_type2;
        this.message = message2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.return_type, 0);
        if (this.message != null) {
            _os.write(this.message, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.return_type = _is.read(this.return_type, 0, false);
        this.message = _is.readString(1, false);
    }
}
