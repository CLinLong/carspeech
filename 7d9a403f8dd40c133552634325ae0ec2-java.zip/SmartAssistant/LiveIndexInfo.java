package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class LiveIndexInfo extends JceStruct {
    public int iCode = 0;
    public String sDay = "";
    public String sDesc = "";
    public String sLevel = "";
    public String sName = "";
    public String sStatus = "";
    public String sUrl = "";

    public LiveIndexInfo() {
    }

    public LiveIndexInfo(int iCode2, String sDay2, String sDesc2, String sLevel2, String sName2, String sStatus2, String sUrl2) {
        this.iCode = iCode2;
        this.sDay = sDay2;
        this.sDesc = sDesc2;
        this.sLevel = sLevel2;
        this.sName = sName2;
        this.sStatus = sStatus2;
        this.sUrl = sUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iCode, 0);
        if (this.sDay != null) {
            _os.write(this.sDay, 1);
        }
        if (this.sDesc != null) {
            _os.write(this.sDesc, 2);
        }
        if (this.sLevel != null) {
            _os.write(this.sLevel, 3);
        }
        if (this.sName != null) {
            _os.write(this.sName, 4);
        }
        if (this.sStatus != null) {
            _os.write(this.sStatus, 5);
        }
        if (this.sUrl != null) {
            _os.write(this.sUrl, 6);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iCode = _is.read(this.iCode, 0, false);
        this.sDay = _is.readString(1, false);
        this.sDesc = _is.readString(2, false);
        this.sLevel = _is.readString(3, false);
        this.sName = _is.readString(4, false);
        this.sStatus = _is.readString(5, false);
        this.sUrl = _is.readString(6, false);
    }
}
