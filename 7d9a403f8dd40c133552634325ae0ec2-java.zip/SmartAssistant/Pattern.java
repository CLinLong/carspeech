package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public final class Pattern extends JceStruct {
    static Map<String, ArrayList<NlpEntity>> cache_params = new HashMap();
    static int cache_type = 0;
    public String domain = "";
    public String intent = "";
    public boolean is_valid = true;
    public String matched_info = "";
    public Map<String, ArrayList<NlpEntity>> params = null;
    public String pattern = "";
    public float sim = 0.0f;
    public String sparql = "";
    public int type = 0;

    public Pattern() {
    }

    public Pattern(String pattern2, String domain2, String intent2, int type2, Map<String, ArrayList<NlpEntity>> params2, float sim2, boolean is_valid2, String matched_info2, String sparql2) {
        this.pattern = pattern2;
        this.domain = domain2;
        this.intent = intent2;
        this.type = type2;
        this.params = params2;
        this.sim = sim2;
        this.is_valid = is_valid2;
        this.matched_info = matched_info2;
        this.sparql = sparql2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.pattern != null) {
            _os.write(this.pattern, 0);
        }
        if (this.domain != null) {
            _os.write(this.domain, 1);
        }
        if (this.intent != null) {
            _os.write(this.intent, 2);
        }
        _os.write(this.type, 3);
        if (this.params != null) {
            _os.write((Map) this.params, 4);
        }
        _os.write(this.sim, 5);
        _os.write(this.is_valid, 6);
        if (this.matched_info != null) {
            _os.write(this.matched_info, 7);
        }
        if (this.sparql != null) {
            _os.write(this.sparql, 8);
        }
    }

    static {
        ArrayList<NlpEntity> __var_19 = new ArrayList<>();
        __var_19.add(new NlpEntity());
        cache_params.put("", __var_19);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.pattern = _is.readString(0, false);
        this.domain = _is.readString(1, false);
        this.intent = _is.readString(2, false);
        this.type = _is.read(this.type, 3, false);
        this.params = (Map) _is.read((Object) cache_params, 4, false);
        this.sim = _is.read(this.sim, 5, false);
        this.is_valid = _is.read(this.is_valid, 6, false);
        this.matched_info = _is.readString(7, false);
        this.sparql = _is.readString(8, false);
    }
}
