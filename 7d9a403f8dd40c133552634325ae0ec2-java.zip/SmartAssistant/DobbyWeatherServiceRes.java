package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class DobbyWeatherServiceRes extends JceStruct {
    static int cache_eAction = 0;
    static ArrayList<DobbyCityWeatherInfo> cache_vecCityWeatherInfo = new ArrayList<>();
    public int eAction = 0;
    public int iRet = 0;
    public String sError = "";
    public String sPlace = "";
    public ArrayList<DobbyCityWeatherInfo> vecCityWeatherInfo = null;

    public DobbyWeatherServiceRes() {
    }

    public DobbyWeatherServiceRes(int iRet2, String sError2, String sPlace2, int eAction2, ArrayList<DobbyCityWeatherInfo> vecCityWeatherInfo2) {
        this.iRet = iRet2;
        this.sError = sError2;
        this.sPlace = sPlace2;
        this.eAction = eAction2;
        this.vecCityWeatherInfo = vecCityWeatherInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iRet, 0);
        if (this.sError != null) {
            _os.write(this.sError, 1);
        }
        if (this.sPlace != null) {
            _os.write(this.sPlace, 2);
        }
        _os.write(this.eAction, 3);
        if (this.vecCityWeatherInfo != null) {
            _os.write((Collection) this.vecCityWeatherInfo, 4);
        }
    }

    static {
        cache_vecCityWeatherInfo.add(new DobbyCityWeatherInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iRet = _is.read(this.iRet, 0, false);
        this.sError = _is.readString(1, false);
        this.sPlace = _is.readString(2, false);
        this.eAction = _is.read(this.eAction, 3, false);
        this.vecCityWeatherInfo = (ArrayList) _is.read((Object) cache_vecCityWeatherInfo, 4, false);
    }
}
