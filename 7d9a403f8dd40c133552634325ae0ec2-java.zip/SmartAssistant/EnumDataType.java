package SmartAssistant;

import java.io.Serializable;

public final class EnumDataType implements Serializable {
    public static final int _DATA_SLOT = 1;
    public static final int _DATA_TEXT = 0;
}
