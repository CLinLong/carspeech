package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class RequestBase extends JceStruct {
    public String access_token = "";
    public String app_key = "";
    public long timestamp = 0;
    public String user_id = "";

    public RequestBase() {
    }

    public RequestBase(String app_key2, String access_token2, String user_id2, long timestamp2) {
        this.app_key = app_key2;
        this.access_token = access_token2;
        this.user_id = user_id2;
        this.timestamp = timestamp2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.app_key, 0);
        _os.write(this.access_token, 1);
        _os.write(this.user_id, 2);
        _os.write(this.timestamp, 3);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.app_key = _is.readString(0, true);
        this.access_token = _is.readString(1, true);
        this.user_id = _is.readString(2, true);
        this.timestamp = _is.read(this.timestamp, 3, true);
    }
}
