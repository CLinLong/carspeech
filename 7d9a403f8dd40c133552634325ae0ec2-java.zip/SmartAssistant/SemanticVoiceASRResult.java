package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SemanticVoiceASRResult extends JceStruct {
    public float prob = 0.0f;
    public String text = "";

    public SemanticVoiceASRResult() {
    }

    public SemanticVoiceASRResult(String text2, float prob2) {
        this.text = text2;
        this.prob = prob2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.text, 0);
        _os.write(this.prob, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.text = _is.readString(0, true);
        this.prob = _is.read(this.prob, 1, true);
    }
}
