package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class stMeidaBaseItem extends JceStruct {
    public String sAlbum = "";
    public String sAlbumPic = "";
    public String sAlbumPubTime = "";
    public String sH5Url = "";
    public String sLyrics = "";
    public String sMedia = "";
    public String sMediaId = "";
    public String sMediaRichname = "";
    public String sPerson = "";
    public String sSource = "";
    public String sUrl = "";

    public stMeidaBaseItem() {
    }

    public stMeidaBaseItem(String sMediaId2, String sMedia2, String sPerson2, String sUrl2, String sSource2, String sAlbum2, String sAlbumPic2, String sAlbumPubTime2, String sH5Url2, String sMediaRichname2, String sLyrics2) {
        this.sMediaId = sMediaId2;
        this.sMedia = sMedia2;
        this.sPerson = sPerson2;
        this.sUrl = sUrl2;
        this.sSource = sSource2;
        this.sAlbum = sAlbum2;
        this.sAlbumPic = sAlbumPic2;
        this.sAlbumPubTime = sAlbumPubTime2;
        this.sH5Url = sH5Url2;
        this.sMediaRichname = sMediaRichname2;
        this.sLyrics = sLyrics2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sMediaId != null) {
            _os.write(this.sMediaId, 0);
        }
        if (this.sMedia != null) {
            _os.write(this.sMedia, 1);
        }
        if (this.sPerson != null) {
            _os.write(this.sPerson, 2);
        }
        if (this.sUrl != null) {
            _os.write(this.sUrl, 3);
        }
        if (this.sSource != null) {
            _os.write(this.sSource, 4);
        }
        if (this.sAlbum != null) {
            _os.write(this.sAlbum, 5);
        }
        if (this.sAlbumPic != null) {
            _os.write(this.sAlbumPic, 6);
        }
        if (this.sAlbumPubTime != null) {
            _os.write(this.sAlbumPubTime, 7);
        }
        if (this.sH5Url != null) {
            _os.write(this.sH5Url, 8);
        }
        if (this.sMediaRichname != null) {
            _os.write(this.sMediaRichname, 9);
        }
        if (this.sLyrics != null) {
            _os.write(this.sLyrics, 10);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sMediaId = _is.readString(0, false);
        this.sMedia = _is.readString(1, false);
        this.sPerson = _is.readString(2, false);
        this.sUrl = _is.readString(3, false);
        this.sSource = _is.readString(4, false);
        this.sAlbum = _is.readString(5, false);
        this.sAlbumPic = _is.readString(6, false);
        this.sAlbumPubTime = _is.readString(7, false);
        this.sH5Url = _is.readString(8, false);
        this.sMediaRichname = _is.readString(9, false);
        this.sLyrics = _is.readString(10, false);
    }
}
