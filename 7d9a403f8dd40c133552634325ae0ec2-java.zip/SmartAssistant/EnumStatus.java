package SmartAssistant;

import java.io.Serializable;

public final class EnumStatus implements Serializable {
    public static final int _RET_ERROR = -1;
    public static final int _RET_OK = 0;
}
