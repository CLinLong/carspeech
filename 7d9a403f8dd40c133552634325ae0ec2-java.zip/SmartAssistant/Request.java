package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.HashMap;
import java.util.Map;

public final class Request extends JceStruct {
    static Map<String, String> cache_data_slot = new HashMap();
    static int cache_data_type = 0;
    static RequestBase cache_request_base = new RequestBase();
    static UserBase cache_user_base = new UserBase();
    public Map<String, String> data_slot = null;
    public String data_text = "";
    public int data_type = 0;
    public boolean force_session_complete = false;
    public RequestBase request_base = null;
    public UserBase user_base = null;

    public Request() {
    }

    public Request(RequestBase request_base2, int data_type2, String data_text2, Map<String, String> data_slot2, UserBase user_base2, boolean force_session_complete2) {
        this.request_base = request_base2;
        this.data_type = data_type2;
        this.data_text = data_text2;
        this.data_slot = data_slot2;
        this.user_base = user_base2;
        this.force_session_complete = force_session_complete2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.request_base, 0);
        _os.write(this.data_type, 1);
        _os.write(this.data_text, 2);
        if (this.data_slot != null) {
            _os.write((Map) this.data_slot, 3);
        }
        if (this.user_base != null) {
            _os.write((JceStruct) this.user_base, 4);
        }
        _os.write(this.force_session_complete, 5);
    }

    static {
        cache_data_slot.put("", "");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.request_base = (RequestBase) _is.read((JceStruct) cache_request_base, 0, true);
        this.data_type = _is.read(this.data_type, 1, true);
        this.data_text = _is.readString(2, true);
        this.data_slot = (Map) _is.read((Object) cache_data_slot, 3, false);
        this.user_base = (UserBase) _is.read((JceStruct) cache_user_base, 4, false);
        this.force_session_complete = _is.read(this.force_session_complete, 5, false);
    }
}
