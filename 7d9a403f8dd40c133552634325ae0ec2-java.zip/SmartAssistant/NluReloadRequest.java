package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NluReloadRequest extends JceStruct {
    static ArrayList<String> cache_keys = new ArrayList<>();
    public ArrayList<String> keys = null;

    public NluReloadRequest() {
    }

    public NluReloadRequest(ArrayList<String> keys2) {
        this.keys = keys2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.keys != null) {
            _os.write((Collection) this.keys, 0);
        }
    }

    static {
        cache_keys.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.keys = (ArrayList) _is.read((Object) cache_keys, 0, false);
    }
}
