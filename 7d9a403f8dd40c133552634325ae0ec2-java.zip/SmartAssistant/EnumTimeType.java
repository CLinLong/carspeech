package SmartAssistant;

import java.io.Serializable;

public final class EnumTimeType implements Serializable {
    public static final int _DATETIME = 1;
    public static final int _DURATION = 3;
    public static final int _INTERVAL = 2;
    public static final int _REPEAT_DATETIME = 4;
}
