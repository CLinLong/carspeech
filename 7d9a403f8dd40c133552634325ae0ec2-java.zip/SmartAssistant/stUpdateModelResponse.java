package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.HashMap;
import java.util.Map;

public final class stUpdateModelResponse extends JceStruct {
    static Map<String, Boolean> cache_updateres = new HashMap();
    public Map<String, Boolean> updateres = null;

    public stUpdateModelResponse() {
    }

    public stUpdateModelResponse(Map<String, Boolean> updateres2) {
        this.updateres = updateres2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Map) this.updateres, 0);
    }

    static {
        cache_updateres.put("", false);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.updateres = (Map) _is.read((Object) cache_updateres, 0, true);
    }
}
