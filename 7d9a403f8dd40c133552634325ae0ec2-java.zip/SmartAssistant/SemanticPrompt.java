package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SemanticPrompt extends JceStruct {
    static int cache_prompt_type = 0;
    public int prompt_type = 0;
    public String show_text = "";
    public String slot_name = "";
    public String slot_type = "";
    public String speak_text = "";

    public SemanticPrompt() {
    }

    public SemanticPrompt(String show_text2, String speak_text2, int prompt_type2, String slot_name2, String slot_type2) {
        this.show_text = show_text2;
        this.speak_text = speak_text2;
        this.prompt_type = prompt_type2;
        this.slot_name = slot_name2;
        this.slot_type = slot_type2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.show_text, 0);
        _os.write(this.speak_text, 1);
        _os.write(this.prompt_type, 2);
        if (this.slot_name != null) {
            _os.write(this.slot_name, 3);
        }
        if (this.slot_type != null) {
            _os.write(this.slot_type, 4);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.show_text = _is.readString(0, true);
        this.speak_text = _is.readString(1, true);
        this.prompt_type = _is.read(this.prompt_type, 2, false);
        this.slot_name = _is.readString(3, false);
        this.slot_type = _is.readString(4, false);
    }
}
