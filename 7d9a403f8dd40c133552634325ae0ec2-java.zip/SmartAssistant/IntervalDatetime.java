package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class IntervalDatetime extends JceStruct {
    static Datetime cache_end = new Datetime();
    static Datetime cache_start = new Datetime();
    public Datetime end = null;
    public Datetime start = null;

    public IntervalDatetime() {
    }

    public IntervalDatetime(Datetime start2, Datetime end2) {
        this.start = start2;
        this.end = end2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.start != null) {
            _os.write((JceStruct) this.start, 0);
        }
        if (this.end != null) {
            _os.write((JceStruct) this.end, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.start = (Datetime) _is.read((JceStruct) cache_start, 0, false);
        this.end = (Datetime) _is.read((JceStruct) cache_end, 1, false);
    }
}
