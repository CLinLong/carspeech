package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SemanticServerLog extends JceStruct {
    static ArrayList<SemanticDetail> cache_details = new ArrayList<>();
    public String debug_log = "";
    public ArrayList<SemanticDetail> details = null;
    public String raw_log = "";

    public SemanticServerLog() {
    }

    public SemanticServerLog(ArrayList<SemanticDetail> details2, String raw_log2, String debug_log2) {
        this.details = details2;
        this.raw_log = raw_log2;
        this.debug_log = debug_log2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.details != null) {
            _os.write((Collection) this.details, 0);
        }
        if (this.raw_log != null) {
            _os.write(this.raw_log, 1);
        }
        if (this.debug_log != null) {
            _os.write(this.debug_log, 2);
        }
    }

    static {
        cache_details.add(new SemanticDetail());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.details = (ArrayList) _is.read((Object) cache_details, 0, false);
        this.raw_log = _is.readString(1, false);
        this.debug_log = _is.readString(2, false);
    }
}
