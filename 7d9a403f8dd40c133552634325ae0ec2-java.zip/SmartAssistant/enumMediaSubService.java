package SmartAssistant;

import java.io.Serializable;

public final class enumMediaSubService implements Serializable {
    public static final int _E_MEDIA_SUB_SERVICE_FM = 2;
    public static final int _E_MEDIA_SUB_SERVICE_MUSIC = 1;
    public static final int _E_MEDIA_SUB_SERVICE_RADIO = 3;
    public static final int _E_MEDIA_SUB_SERVICE_UNKNOWN = 0;
}
