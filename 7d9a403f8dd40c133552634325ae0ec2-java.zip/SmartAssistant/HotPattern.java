package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class HotPattern extends JceStruct {
    static ArrayList<Answer> cache_answers = new ArrayList<>();
    public ArrayList<Answer> answers = null;
    public String query = "";

    public HotPattern() {
    }

    public HotPattern(String query2, ArrayList<Answer> answers2) {
        this.query = query2;
        this.answers = answers2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.query != null) {
            _os.write(this.query, 0);
        }
        if (this.answers != null) {
            _os.write((Collection) this.answers, 1);
        }
    }

    static {
        cache_answers.add(new Answer());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.query = _is.readString(0, false);
        this.answers = (ArrayList) _is.read((Object) cache_answers, 1, false);
    }
}
