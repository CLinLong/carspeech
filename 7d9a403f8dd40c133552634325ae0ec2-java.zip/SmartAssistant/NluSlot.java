package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NluSlot extends JceStruct {
    static int cache_value_type = 0;
    static ArrayList<byte[]> cache_values_jce = new ArrayList<>();
    static ArrayList<String> cache_values_json = new ArrayList<>();
    public String name = "";
    public String type = "";
    public int value_type = 0;
    public ArrayList<byte[]> values_jce = null;
    public ArrayList<String> values_json = null;

    public NluSlot() {
    }

    public NluSlot(String name2, String type2, int value_type2, ArrayList<byte[]> values_jce2, ArrayList<String> values_json2) {
        this.name = name2;
        this.type = type2;
        this.value_type = value_type2;
        this.values_jce = values_jce2;
        this.values_json = values_json2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.name != null) {
            _os.write(this.name, 0);
        }
        if (this.type != null) {
            _os.write(this.type, 1);
        }
        _os.write(this.value_type, 2);
        if (this.values_jce != null) {
            _os.write((Collection) this.values_jce, 3);
        }
        if (this.values_json != null) {
            _os.write((Collection) this.values_json, 4);
        }
    }

    static {
        byte[] __var_2 = new byte[1];
        __var_2[0] = 0;
        cache_values_jce.add(__var_2);
        cache_values_json.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.name = _is.readString(0, false);
        this.type = _is.readString(1, false);
        this.value_type = _is.read(this.value_type, 2, false);
        this.values_jce = (ArrayList) _is.read((Object) cache_values_jce, 3, false);
        this.values_json = (ArrayList) _is.read((Object) cache_values_json, 4, false);
    }
}
