package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class UserBase extends JceStruct {
    static ChatBot cache_botType = new ChatBot();
    static byte[] cache_sGUID = new byte[1];
    static byte[] cache_sMac = new byte[1];
    static byte[] cache_vLBSKeyData = new byte[1];
    static ArrayList<Long> cache_vWifiMacs = new ArrayList<>();
    public boolean bSave = true;
    public ChatBot botType = null;
    public short iMCC = 0;
    public short iMNC = 0;
    public String sAPN = "";
    public String sAdId = "";
    public String sCellNumber = "";
    public String sCellid = "";
    public String sCellphone = "";
    public String sChannel = "";
    public String sFirstChannel = "";
    public byte[] sGUID = null;
    public String sIMEI = "";
    public String sIP = "";
    public String sLAC = "";
    public String sLC = "";
    public byte[] sMac = null;
    public String sQUA2 = "";
    public String sUA = "";
    public String sUin = "";
    public String sVenderId = "";
    public byte[] vLBSKeyData = null;
    public ArrayList<Long> vWifiMacs = null;

    public UserBase() {
    }

    public UserBase(String sIMEI2, byte[] sGUID2, String sLC2, String sCellphone2, String sUin2, String sCellid2, boolean bSave2, String sChannel2, String sLAC2, String sUA2, short iMCC2, short iMNC2, String sAPN2, String sCellNumber2, byte[] sMac2, ArrayList<Long> vWifiMacs2, byte[] vLBSKeyData2, String sVenderId2, String sAdId2, String sFirstChannel2, String sQUA22, String sIP2, ChatBot botType2) {
        this.sIMEI = sIMEI2;
        this.sGUID = sGUID2;
        this.sLC = sLC2;
        this.sCellphone = sCellphone2;
        this.sUin = sUin2;
        this.sCellid = sCellid2;
        this.bSave = bSave2;
        this.sChannel = sChannel2;
        this.sLAC = sLAC2;
        this.sUA = sUA2;
        this.iMCC = iMCC2;
        this.iMNC = iMNC2;
        this.sAPN = sAPN2;
        this.sCellNumber = sCellNumber2;
        this.sMac = sMac2;
        this.vWifiMacs = vWifiMacs2;
        this.vLBSKeyData = vLBSKeyData2;
        this.sVenderId = sVenderId2;
        this.sAdId = sAdId2;
        this.sFirstChannel = sFirstChannel2;
        this.sQUA2 = sQUA22;
        this.sIP = sIP2;
        this.botType = botType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sIMEI, 0);
        _os.write(this.sGUID, 1);
        _os.write(this.sLC, 3);
        _os.write(this.sCellphone, 4);
        _os.write(this.sUin, 5);
        if (this.sCellid != null) {
            _os.write(this.sCellid, 6);
        }
        _os.write(this.bSave, 8);
        if (this.sChannel != null) {
            _os.write(this.sChannel, 9);
        }
        if (this.sLAC != null) {
            _os.write(this.sLAC, 10);
        }
        if (this.sUA != null) {
            _os.write(this.sUA, 11);
        }
        _os.write(this.iMCC, 13);
        _os.write(this.iMNC, 14);
        if (this.sAPN != null) {
            _os.write(this.sAPN, 15);
        }
        if (this.sCellNumber != null) {
            _os.write(this.sCellNumber, 16);
        }
        if (this.sMac != null) {
            _os.write(this.sMac, 17);
        }
        if (this.vWifiMacs != null) {
            _os.write((Collection) this.vWifiMacs, 19);
        }
        if (this.vLBSKeyData != null) {
            _os.write(this.vLBSKeyData, 20);
        }
        if (this.sVenderId != null) {
            _os.write(this.sVenderId, 21);
        }
        if (this.sAdId != null) {
            _os.write(this.sAdId, 22);
        }
        if (this.sFirstChannel != null) {
            _os.write(this.sFirstChannel, 23);
        }
        if (this.sQUA2 != null) {
            _os.write(this.sQUA2, 24);
        }
        if (this.sIP != null) {
            _os.write(this.sIP, 25);
        }
        if (this.botType != null) {
            _os.write((JceStruct) this.botType, 26);
        }
    }

    static {
        cache_sGUID[0] = 0;
        cache_sMac[0] = 0;
        cache_vWifiMacs.add(0L);
        cache_vLBSKeyData[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sIMEI = _is.readString(0, true);
        this.sGUID = _is.read(cache_sGUID, 1, true);
        this.sLC = _is.readString(3, true);
        this.sCellphone = _is.readString(4, true);
        this.sUin = _is.readString(5, true);
        this.sCellid = _is.readString(6, false);
        this.bSave = _is.read(this.bSave, 8, false);
        this.sChannel = _is.readString(9, false);
        this.sLAC = _is.readString(10, false);
        this.sUA = _is.readString(11, false);
        this.iMCC = _is.read(this.iMCC, 13, false);
        this.iMNC = _is.read(this.iMNC, 14, false);
        this.sAPN = _is.readString(15, false);
        this.sCellNumber = _is.readString(16, false);
        this.sMac = _is.read(cache_sMac, 17, false);
        this.vWifiMacs = (ArrayList) _is.read((Object) cache_vWifiMacs, 19, false);
        this.vLBSKeyData = _is.read(cache_vLBSKeyData, 20, false);
        this.sVenderId = _is.readString(21, false);
        this.sAdId = _is.readString(22, false);
        this.sFirstChannel = _is.readString(23, false);
        this.sQUA2 = _is.readString(24, false);
        this.sIP = _is.readString(25, false);
        this.botType = (ChatBot) _is.read((JceStruct) cache_botType, 26, false);
    }
}
