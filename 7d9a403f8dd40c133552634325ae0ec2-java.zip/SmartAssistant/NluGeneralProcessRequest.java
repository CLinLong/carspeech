package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NluGeneralProcessRequest extends JceStruct {
    public String query = "";

    public NluGeneralProcessRequest() {
    }

    public NluGeneralProcessRequest(String query2) {
        this.query = query2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.query != null) {
            _os.write(this.query, 0);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.query = _is.readString(0, false);
    }
}
