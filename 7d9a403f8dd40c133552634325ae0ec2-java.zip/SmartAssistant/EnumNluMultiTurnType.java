package SmartAssistant;

import java.io.Serializable;

public final class EnumNluMultiTurnType implements Serializable {
    public static final int _NLU_MULTI_TURN_CONFIRMATION = 3;
    public static final int _NLU_MULTI_TURN_NONE = 0;
    public static final int _NLU_MULTI_TURN_SELECTION = 2;
    public static final int _NLU_MULTI_TURN_SLOT_FILLING = 1;
}
