package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class FmBaseItem extends JceStruct {
    static int cache_eShowType = 0;
    public int eShowType = 0;
    public String sAlbum = "";
    public String sAlbumId = "";
    public String sAnchor = "";
    public String sArea = "";
    public String sCoverUrl = "";
    public String sShowId = "";
    public String sShowName = "";
    public String sSource = "";
    public String sUrl = "";

    public FmBaseItem() {
    }

    public FmBaseItem(String sShowId2, String sShowName2, String sAnchor2, String sUrl2, String sSource2, String sAlbum2, String sCoverUrl2, String sAlbumId2, String sArea2, int eShowType2) {
        this.sShowId = sShowId2;
        this.sShowName = sShowName2;
        this.sAnchor = sAnchor2;
        this.sUrl = sUrl2;
        this.sSource = sSource2;
        this.sAlbum = sAlbum2;
        this.sCoverUrl = sCoverUrl2;
        this.sAlbumId = sAlbumId2;
        this.sArea = sArea2;
        this.eShowType = eShowType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sShowId != null) {
            _os.write(this.sShowId, 0);
        }
        if (this.sShowName != null) {
            _os.write(this.sShowName, 1);
        }
        if (this.sAnchor != null) {
            _os.write(this.sAnchor, 2);
        }
        if (this.sUrl != null) {
            _os.write(this.sUrl, 3);
        }
        if (this.sSource != null) {
            _os.write(this.sSource, 4);
        }
        if (this.sAlbum != null) {
            _os.write(this.sAlbum, 5);
        }
        if (this.sCoverUrl != null) {
            _os.write(this.sCoverUrl, 6);
        }
        if (this.sAlbumId != null) {
            _os.write(this.sAlbumId, 7);
        }
        if (this.sArea != null) {
            _os.write(this.sArea, 8);
        }
        _os.write(this.eShowType, 9);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sShowId = _is.readString(0, false);
        this.sShowName = _is.readString(1, false);
        this.sAnchor = _is.readString(2, false);
        this.sUrl = _is.readString(3, false);
        this.sSource = _is.readString(4, false);
        this.sAlbum = _is.readString(5, false);
        this.sCoverUrl = _is.readString(6, false);
        this.sAlbumId = _is.readString(7, false);
        this.sArea = _is.readString(8, false);
        this.eShowType = _is.read(this.eShowType, 9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        FmBaseItem temp = (FmBaseItem) a.parseObject(text, FmBaseItem.class);
        this.sShowId = temp.sShowId;
        this.sShowName = temp.sShowName;
        this.sAnchor = temp.sAnchor;
        this.sUrl = temp.sUrl;
        this.sSource = temp.sSource;
        this.sAlbum = temp.sAlbum;
        this.sCoverUrl = temp.sCoverUrl;
        this.sAlbumId = temp.sAlbumId;
        this.sArea = temp.sArea;
        this.eShowType = temp.eShowType;
    }
}
