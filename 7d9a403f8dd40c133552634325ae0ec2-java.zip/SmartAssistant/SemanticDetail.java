package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SemanticDetail extends JceStruct {
    static ArrayList<SemanticSlot> cache_slots = new ArrayList<>();
    public String domain = "";
    public String intent = "";
    public String matched_pattern = "";
    public String query = "";
    public float score = 0.0f;
    public boolean session_complete = true;
    public ArrayList<SemanticSlot> slots = null;

    public SemanticDetail() {
    }

    public SemanticDetail(String query2, String domain2, String intent2, ArrayList<SemanticSlot> slots2, boolean session_complete2, String matched_pattern2, float score2) {
        this.query = query2;
        this.domain = domain2;
        this.intent = intent2;
        this.slots = slots2;
        this.session_complete = session_complete2;
        this.matched_pattern = matched_pattern2;
        this.score = score2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.query, 0);
        if (this.domain != null) {
            _os.write(this.domain, 1);
        }
        if (this.intent != null) {
            _os.write(this.intent, 2);
        }
        if (this.slots != null) {
            _os.write((Collection) this.slots, 3);
        }
        _os.write(this.session_complete, 4);
        if (this.matched_pattern != null) {
            _os.write(this.matched_pattern, 5);
        }
        _os.write(this.score, 6);
    }

    static {
        cache_slots.add(new SemanticSlot());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.query = _is.readString(0, true);
        this.domain = _is.readString(1, false);
        this.intent = _is.readString(2, false);
        this.slots = (ArrayList) _is.read((Object) cache_slots, 3, false);
        this.session_complete = _is.read(this.session_complete, 4, false);
        this.matched_pattern = _is.readString(5, false);
        this.score = _is.read(this.score, 6, false);
    }
}
