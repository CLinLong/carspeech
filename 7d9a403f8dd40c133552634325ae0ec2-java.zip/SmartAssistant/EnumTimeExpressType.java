package SmartAssistant;

import java.io.Serializable;

public final class EnumTimeExpressType implements Serializable {
    public static final int _BIAS_TIME = 2;
    public static final int _LUNAR_TIME = 5;
    public static final int _NEXT_PREV_TIME = 3;
    public static final int _NORMAL_TIME = 1;
    public static final int _WEEK_TIME = 4;
}
