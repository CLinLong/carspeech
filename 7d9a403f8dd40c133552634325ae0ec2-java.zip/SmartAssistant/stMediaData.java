package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class stMediaData extends JceStruct {
    static ArrayList<stMediaDataItem> cache_vActionList = new ArrayList<>();
    public ArrayList<stMediaDataItem> vActionList = null;

    public stMediaData() {
    }

    public stMediaData(ArrayList<stMediaDataItem> vActionList2) {
        this.vActionList = vActionList2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vActionList != null) {
            _os.write((Collection) this.vActionList, 0);
        }
    }

    static {
        cache_vActionList.add(new stMediaDataItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vActionList = (ArrayList) _is.read((Object) cache_vActionList, 0, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        this.vActionList = ((stMediaData) a.parseObject(text, stMediaData.class)).vActionList;
    }
}
