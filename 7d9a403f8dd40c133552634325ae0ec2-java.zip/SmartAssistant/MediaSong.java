package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class MediaSong extends JceStruct {
    static ArrayList<String> cache_vAges = new ArrayList<>();
    static ArrayList<String> cache_vEmotions = new ArrayList<>();
    static ArrayList<String> cache_vInstruments = new ArrayList<>();
    static ArrayList<String> cache_vLanguages = new ArrayList<>();
    static ArrayList<String> cache_vNames = new ArrayList<>();
    static ArrayList<String> cache_vOperas = new ArrayList<>();
    static ArrayList<String> cache_vScenes = new ArrayList<>();
    static ArrayList<String> cache_vStyles = new ArrayList<>();
    static ArrayList<String> cache_vThemes = new ArrayList<>();
    public ArrayList<String> vAges = null;
    public ArrayList<String> vEmotions = null;
    public ArrayList<String> vInstruments = null;
    public ArrayList<String> vLanguages = null;
    public ArrayList<String> vNames = null;
    public ArrayList<String> vOperas = null;
    public ArrayList<String> vScenes = null;
    public ArrayList<String> vStyles = null;
    public ArrayList<String> vThemes = null;

    public MediaSong() {
    }

    public MediaSong(ArrayList<String> vNames2, ArrayList<String> vLanguages2, ArrayList<String> vThemes2, ArrayList<String> vAges2, ArrayList<String> vInstruments2, ArrayList<String> vScenes2, ArrayList<String> vStyles2, ArrayList<String> vEmotions2, ArrayList<String> vOperas2) {
        this.vNames = vNames2;
        this.vLanguages = vLanguages2;
        this.vThemes = vThemes2;
        this.vAges = vAges2;
        this.vInstruments = vInstruments2;
        this.vScenes = vScenes2;
        this.vStyles = vStyles2;
        this.vEmotions = vEmotions2;
        this.vOperas = vOperas2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vNames != null) {
            _os.write((Collection) this.vNames, 0);
        }
        if (this.vLanguages != null) {
            _os.write((Collection) this.vLanguages, 1);
        }
        if (this.vThemes != null) {
            _os.write((Collection) this.vThemes, 2);
        }
        if (this.vAges != null) {
            _os.write((Collection) this.vAges, 3);
        }
        if (this.vInstruments != null) {
            _os.write((Collection) this.vInstruments, 4);
        }
        if (this.vScenes != null) {
            _os.write((Collection) this.vScenes, 5);
        }
        if (this.vStyles != null) {
            _os.write((Collection) this.vStyles, 6);
        }
        if (this.vEmotions != null) {
            _os.write((Collection) this.vEmotions, 7);
        }
        if (this.vOperas != null) {
            _os.write((Collection) this.vOperas, 8);
        }
    }

    static {
        cache_vNames.add("");
        cache_vLanguages.add("");
        cache_vThemes.add("");
        cache_vAges.add("");
        cache_vInstruments.add("");
        cache_vScenes.add("");
        cache_vStyles.add("");
        cache_vEmotions.add("");
        cache_vOperas.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vNames = (ArrayList) _is.read((Object) cache_vNames, 0, false);
        this.vLanguages = (ArrayList) _is.read((Object) cache_vLanguages, 1, false);
        this.vThemes = (ArrayList) _is.read((Object) cache_vThemes, 2, false);
        this.vAges = (ArrayList) _is.read((Object) cache_vAges, 3, false);
        this.vInstruments = (ArrayList) _is.read((Object) cache_vInstruments, 4, false);
        this.vScenes = (ArrayList) _is.read((Object) cache_vScenes, 5, false);
        this.vStyles = (ArrayList) _is.read((Object) cache_vStyles, 6, false);
        this.vEmotions = (ArrayList) _is.read((Object) cache_vEmotions, 7, false);
        this.vOperas = (ArrayList) _is.read((Object) cache_vOperas, 8, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        MediaSong temp = (MediaSong) a.parseObject(text, MediaSong.class);
        this.vNames = temp.vNames;
        this.vLanguages = temp.vLanguages;
        this.vThemes = temp.vThemes;
        this.vAges = temp.vAges;
        this.vInstruments = temp.vInstruments;
        this.vScenes = temp.vScenes;
        this.vStyles = temp.vStyles;
        this.vEmotions = temp.vEmotions;
        this.vOperas = temp.vOperas;
    }
}
