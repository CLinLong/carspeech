package SmartAssistant;

import java.io.Serializable;

public final class EnumNluTurnType implements Serializable {
    public static final int _NLU_TURN_APPEND = 2;
    public static final int _NLU_TURN_EXPLICIT = 3;
    public static final int _NLU_TURN_MULTI = 1;
    public static final int _NLU_TURN_SINGLE = 0;
}
