package SmartAssistant;

import java.io.Serializable;

public final class UpdateType implements Serializable {
    public static final int _ADD = 1;
    public static final int _DELETE = 2;
    public static final int _UPDATE = 3;
}
