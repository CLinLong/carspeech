package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public final class NluGeneralProcessResponse extends JceStruct {
    static ArrayList<NlpTokenOccurence> cache_char_occurs = new ArrayList<>();
    static Map<String, ArrayList<NlpEntity>> cache_pre_entities = new HashMap();
    static ArrayList<NlpTokenOccurence> cache_token_occurs = new ArrayList<>();
    static ArrayList<NlpToken> cache_tokens = new ArrayList<>();
    public ArrayList<NlpTokenOccurence> char_occurs = null;
    public Map<String, ArrayList<NlpEntity>> pre_entities = null;
    public ArrayList<NlpTokenOccurence> token_occurs = null;
    public ArrayList<NlpToken> tokens = null;

    public NluGeneralProcessResponse() {
    }

    public NluGeneralProcessResponse(Map<String, ArrayList<NlpEntity>> pre_entities2, ArrayList<NlpTokenOccurence> token_occurs2, ArrayList<NlpTokenOccurence> char_occurs2, ArrayList<NlpToken> tokens2) {
        this.pre_entities = pre_entities2;
        this.token_occurs = token_occurs2;
        this.char_occurs = char_occurs2;
        this.tokens = tokens2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.pre_entities != null) {
            _os.write((Map) this.pre_entities, 0);
        }
        if (this.token_occurs != null) {
            _os.write((Collection) this.token_occurs, 1);
        }
        if (this.char_occurs != null) {
            _os.write((Collection) this.char_occurs, 2);
        }
        if (this.tokens != null) {
            _os.write((Collection) this.tokens, 3);
        }
    }

    static {
        ArrayList<NlpEntity> __var_13 = new ArrayList<>();
        __var_13.add(new NlpEntity());
        cache_pre_entities.put("", __var_13);
        cache_token_occurs.add(new NlpTokenOccurence());
        cache_char_occurs.add(new NlpTokenOccurence());
        cache_tokens.add(new NlpToken());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.pre_entities = (Map) _is.read((Object) cache_pre_entities, 0, false);
        this.token_occurs = (ArrayList) _is.read((Object) cache_token_occurs, 1, false);
        this.char_occurs = (ArrayList) _is.read((Object) cache_char_occurs, 2, false);
        this.tokens = (ArrayList) _is.read((Object) cache_tokens, 3, false);
    }
}
