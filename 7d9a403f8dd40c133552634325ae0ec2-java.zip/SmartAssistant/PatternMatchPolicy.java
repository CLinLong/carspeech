package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class PatternMatchPolicy extends JceStruct {
    static ArrayList<MatchDomainPolicy> cache_domain_policies = new ArrayList<>();
    public ArrayList<MatchDomainPolicy> domain_policies = null;

    public PatternMatchPolicy() {
    }

    public PatternMatchPolicy(ArrayList<MatchDomainPolicy> domain_policies2) {
        this.domain_policies = domain_policies2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.domain_policies != null) {
            _os.write((Collection) this.domain_policies, 0);
        }
    }

    static {
        cache_domain_policies.add(new MatchDomainPolicy());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.domain_policies = (ArrayList) _is.read((Object) cache_domain_policies, 0, false);
    }
}
