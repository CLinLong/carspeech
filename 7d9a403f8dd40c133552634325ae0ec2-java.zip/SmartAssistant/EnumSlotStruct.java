package SmartAssistant;

import java.io.Serializable;

public final class EnumSlotStruct implements Serializable {
    public static final int _SLOT_DATETIME = 0;
    public static final int _SLOT_ENTITY = 1;
    public static final int _SLOT_LOCATION = 2;
    public static final int _SLOT_NUMBER = 3;
}
