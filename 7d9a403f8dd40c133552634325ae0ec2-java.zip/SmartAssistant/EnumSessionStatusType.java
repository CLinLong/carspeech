package SmartAssistant;

import java.io.Serializable;

public final class EnumSessionStatusType implements Serializable {
    public static final int _ENUM_SESSION_STATUS_TYPE_OK = 0;
    public static final int _ENUM_SESSION_STATUS_TYPE_PROMPT = 2;
    public static final int _ENUM_SESSION_STATUS_TYPE_UNKNOWN = 1;
}
