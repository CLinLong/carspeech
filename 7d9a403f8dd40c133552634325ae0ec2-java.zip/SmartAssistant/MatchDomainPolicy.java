package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class MatchDomainPolicy extends JceStruct {
    static ArrayList<MatchIntentPolicy> cache_intent_policies = new ArrayList<>();
    public String domain_name = "";
    public ArrayList<MatchIntentPolicy> intent_policies = null;
    public int match_single_entity_type = 0;

    public MatchDomainPolicy() {
    }

    public MatchDomainPolicy(String domain_name2, ArrayList<MatchIntentPolicy> intent_policies2, int match_single_entity_type2) {
        this.domain_name = domain_name2;
        this.intent_policies = intent_policies2;
        this.match_single_entity_type = match_single_entity_type2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.domain_name != null) {
            _os.write(this.domain_name, 0);
        }
        if (this.intent_policies != null) {
            _os.write((Collection) this.intent_policies, 1);
        }
        _os.write(this.match_single_entity_type, 2);
    }

    static {
        cache_intent_policies.add(new MatchIntentPolicy());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.domain_name = _is.readString(0, false);
        this.intent_policies = (ArrayList) _is.read((Object) cache_intent_policies, 1, false);
        this.match_single_entity_type = _is.read(this.match_single_entity_type, 2, false);
    }
}
