package SmartAssistant;

import java.io.Serializable;

public final class EnumSemanticConfirmState implements Serializable {
    public static final int _ENUM_SEMANTIC_CONFIRM_STATE_NO = 2;
    public static final int _ENUM_SEMANTIC_CONFIRM_STATE_NONE = 0;
    public static final int _ENUM_SEMANTIC_CONFIRM_STATE_YES = 1;
}
