package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyChat extends JceStruct {
    public String sAnswer = "";
    public String sSpeak = "";
    public String sText = "";

    public DobbyChat() {
    }

    public DobbyChat(String sAnswer2, String sSpeak2, String sText2) {
        this.sAnswer = sAnswer2;
        this.sSpeak = sSpeak2;
        this.sText = sText2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sAnswer, 0);
        _os.write(this.sSpeak, 1);
        _os.write(this.sText, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAnswer = _is.readString(0, true);
        this.sSpeak = _is.readString(1, true);
        this.sText = _is.readString(2, true);
    }
}
