package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class MediaTranMusic extends JceStruct {
    static ArrayList<String> cache_vAlbums = new ArrayList<>();
    static ArrayList<String> cache_vSingers = new ArrayList<>();
    static ArrayList<MediaSong> cache_vSongs = new ArrayList<>();
    static ArrayList<String> cache_vToplists = new ArrayList<>();
    static ArrayList<String> cache_vTvFilms = new ArrayList<>();
    public ArrayList<String> vAlbums = null;
    public ArrayList<String> vSingers = null;
    public ArrayList<MediaSong> vSongs = null;
    public ArrayList<String> vToplists = null;
    public ArrayList<String> vTvFilms = null;

    public MediaTranMusic() {
    }

    public MediaTranMusic(ArrayList<String> vSingers2, ArrayList<MediaSong> vSongs2, ArrayList<String> vAlbums2, ArrayList<String> vTvFilms2, ArrayList<String> vToplists2) {
        this.vSingers = vSingers2;
        this.vSongs = vSongs2;
        this.vAlbums = vAlbums2;
        this.vTvFilms = vTvFilms2;
        this.vToplists = vToplists2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vSingers != null) {
            _os.write((Collection) this.vSingers, 0);
        }
        if (this.vSongs != null) {
            _os.write((Collection) this.vSongs, 1);
        }
        if (this.vAlbums != null) {
            _os.write((Collection) this.vAlbums, 2);
        }
        if (this.vTvFilms != null) {
            _os.write((Collection) this.vTvFilms, 3);
        }
        if (this.vToplists != null) {
            _os.write((Collection) this.vToplists, 4);
        }
    }

    static {
        cache_vSingers.add("");
        cache_vSongs.add(new MediaSong());
        cache_vAlbums.add("");
        cache_vTvFilms.add("");
        cache_vToplists.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vSingers = (ArrayList) _is.read((Object) cache_vSingers, 0, false);
        this.vSongs = (ArrayList) _is.read((Object) cache_vSongs, 1, false);
        this.vAlbums = (ArrayList) _is.read((Object) cache_vAlbums, 2, false);
        this.vTvFilms = (ArrayList) _is.read((Object) cache_vTvFilms, 3, false);
        this.vToplists = (ArrayList) _is.read((Object) cache_vToplists, 4, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        MediaTranMusic temp = (MediaTranMusic) a.parseObject(text, MediaTranMusic.class);
        this.vSingers = temp.vSingers;
        this.vSongs = temp.vSongs;
        this.vAlbums = temp.vAlbums;
        this.vTvFilms = temp.vTvFilms;
        this.vToplists = temp.vToplists;
    }
}
