package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class DobbyCityWeatherInfo extends JceStruct {
    static LiveIndex cache_stLiveIndex = new LiveIndex();
    static WeatherActivity cache_stWeatherActivity = new WeatherActivity();
    static ArrayList<WeatherWarningInfo> cache_vWeatherWarning = new ArrayList<>();
    static ArrayList<DobbyHourlyWeatherSimple> cache_vcHourlyWeatherInfo = new ArrayList<>();
    static ArrayList<DobbyWeatherSimple> cache_vcWeatherInfo = new ArrayList<>();
    public int iDayIndex = 0;
    public String sCityID = "";
    public String sCounty = "";
    public String sDisplayTips = "";
    public String sDistrict = "";
    public String sMoreUrl = "";
    public String sProvince = "";
    public String sWeatherTips = "";
    public LiveIndex stLiveIndex = null;
    public WeatherActivity stWeatherActivity = null;
    public ArrayList<WeatherWarningInfo> vWeatherWarning = null;
    public ArrayList<DobbyHourlyWeatherSimple> vcHourlyWeatherInfo = null;
    public ArrayList<DobbyWeatherSimple> vcWeatherInfo = null;

    public DobbyCityWeatherInfo() {
    }

    public DobbyCityWeatherInfo(String sCityID2, String sProvince2, String sDistrict2, String sCounty2, ArrayList<DobbyWeatherSimple> vcWeatherInfo2, int iDayIndex2, String sWeatherTips2, String sDisplayTips2, LiveIndex stLiveIndex2, ArrayList<WeatherWarningInfo> vWeatherWarning2, String sMoreUrl2, WeatherActivity stWeatherActivity2, ArrayList<DobbyHourlyWeatherSimple> vcHourlyWeatherInfo2) {
        this.sCityID = sCityID2;
        this.sProvince = sProvince2;
        this.sDistrict = sDistrict2;
        this.sCounty = sCounty2;
        this.vcWeatherInfo = vcWeatherInfo2;
        this.iDayIndex = iDayIndex2;
        this.sWeatherTips = sWeatherTips2;
        this.sDisplayTips = sDisplayTips2;
        this.stLiveIndex = stLiveIndex2;
        this.vWeatherWarning = vWeatherWarning2;
        this.sMoreUrl = sMoreUrl2;
        this.stWeatherActivity = stWeatherActivity2;
        this.vcHourlyWeatherInfo = vcHourlyWeatherInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sCityID != null) {
            _os.write(this.sCityID, 0);
        }
        if (this.sProvince != null) {
            _os.write(this.sProvince, 1);
        }
        if (this.sDistrict != null) {
            _os.write(this.sDistrict, 2);
        }
        if (this.sCounty != null) {
            _os.write(this.sCounty, 3);
        }
        if (this.vcWeatherInfo != null) {
            _os.write((Collection) this.vcWeatherInfo, 4);
        }
        _os.write(this.iDayIndex, 5);
        if (this.sWeatherTips != null) {
            _os.write(this.sWeatherTips, 6);
        }
        if (this.sDisplayTips != null) {
            _os.write(this.sDisplayTips, 7);
        }
        if (this.stLiveIndex != null) {
            _os.write((JceStruct) this.stLiveIndex, 8);
        }
        if (this.vWeatherWarning != null) {
            _os.write((Collection) this.vWeatherWarning, 9);
        }
        if (this.sMoreUrl != null) {
            _os.write(this.sMoreUrl, 10);
        }
        if (this.stWeatherActivity != null) {
            _os.write((JceStruct) this.stWeatherActivity, 11);
        }
        if (this.vcHourlyWeatherInfo != null) {
            _os.write((Collection) this.vcHourlyWeatherInfo, 12);
        }
    }

    static {
        cache_vcWeatherInfo.add(new DobbyWeatherSimple());
        cache_vWeatherWarning.add(new WeatherWarningInfo());
        cache_vcHourlyWeatherInfo.add(new DobbyHourlyWeatherSimple());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sCityID = _is.readString(0, false);
        this.sProvince = _is.readString(1, false);
        this.sDistrict = _is.readString(2, false);
        this.sCounty = _is.readString(3, false);
        this.vcWeatherInfo = (ArrayList) _is.read((Object) cache_vcWeatherInfo, 4, false);
        this.iDayIndex = _is.read(this.iDayIndex, 5, false);
        this.sWeatherTips = _is.readString(6, false);
        this.sDisplayTips = _is.readString(7, false);
        this.stLiveIndex = (LiveIndex) _is.read((JceStruct) cache_stLiveIndex, 8, false);
        this.vWeatherWarning = (ArrayList) _is.read((Object) cache_vWeatherWarning, 9, false);
        this.sMoreUrl = _is.readString(10, false);
        this.stWeatherActivity = (WeatherActivity) _is.read((JceStruct) cache_stWeatherActivity, 11, false);
        this.vcHourlyWeatherInfo = (ArrayList) _is.read((Object) cache_vcHourlyWeatherInfo, 12, false);
    }
}
