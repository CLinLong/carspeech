package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SlotDatetime extends JceStruct {
    static Datetime cache_datetime = new Datetime();
    static IntervalDatetime cache_interval = new IntervalDatetime();
    static RepeatDateTime cache_repeat = new RepeatDateTime();
    static int cache_type = 0;
    public Datetime datetime = null;
    public IntervalDatetime interval = null;
    public boolean is_valid = true;
    public String old_json = "";
    public String original_text = "";
    public RepeatDateTime repeat = null;
    public int type = 0;

    public SlotDatetime() {
    }

    public SlotDatetime(String original_text2, int type2, Datetime datetime2, IntervalDatetime interval2, RepeatDateTime repeat2, String old_json2, boolean is_valid2) {
        this.original_text = original_text2;
        this.type = type2;
        this.datetime = datetime2;
        this.interval = interval2;
        this.repeat = repeat2;
        this.old_json = old_json2;
        this.is_valid = is_valid2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.original_text, 0);
        _os.write(this.type, 1);
        if (this.datetime != null) {
            _os.write((JceStruct) this.datetime, 2);
        }
        if (this.interval != null) {
            _os.write((JceStruct) this.interval, 3);
        }
        if (this.repeat != null) {
            _os.write((JceStruct) this.repeat, 4);
        }
        if (this.old_json != null) {
            _os.write(this.old_json, 5);
        }
        _os.write(this.is_valid, 6);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.original_text = _is.readString(0, true);
        this.type = _is.read(this.type, 1, true);
        this.datetime = (Datetime) _is.read((JceStruct) cache_datetime, 2, false);
        this.interval = (IntervalDatetime) _is.read((JceStruct) cache_interval, 3, false);
        this.repeat = (RepeatDateTime) _is.read((JceStruct) cache_repeat, 4, false);
        this.old_json = _is.readString(5, false);
        this.is_valid = _is.read(this.is_valid, 6, false);
    }
}
