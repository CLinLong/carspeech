package SmartAssistant;

import java.io.Serializable;

public final class enumMusicTerminalDisplayFormat implements Serializable {
    public static final int _E_MUSIC_TERMINAL_DISPLAY_FORMAT_ALBUM_LIST = 3;
    public static final int _E_MUSIC_TERMINAL_DISPLAY_FORMAT_PLAY_AND_HIDE_OTHERS = 5;
    public static final int _E_MUSIC_TERMINAL_DISPLAY_FORMAT_PLAY_AND_SONG_LIST = 4;
    public static final int _E_MUSIC_TERMINAL_DISPLAY_FORMAT_PLAY_ONLY = 1;
    public static final int _E_MUSIC_TERMINAL_DISPLAY_FORMAT_SONG_LIST = 2;
    public static final int _E_MUSIC_TERMINAL_DISPLAY_FORMAT_TEXT_ONLY = 0;
}
