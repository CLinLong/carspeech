package SmartAssistant;

import java.io.Serializable;

public final class enumActionType implements Serializable {
    public static final int _E_ACTION_COLLECT = 16;
    public static final int _E_ACTION_DELETE = 3;
    public static final int _E_ACTION_NEXT = 10;
    public static final int _E_ACTION_PAUSE = 6;
    public static final int _E_ACTION_PLAY = 4;
    public static final int _E_ACTION_PLAYLIST = 5;
    public static final int _E_ACTION_PREV = 9;
    public static final int _E_ACTION_QUERY = 1;
    public static final int _E_ACTION_RESUME = 7;
    public static final int _E_ACTION_SELECT = 2;
    public static final int _E_ACTION_STOP = 8;
    public static final int _E_ACTION_UNKNOWN = 0;
    public static final int _E_ACTION_VOLUME_DOWN = 15;
    public static final int _E_ACTION_VOLUME_MAX = 12;
    public static final int _E_ACTION_VOLUME_MID = 11;
    public static final int _E_ACTION_VOLUME_MIN = 13;
    public static final int _E_ACTION_VOLUME_UP = 14;
}
