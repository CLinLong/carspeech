package SmartAssistant;

import java.io.Serializable;

public final class enumSubService implements Serializable {
    public static final int _E_SUB_SERVICE_FM = 2;
    public static final int _E_SUB_SERVICE_MUSIC = 1;
    public static final int _E_SUB_SERVICE_RADIO = 3;
    public static final int _E_SUB_SERVICE_TEXT = 4;
    public static final int _E_SUB_SERVICE_UNKNOWN = 0;
}
