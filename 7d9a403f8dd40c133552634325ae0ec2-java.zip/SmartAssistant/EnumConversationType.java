package SmartAssistant;

import java.io.Serializable;

public final class EnumConversationType implements Serializable {
    public static final int _CONVERSATION_CHAT = 2;
    public static final int _CONVERSATION_KBQA = 1;
    public static final int _CONVERSATION_QA_PAIRS = 3;
    public static final int _CONVERSATION_TASK = 0;
}
