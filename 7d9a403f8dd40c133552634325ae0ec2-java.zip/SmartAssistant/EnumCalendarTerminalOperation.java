package SmartAssistant;

import java.io.Serializable;

public final class EnumCalendarTerminalOperation implements Serializable {
    public static final int _CALENDAR_TERMINAL_OPERATION_DO_NORMAL = 0;
    public static final int _CALENDAR_TERMINAL_OPERATION_DO_NOTHING_OTHER_REASON = 3;
    public static final int _CALENDAR_TERMINAL_OPERATION_DO_NOTHING_TIME_IS_PAST = 1;
    public static final int _CALENDAR_TERMINAL_OPERATION_DO_NOTHING_UNSUPPORTED = 2;
}
