package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NluResponse extends JceStruct {
    static ArrayList<NluResult> cache_results = new ArrayList<>();
    public ArrayList<NluResult> results = null;

    public NluResponse() {
    }

    public NluResponse(ArrayList<NluResult> results2) {
        this.results = results2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.results != null) {
            _os.write((Collection) this.results, 0);
        }
    }

    static {
        cache_results.add(new NluResult());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.results = (ArrayList) _is.read((Object) cache_results, 0, false);
    }
}
