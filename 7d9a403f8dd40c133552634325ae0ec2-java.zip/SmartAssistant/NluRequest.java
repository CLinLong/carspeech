package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NluRequest extends JceStruct {
    static DMSession cache_dm_session = new DMSession();
    static NluExplicitRequest cache_explicit_req = new NluExplicitRequest();
    static NluMultiTurnRequest cache_multi_turn_req = new NluMultiTurnRequest();
    static NluPolicy cache_policy = new NluPolicy();
    static NluUserBase cache_user_base = new NluUserBase();
    public DMSession dm_session = null;
    public NluExplicitRequest explicit_req = null;
    public NluMultiTurnRequest multi_turn_req = null;
    public NluPolicy policy = null;
    public String query = "";
    public NluUserBase user_base = null;

    public NluRequest() {
    }

    public NluRequest(String query2, NluUserBase user_base2, DMSession dm_session2, NluMultiTurnRequest multi_turn_req2, NluExplicitRequest explicit_req2, NluPolicy policy2) {
        this.query = query2;
        this.user_base = user_base2;
        this.dm_session = dm_session2;
        this.multi_turn_req = multi_turn_req2;
        this.explicit_req = explicit_req2;
        this.policy = policy2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.query != null) {
            _os.write(this.query, 0);
        }
        if (this.user_base != null) {
            _os.write((JceStruct) this.user_base, 1);
        }
        if (this.dm_session != null) {
            _os.write((JceStruct) this.dm_session, 2);
        }
        if (this.multi_turn_req != null) {
            _os.write((JceStruct) this.multi_turn_req, 3);
        }
        if (this.explicit_req != null) {
            _os.write((JceStruct) this.explicit_req, 4);
        }
        if (this.policy != null) {
            _os.write((JceStruct) this.policy, 5);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.query = _is.readString(0, false);
        this.user_base = (NluUserBase) _is.read((JceStruct) cache_user_base, 1, false);
        this.dm_session = (DMSession) _is.read((JceStruct) cache_dm_session, 2, false);
        this.multi_turn_req = (NluMultiTurnRequest) _is.read((JceStruct) cache_multi_turn_req, 3, false);
        this.explicit_req = (NluExplicitRequest) _is.read((JceStruct) cache_explicit_req, 4, false);
        this.policy = (NluPolicy) _is.read((JceStruct) cache_policy, 5, false);
    }
}
