package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.HashMap;
import java.util.Map;

public final class ResponseIntent extends JceStruct {
    static Map<String, String> cache_parameters_extracted = new HashMap();
    public String action = "";
    public String name = "";
    public Map<String, String> parameters_extracted = null;

    public ResponseIntent() {
    }

    public ResponseIntent(String name2, String action2, Map<String, String> parameters_extracted2) {
        this.name = name2;
        this.action = action2;
        this.parameters_extracted = parameters_extracted2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.name, 0);
        _os.write(this.action, 1);
        _os.write((Map) this.parameters_extracted, 2);
    }

    static {
        cache_parameters_extracted.put("", "");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.name = _is.readString(0, true);
        this.action = _is.readString(1, true);
        this.parameters_extracted = (Map) _is.read((Object) cache_parameters_extracted, 2, true);
    }
}
