package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class FmDataItem extends JceStruct {
    static int cache_eActionType = 0;
    static ArrayList<FmBaseItem> cache_vFmDataList = new ArrayList<>();
    public int eActionType = 0;
    public ArrayList<FmBaseItem> vFmDataList = null;

    public FmDataItem() {
    }

    public FmDataItem(int eActionType2, ArrayList<FmBaseItem> vFmDataList2) {
        this.eActionType = eActionType2;
        this.vFmDataList = vFmDataList2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eActionType, 0);
        if (this.vFmDataList != null) {
            _os.write((Collection) this.vFmDataList, 1);
        }
    }

    static {
        cache_vFmDataList.add(new FmBaseItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eActionType = _is.read(this.eActionType, 0, false);
        this.vFmDataList = (ArrayList) _is.read((Object) cache_vFmDataList, 1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        FmDataItem temp = (FmDataItem) a.parseObject(text, FmDataItem.class);
        this.eActionType = temp.eActionType;
        this.vFmDataList = temp.vFmDataList;
    }
}
