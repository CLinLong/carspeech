package SmartAssistant;

import java.io.Serializable;

public final class EnumSemanticVoiceSampleRate implements Serializable {
    public static final int _ENUM_SEMANTIC_VOICE_SAMPLE_RATE_16KHZ = 16000;
    public static final int _ENUM_SEMANTIC_VOICE_SAMPLE_RATE_8KHZ = 8000;
}
