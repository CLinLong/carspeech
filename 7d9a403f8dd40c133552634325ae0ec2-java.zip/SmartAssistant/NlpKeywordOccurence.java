package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NlpKeywordOccurence extends JceStruct {
    static NlpKeywordInfo cache_info = new NlpKeywordInfo();
    public NlpKeywordInfo info = null;
    public int num_tokens = 0;
    public String original_text = "";
    public String text = "";

    public NlpKeywordOccurence() {
    }

    public NlpKeywordOccurence(String text2, NlpKeywordInfo info2, int num_tokens2, String original_text2) {
        this.text = text2;
        this.info = info2;
        this.num_tokens = num_tokens2;
        this.original_text = original_text2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.text != null) {
            _os.write(this.text, 0);
        }
        if (this.info != null) {
            _os.write((JceStruct) this.info, 1);
        }
        _os.write(this.num_tokens, 2);
        if (this.original_text != null) {
            _os.write(this.original_text, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.text = _is.readString(0, false);
        this.info = (NlpKeywordInfo) _is.read((JceStruct) cache_info, 1, false);
        this.num_tokens = _is.read(this.num_tokens, 2, false);
        this.original_text = _is.readString(3, false);
    }
}
