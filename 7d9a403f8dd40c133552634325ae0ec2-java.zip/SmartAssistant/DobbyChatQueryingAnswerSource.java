package SmartAssistant;

import java.io.Serializable;

public final class DobbyChatQueryingAnswerSource implements Serializable {
    public static final int _ChatQueryingAnswerSource_PUGC = 0;
    public static final int _ChatQueryingAnswerSource_UGC = 1;
}
