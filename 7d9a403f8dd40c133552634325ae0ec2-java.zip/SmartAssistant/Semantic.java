package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class Semantic extends JceStruct {
    static ArrayList<SemanticSlot> cache_slots = new ArrayList<>();
    public String bubble_transform_query = "";
    public String domain = "";
    public String intent = "";
    public String query = "";
    public boolean session_complete = false;
    public ArrayList<SemanticSlot> slots = null;

    public Semantic() {
    }

    public Semantic(String query2, String domain2, String intent2, ArrayList<SemanticSlot> slots2, boolean session_complete2, String bubble_transform_query2) {
        this.query = query2;
        this.domain = domain2;
        this.intent = intent2;
        this.slots = slots2;
        this.session_complete = session_complete2;
        this.bubble_transform_query = bubble_transform_query2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.query, 0);
        if (this.domain != null) {
            _os.write(this.domain, 1);
        }
        if (this.intent != null) {
            _os.write(this.intent, 2);
        }
        if (this.slots != null) {
            _os.write((Collection) this.slots, 3);
        }
        _os.write(this.session_complete, 4);
        if (this.bubble_transform_query != null) {
            _os.write(this.bubble_transform_query, 5);
        }
    }

    static {
        cache_slots.add(new SemanticSlot());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.query = _is.readString(0, true);
        this.domain = _is.readString(1, false);
        this.intent = _is.readString(2, false);
        this.slots = (ArrayList) _is.read((Object) cache_slots, 3, false);
        this.session_complete = _is.read(this.session_complete, 4, false);
        this.bubble_transform_query = _is.readString(5, false);
    }
}
