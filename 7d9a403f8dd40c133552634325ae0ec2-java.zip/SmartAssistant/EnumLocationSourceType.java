package SmartAssistant;

import java.io.Serializable;

public final class EnumLocationSourceType implements Serializable {
    public static final int _LOCATION_SOURCE_IP = 2;
    public static final int _LOCATION_SOURCE_LBS = 1;
    public static final int _LOCATION_SOURCE_QUERY = 0;
}
