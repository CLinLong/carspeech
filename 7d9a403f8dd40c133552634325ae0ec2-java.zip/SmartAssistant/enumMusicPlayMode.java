package SmartAssistant;

import java.io.Serializable;

public final class enumMusicPlayMode implements Serializable {
    public static final int _E_MUSIC_PLAY_MODE_LOOP = 4;
    public static final int _E_MUSIC_PLAY_MODE_ORDER = 2;
    public static final int _E_MUSIC_PLAY_MODE_RANDOM = 1;
    public static final int _E_MUSIC_PLAY_MODE_SINGLE_LOOP = 3;
    public static final int _E_MUSIC_PLAY_MODE_TERMINAL_CONTROL = 0;
}
