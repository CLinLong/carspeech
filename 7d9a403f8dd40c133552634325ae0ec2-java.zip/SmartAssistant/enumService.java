package SmartAssistant;

import java.io.Serializable;

public final class enumService implements Serializable {
    public static final int _E_SERVICE_CHAT = 4;
    public static final int _E_SERVICE_CLOCK = 9;
    public static final int _E_SERVICE_CTRL = 3;
    public static final int _E_SERVICE_JOKE = 6;
    public static final int _E_SERVICE_LOTTERY = 7;
    public static final int _E_SERVICE_MEDIA = 2;
    public static final int _E_SERVICE_NEWS = 12;
    public static final int _E_SERVICE_REMIND = 8;
    public static final int _E_SERVICE_SEMANTIC = 1;
    public static final int _E_SERVICE_TAXI = 10;
    public static final int _E_SERVICE_TV = 11;
    public static final int _E_SERVICE_UNKNOWN = 0;
    public static final int _E_SERVICE_WEATHER = 5;
}
