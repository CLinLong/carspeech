package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class PatternMatchResponse extends JceStruct {
    static ArrayList<Pattern> cache_matched_patterns = new ArrayList<>();
    public String info = "";
    public ArrayList<Pattern> matched_patterns = null;

    public PatternMatchResponse() {
    }

    public PatternMatchResponse(ArrayList<Pattern> matched_patterns2, String info2) {
        this.matched_patterns = matched_patterns2;
        this.info = info2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.matched_patterns != null) {
            _os.write((Collection) this.matched_patterns, 0);
        }
        if (this.info != null) {
            _os.write(this.info, 1);
        }
    }

    static {
        cache_matched_patterns.add(new Pattern());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.matched_patterns = (ArrayList) _is.read((Object) cache_matched_patterns, 0, false);
        this.info = _is.readString(1, false);
    }
}
