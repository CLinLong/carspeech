package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class WeatherActivity extends JceStruct {
    public int iSuggestion = 0;
    public String sActivity = "";
    public String sReason = "";

    public WeatherActivity() {
    }

    public WeatherActivity(String sActivity2, int iSuggestion2, String sReason2) {
        this.sActivity = sActivity2;
        this.iSuggestion = iSuggestion2;
        this.sReason = sReason2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sActivity != null) {
            _os.write(this.sActivity, 0);
        }
        _os.write(this.iSuggestion, 1);
        if (this.sReason != null) {
            _os.write(this.sReason, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sActivity = _is.readString(0, false);
        this.iSuggestion = _is.read(this.iSuggestion, 1, false);
        this.sReason = _is.readString(2, false);
    }
}
