package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NluMultiTurnRequest extends JceStruct {
    static int cache_type = 0;
    static ArrayList<String> cache_value_list = new ArrayList<>();
    public String domain = "";
    public String intent = "";
    public String slot_name = "";
    public int type = 0;
    public ArrayList<String> value_list = null;

    public NluMultiTurnRequest() {
    }

    public NluMultiTurnRequest(int type2, String domain2, String intent2, String slot_name2, ArrayList<String> value_list2) {
        this.type = type2;
        this.domain = domain2;
        this.intent = intent2;
        this.slot_name = slot_name2;
        this.value_list = value_list2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.type, 0);
        if (this.domain != null) {
            _os.write(this.domain, 1);
        }
        if (this.intent != null) {
            _os.write(this.intent, 2);
        }
        if (this.slot_name != null) {
            _os.write(this.slot_name, 3);
        }
        if (this.value_list != null) {
            _os.write((Collection) this.value_list, 4);
        }
    }

    static {
        cache_value_list.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.type = _is.read(this.type, 0, false);
        this.domain = _is.readString(1, false);
        this.intent = _is.readString(2, false);
        this.slot_name = _is.readString(3, false);
        this.value_list = (ArrayList) _is.read((Object) cache_value_list, 4, false);
    }
}
