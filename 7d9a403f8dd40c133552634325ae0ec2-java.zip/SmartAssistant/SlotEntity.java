package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SlotEntity extends JceStruct {
    public String original_text = "";
    public String text = "";

    public SlotEntity() {
    }

    public SlotEntity(String text2, String original_text2) {
        this.text = text2;
        this.original_text = original_text2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.text, 0);
        _os.write(this.original_text, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.text = _is.readString(0, true);
        this.original_text = _is.readString(1, true);
    }
}
