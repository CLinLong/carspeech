package SmartAssistant;

import android.support.annotation.Keep;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

@Keep
public final class SlotLocation extends JceStruct {
    static int cache_source = 0;
    static byte[] cache_vLBSKeyData = new byte[1];
    public String city = "";
    public String country = "";
    public String district = "";
    public float latitude = 0.0f;
    public float longitude = 0.0f;
    public String original_text = "";
    public String province = "";
    public String residual = "";
    public int source = 0;
    public String street = "";
    public String title = "";
    public String town = "";
    public byte[] vLBSKeyData = null;
    public String village = "";

    static {
        cache_vLBSKeyData[0] = 0;
    }

    public SlotLocation() {
    }

    public SlotLocation(String var1, String var2, String var3, String var4, String var5, String var6, String var7, float var8, float var9, byte[] var10, String var11, String var12, String var13, int var14) {
        this.original_text = var1;
        this.country = var2;
        this.province = var3;
        this.city = var4;
        this.district = var5;
        this.town = var6;
        this.street = var7;
        this.longitude = var8;
        this.latitude = var9;
        this.vLBSKeyData = var10;
        this.title = var11;
        this.village = var12;
        this.residual = var13;
        this.source = var14;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream var1) {
        if (this.original_text != null) {
            var1.write(this.original_text, 0);
        }
        if (this.country != null) {
            var1.write(this.country, 1);
        }
        if (this.province != null) {
            var1.write(this.province, 2);
        }
        if (this.city != null) {
            var1.write(this.city, 3);
        }
        if (this.district != null) {
            var1.write(this.district, 4);
        }
        if (this.town != null) {
            var1.write(this.town, 5);
        }
        if (this.street != null) {
            var1.write(this.street, 6);
        }
        var1.write(this.longitude, 7);
        var1.write(this.latitude, 8);
        if (this.vLBSKeyData != null) {
            var1.write(this.vLBSKeyData, 9);
        }
        if (this.title != null) {
            var1.write(this.title, 10);
        }
        if (this.village != null) {
            var1.write(this.village, 11);
        }
        if (this.residual != null) {
            var1.write(this.residual, 12);
        }
        var1.write(this.source, 13);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream var1) {
        this.original_text = var1.readString(0, false);
        this.country = var1.readString(1, false);
        this.province = var1.readString(2, false);
        this.city = var1.readString(3, false);
        this.district = var1.readString(4, false);
        this.town = var1.readString(5, false);
        this.street = var1.readString(6, false);
        this.longitude = var1.read(this.longitude, 7, false);
        this.latitude = var1.read(this.latitude, 8, false);
        this.vLBSKeyData = var1.read(cache_vLBSKeyData, 9, false);
        this.title = var1.readString(10, false);
        this.village = var1.readString(11, false);
        this.residual = var1.readString(12, false);
        this.source = var1.read(this.source, 13, false);
    }
}
