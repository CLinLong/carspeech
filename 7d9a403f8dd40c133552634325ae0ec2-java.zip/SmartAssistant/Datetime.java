package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Datetime extends JceStruct {
    static int cache_calendar_type_of_text = 0;
    static int cache_express_type = 0;
    static int cache_period_of_day = 0;
    public int calendar_type_of_text = 0;
    public String date = "";
    public int day = -1;
    public int express_type = 0;
    public int hour = -1;
    public int min = -1;
    public int mon = -1;
    public String original_text = "";
    public int period_of_day = 0;
    public int sec = -1;
    public String time = "";
    public int week = -1;
    public int year = -1;

    public Datetime() {
    }

    public Datetime(String original_text2, String date2, String time2, int year2, int mon2, int day2, int week2, int hour2, int min2, int sec2, int period_of_day2, int calendar_type_of_text2, int express_type2) {
        this.original_text = original_text2;
        this.date = date2;
        this.time = time2;
        this.year = year2;
        this.mon = mon2;
        this.day = day2;
        this.week = week2;
        this.hour = hour2;
        this.min = min2;
        this.sec = sec2;
        this.period_of_day = period_of_day2;
        this.calendar_type_of_text = calendar_type_of_text2;
        this.express_type = express_type2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.original_text != null) {
            _os.write(this.original_text, 0);
        }
        if (this.date != null) {
            _os.write(this.date, 1);
        }
        if (this.time != null) {
            _os.write(this.time, 2);
        }
        _os.write(this.year, 3);
        _os.write(this.mon, 4);
        _os.write(this.day, 5);
        _os.write(this.week, 6);
        _os.write(this.hour, 7);
        _os.write(this.min, 8);
        _os.write(this.sec, 9);
        _os.write(this.period_of_day, 10);
        _os.write(this.calendar_type_of_text, 11);
        _os.write(this.express_type, 12);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.original_text = _is.readString(0, false);
        this.date = _is.readString(1, false);
        this.time = _is.readString(2, false);
        this.year = _is.read(this.year, 3, true);
        this.mon = _is.read(this.mon, 4, true);
        this.day = _is.read(this.day, 5, true);
        this.week = _is.read(this.week, 6, true);
        this.hour = _is.read(this.hour, 7, true);
        this.min = _is.read(this.min, 8, true);
        this.sec = _is.read(this.sec, 9, true);
        this.period_of_day = _is.read(this.period_of_day, 10, true);
        this.calendar_type_of_text = _is.read(this.calendar_type_of_text, 11, true);
        this.express_type = _is.read(this.express_type, 12, false);
    }
}
