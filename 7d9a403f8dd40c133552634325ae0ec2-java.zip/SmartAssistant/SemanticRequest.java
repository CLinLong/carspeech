package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SemanticRequest extends JceStruct {
    static Semantic cache_semantic = new Semantic();
    static UserProfile cache_user_profile = new UserProfile();
    public int iCmd = 0;
    public Semantic semantic = null;
    public UserProfile user_profile = null;

    public SemanticRequest() {
    }

    public SemanticRequest(UserProfile user_profile2, Semantic semantic2, int iCmd2) {
        this.user_profile = user_profile2;
        this.semantic = semantic2;
        this.iCmd = iCmd2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.user_profile, 0);
        if (this.semantic != null) {
            _os.write((JceStruct) this.semantic, 1);
        }
        _os.write(this.iCmd, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.user_profile = (UserProfile) _is.read((JceStruct) cache_user_profile, 0, true);
        this.semantic = (Semantic) _is.read((JceStruct) cache_semantic, 1, false);
        this.iCmd = _is.read(this.iCmd, 2, false);
    }
}
