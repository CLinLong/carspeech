package SmartAssistant;

import java.io.Serializable;

public final class PatternType implements Serializable {
    public static final int _CANCEL = 4;
    public static final int _COMMON = 1;
    public static final int _PARAMETER_ASK = 8;
    public static final int _SUPPER_ADD = 2;
}
