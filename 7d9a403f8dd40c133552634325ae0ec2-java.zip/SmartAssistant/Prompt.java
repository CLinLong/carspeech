package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class Prompt extends JceStruct {
    static ArrayList<String> cache_text_list = new ArrayList<>();
    public String slot_key = "";
    public String text = "";
    public ArrayList<String> text_list = null;

    public Prompt() {
    }

    public Prompt(String text2, String slot_key2, ArrayList<String> text_list2) {
        this.text = text2;
        this.slot_key = slot_key2;
        this.text_list = text_list2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.text != null) {
            _os.write(this.text, 0);
        }
        if (this.slot_key != null) {
            _os.write(this.slot_key, 1);
        }
        if (this.text_list != null) {
            _os.write((Collection) this.text_list, 2);
        }
    }

    static {
        cache_text_list.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.text = _is.readString(0, false);
        this.slot_key = _is.readString(1, false);
        this.text_list = (ArrayList) _is.read((Object) cache_text_list, 2, false);
    }
}
