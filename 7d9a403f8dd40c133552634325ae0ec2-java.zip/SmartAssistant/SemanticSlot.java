package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SemanticSlot extends JceStruct {
    static ArrayList<String> cache_json_values = new ArrayList<>();
    static SemanticPrompt cache_prompt = new SemanticPrompt();
    static int cache_slot_struct = 0;
    static ArrayList<byte[]> cache_values = new ArrayList<>();
    public ArrayList<String> json_values = null;
    public String name = "";
    public SemanticPrompt prompt = null;
    public int slot_struct = 0;
    public String type = "";
    public ArrayList<byte[]> values = null;

    public SemanticSlot() {
    }

    public SemanticSlot(String name2, String type2, int slot_struct2, ArrayList<byte[]> values2, SemanticPrompt prompt2, ArrayList<String> json_values2) {
        this.name = name2;
        this.type = type2;
        this.slot_struct = slot_struct2;
        this.values = values2;
        this.prompt = prompt2;
        this.json_values = json_values2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.name, 0);
        _os.write(this.type, 1);
        _os.write(this.slot_struct, 2);
        if (this.values != null) {
            _os.write((Collection) this.values, 3);
        }
        if (this.prompt != null) {
            _os.write((JceStruct) this.prompt, 4);
        }
        if (this.json_values != null) {
            _os.write((Collection) this.json_values, 5);
        }
    }

    static {
        byte[] __var_11 = new byte[1];
        __var_11[0] = 0;
        cache_values.add(__var_11);
        cache_json_values.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.name = _is.readString(0, true);
        this.type = _is.readString(1, true);
        this.slot_struct = _is.read(this.slot_struct, 2, false);
        this.values = (ArrayList) _is.read((Object) cache_values, 3, false);
        this.prompt = (SemanticPrompt) _is.read((JceStruct) cache_prompt, 4, false);
        this.json_values = (ArrayList) _is.read((Object) cache_json_values, 5, false);
    }
}
