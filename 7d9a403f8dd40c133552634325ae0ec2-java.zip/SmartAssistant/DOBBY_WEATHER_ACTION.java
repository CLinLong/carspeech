package SmartAssistant;

import java.io.Serializable;

public final class DOBBY_WEATHER_ACTION implements Serializable {
    public static final int _AQI_SEARCH = 8;
    public static final int _BUSINESSASSISTANT = 11;
    public static final int _CONDITIONAL_SEARCH_ACTIVITY = 6;
    public static final int _CONDITIONAL_SEARCH_DESCRIPTION = 4;
    public static final int _CONDITIONAL_SEARCH_FEEL = 5;
    public static final int _CONDITIONAL_SEARCH_HUMIDITY = 10;
    public static final int _CONDITIONAL_SEARCH_OUTFIT = 7;
    public static final int _CONDITIONAL_SEARCH_TEMPERATURE = 12;
    public static final int _CONDITIONAL_SEARCH_ULTRAVIOLET = 9;
    public static final int _DOBBY_WEATHER_ACTION_QUERY_AQI = 1;
    public static final int _DOBBY_WEATHER_ACTION_QUERY_CLOSING = 2;
    public static final int _DOBBY_WEATHER_ACTION_QUERY_WEATHER = 0;
    public static final int _GENERAL_SEARCH = 3;
}
