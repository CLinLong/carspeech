package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyWeatherServiceReq extends JceStruct {
    static int cache_eAction = 0;
    static int cache_stClientType = 0;
    static UserBase cache_stUserBase = new UserBase();
    public boolean bValidDate = true;
    public int eAction = 0;
    public long lFromTime = 0;
    public long lToTime = 0;
    public String sActivity = "";
    public String sDateContent = "";
    public String sDescription = "";
    public String sFeel = "";
    public String sLatitude = "";
    public String sLongitude = "";
    public String sOutfit = "";
    public String sPlace = "";
    public String sPollutant = "";
    public int stClientType = 0;
    public UserBase stUserBase = null;

    public DobbyWeatherServiceReq() {
    }

    public DobbyWeatherServiceReq(UserBase stUserBase2, int eAction2, String sPlace2, long lFromTime2, long lToTime2, String sLatitude2, String sLongitude2, int stClientType2, String sDescription2, String sFeel2, String sActivity2, String sOutfit2, String sPollutant2, String sDateContent2, boolean bValidDate2) {
        this.stUserBase = stUserBase2;
        this.eAction = eAction2;
        this.sPlace = sPlace2;
        this.lFromTime = lFromTime2;
        this.lToTime = lToTime2;
        this.sLatitude = sLatitude2;
        this.sLongitude = sLongitude2;
        this.stClientType = stClientType2;
        this.sDescription = sDescription2;
        this.sFeel = sFeel2;
        this.sActivity = sActivity2;
        this.sOutfit = sOutfit2;
        this.sPollutant = sPollutant2;
        this.sDateContent = sDateContent2;
        this.bValidDate = bValidDate2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.stUserBase != null) {
            _os.write((JceStruct) this.stUserBase, 0);
        }
        _os.write(this.eAction, 1);
        if (this.sPlace != null) {
            _os.write(this.sPlace, 2);
        }
        _os.write(this.lFromTime, 3);
        _os.write(this.lToTime, 4);
        if (this.sLatitude != null) {
            _os.write(this.sLatitude, 5);
        }
        if (this.sLongitude != null) {
            _os.write(this.sLongitude, 6);
        }
        _os.write(this.stClientType, 7);
        if (this.sDescription != null) {
            _os.write(this.sDescription, 8);
        }
        if (this.sFeel != null) {
            _os.write(this.sFeel, 9);
        }
        if (this.sActivity != null) {
            _os.write(this.sActivity, 10);
        }
        if (this.sOutfit != null) {
            _os.write(this.sOutfit, 11);
        }
        if (this.sPollutant != null) {
            _os.write(this.sPollutant, 12);
        }
        if (this.sDateContent != null) {
            _os.write(this.sDateContent, 13);
        }
        _os.write(this.bValidDate, 14);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.stUserBase = (UserBase) _is.read((JceStruct) cache_stUserBase, 0, false);
        this.eAction = _is.read(this.eAction, 1, false);
        this.sPlace = _is.readString(2, false);
        this.lFromTime = _is.read(this.lFromTime, 3, false);
        this.lToTime = _is.read(this.lToTime, 4, false);
        this.sLatitude = _is.readString(5, false);
        this.sLongitude = _is.readString(6, false);
        this.stClientType = _is.read(this.stClientType, 7, false);
        this.sDescription = _is.readString(8, false);
        this.sFeel = _is.readString(9, false);
        this.sActivity = _is.readString(10, false);
        this.sOutfit = _is.readString(11, false);
        this.sPollutant = _is.readString(12, false);
        this.sDateContent = _is.readString(13, false);
        this.bValidDate = _is.read(this.bValidDate, 14, false);
    }
}
