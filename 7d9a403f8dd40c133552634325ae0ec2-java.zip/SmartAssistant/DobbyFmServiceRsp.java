package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyFmServiceRsp extends JceStruct {
    static int cache_eDisplayFormat = 0;
    static int cache_eRetCode = 0;
    static int cache_eSubService = 0;
    static FmData cache_fmData = new FmData();
    public int eDisplayFormat = 1;
    public int eRetCode = 0;
    public int eSubService = 0;
    public String exstr = "";
    public FmData fmData = null;
    public String sSpeak = "";
    public String sText = "";

    public DobbyFmServiceRsp() {
    }

    public DobbyFmServiceRsp(int eRetCode2, int eSubService2, String sSpeak2, String sText2, FmData fmData2, int eDisplayFormat2, String exstr2) {
        this.eRetCode = eRetCode2;
        this.eSubService = eSubService2;
        this.sSpeak = sSpeak2;
        this.sText = sText2;
        this.fmData = fmData2;
        this.eDisplayFormat = eDisplayFormat2;
        this.exstr = exstr2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eRetCode, 0);
        _os.write(this.eSubService, 1);
        if (this.sSpeak != null) {
            _os.write(this.sSpeak, 2);
        }
        if (this.sText != null) {
            _os.write(this.sText, 3);
        }
        if (this.fmData != null) {
            _os.write((JceStruct) this.fmData, 4);
        }
        _os.write(this.eDisplayFormat, 5);
        if (this.exstr != null) {
            _os.write(this.exstr, 6);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eRetCode = _is.read(this.eRetCode, 0, false);
        this.eSubService = _is.read(this.eSubService, 1, false);
        this.sSpeak = _is.readString(2, false);
        this.sText = _is.readString(3, false);
        this.fmData = (FmData) _is.read((JceStruct) cache_fmData, 4, false);
        this.eDisplayFormat = _is.read(this.eDisplayFormat, 5, false);
        this.exstr = _is.readString(6, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        DobbyFmServiceRsp temp = (DobbyFmServiceRsp) a.parseObject(text, DobbyFmServiceRsp.class);
        this.eRetCode = temp.eRetCode;
        this.eSubService = temp.eSubService;
        this.sSpeak = temp.sSpeak;
        this.sText = temp.sText;
        this.fmData = temp.fmData;
        this.eDisplayFormat = temp.eDisplayFormat;
        this.exstr = temp.exstr;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
