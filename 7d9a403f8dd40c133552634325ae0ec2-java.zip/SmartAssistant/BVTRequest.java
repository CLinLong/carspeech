package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class BVTRequest extends JceStruct {
    static SemanticRequest cache_semantic_request = new SemanticRequest();
    public SemanticRequest semantic_request = null;
    public boolean use_model = true;
    public boolean use_pattern = true;

    public BVTRequest() {
    }

    public BVTRequest(SemanticRequest semantic_request2, boolean use_pattern2, boolean use_model2) {
        this.semantic_request = semantic_request2;
        this.use_pattern = use_pattern2;
        this.use_model = use_model2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.semantic_request, 0);
        _os.write(this.use_pattern, 1);
        _os.write(this.use_model, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.semantic_request = (SemanticRequest) _is.read((JceStruct) cache_semantic_request, 0, true);
        this.use_pattern = _is.read(this.use_pattern, 1, false);
        this.use_model = _is.read(this.use_model, 2, false);
    }
}
