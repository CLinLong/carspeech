package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class DobbyWeatherSimple extends JceStruct {
    static DobbyMaxMin cache_stHumidity = new DobbyMaxMin();
    static DobbyWeatherDetail cache_stWeatherDetail = new DobbyWeatherDetail();
    static ArrayList<DobbyLiveIndexInfo> cache_vDobbyLiveIndex = new ArrayList<>();
    public String sAQI = "";
    public String sAQIDes = "";
    public String sCurrentT = "";
    public String sDWeaIndex = "";
    public String sDressingIndex = "";
    public String sDweather = "";
    public String sHoliday = "";
    public String sJumpUrl = "";
    public String sLunarYear = "";
    public String sMaxT = "";
    public String sMinT = "";
    public String sName = "";
    public String sNewCurT = "";
    public String sPm25 = "";
    public String sTim = "";
    public String sWeek = "";
    public String sWind = "";
    public String sWindPower = "";
    public DobbyMaxMin stHumidity = null;
    public DobbyWeatherDetail stWeatherDetail = null;
    public ArrayList<DobbyLiveIndexInfo> vDobbyLiveIndex = null;

    public DobbyWeatherSimple() {
    }

    public DobbyWeatherSimple(String sDWeaIndex2, String sMaxT2, String sMinT2, String sTim2, String sWeek2, String sDweather2, String sName2, String sWind2, String sWindPower2, String sLunarYear2, String sHoliday2, String sJumpUrl2, String sCurrentT2, String sAQIDes2, String sAQI2, String sNewCurT2, String sDressingIndex2, DobbyWeatherDetail stWeatherDetail2, String sPm252, DobbyMaxMin stHumidity2, ArrayList<DobbyLiveIndexInfo> vDobbyLiveIndex2) {
        this.sDWeaIndex = sDWeaIndex2;
        this.sMaxT = sMaxT2;
        this.sMinT = sMinT2;
        this.sTim = sTim2;
        this.sWeek = sWeek2;
        this.sDweather = sDweather2;
        this.sName = sName2;
        this.sWind = sWind2;
        this.sWindPower = sWindPower2;
        this.sLunarYear = sLunarYear2;
        this.sHoliday = sHoliday2;
        this.sJumpUrl = sJumpUrl2;
        this.sCurrentT = sCurrentT2;
        this.sAQIDes = sAQIDes2;
        this.sAQI = sAQI2;
        this.sNewCurT = sNewCurT2;
        this.sDressingIndex = sDressingIndex2;
        this.stWeatherDetail = stWeatherDetail2;
        this.sPm25 = sPm252;
        this.stHumidity = stHumidity2;
        this.vDobbyLiveIndex = vDobbyLiveIndex2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sDWeaIndex != null) {
            _os.write(this.sDWeaIndex, 0);
        }
        if (this.sMaxT != null) {
            _os.write(this.sMaxT, 1);
        }
        if (this.sMinT != null) {
            _os.write(this.sMinT, 2);
        }
        if (this.sTim != null) {
            _os.write(this.sTim, 3);
        }
        if (this.sWeek != null) {
            _os.write(this.sWeek, 4);
        }
        if (this.sDweather != null) {
            _os.write(this.sDweather, 5);
        }
        if (this.sName != null) {
            _os.write(this.sName, 6);
        }
        if (this.sWind != null) {
            _os.write(this.sWind, 7);
        }
        if (this.sWindPower != null) {
            _os.write(this.sWindPower, 8);
        }
        if (this.sLunarYear != null) {
            _os.write(this.sLunarYear, 9);
        }
        if (this.sHoliday != null) {
            _os.write(this.sHoliday, 10);
        }
        if (this.sJumpUrl != null) {
            _os.write(this.sJumpUrl, 11);
        }
        if (this.sCurrentT != null) {
            _os.write(this.sCurrentT, 12);
        }
        if (this.sAQIDes != null) {
            _os.write(this.sAQIDes, 13);
        }
        if (this.sAQI != null) {
            _os.write(this.sAQI, 14);
        }
        if (this.sNewCurT != null) {
            _os.write(this.sNewCurT, 15);
        }
        if (this.sDressingIndex != null) {
            _os.write(this.sDressingIndex, 16);
        }
        if (this.stWeatherDetail != null) {
            _os.write((JceStruct) this.stWeatherDetail, 17);
        }
        if (this.sPm25 != null) {
            _os.write(this.sPm25, 18);
        }
        if (this.stHumidity != null) {
            _os.write((JceStruct) this.stHumidity, 19);
        }
        if (this.vDobbyLiveIndex != null) {
            _os.write((Collection) this.vDobbyLiveIndex, 20);
        }
    }

    static {
        cache_vDobbyLiveIndex.add(new DobbyLiveIndexInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sDWeaIndex = _is.readString(0, false);
        this.sMaxT = _is.readString(1, false);
        this.sMinT = _is.readString(2, false);
        this.sTim = _is.readString(3, false);
        this.sWeek = _is.readString(4, false);
        this.sDweather = _is.readString(5, false);
        this.sName = _is.readString(6, false);
        this.sWind = _is.readString(7, false);
        this.sWindPower = _is.readString(8, false);
        this.sLunarYear = _is.readString(9, false);
        this.sHoliday = _is.readString(10, false);
        this.sJumpUrl = _is.readString(11, false);
        this.sCurrentT = _is.readString(12, false);
        this.sAQIDes = _is.readString(13, false);
        this.sAQI = _is.readString(14, false);
        this.sNewCurT = _is.readString(15, false);
        this.sDressingIndex = _is.readString(16, false);
        this.stWeatherDetail = (DobbyWeatherDetail) _is.read((JceStruct) cache_stWeatherDetail, 17, false);
        this.sPm25 = _is.readString(18, false);
        this.stHumidity = (DobbyMaxMin) _is.read((JceStruct) cache_stHumidity, 19, false);
        this.vDobbyLiveIndex = (ArrayList) _is.read((Object) cache_vDobbyLiveIndex, 20, false);
    }
}
