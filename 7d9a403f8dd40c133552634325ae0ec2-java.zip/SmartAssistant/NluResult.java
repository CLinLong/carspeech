package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NluResult extends JceStruct {
    static NluExtraInfo cache_extra_info = new NluExtraInfo();
    static ArrayList<NluSlot> cache_slots = new ArrayList<>();
    static int cache_turn_type = 0;
    public String domain = "";
    public NluExtraInfo extra_info = null;
    public String intent = "";
    public ArrayList<NluSlot> slots = null;
    public int turn_type = 0;

    public NluResult() {
    }

    public NluResult(String domain2, String intent2, ArrayList<NluSlot> slots2, NluExtraInfo extra_info2, int turn_type2) {
        this.domain = domain2;
        this.intent = intent2;
        this.slots = slots2;
        this.extra_info = extra_info2;
        this.turn_type = turn_type2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.domain != null) {
            _os.write(this.domain, 0);
        }
        if (this.intent != null) {
            _os.write(this.intent, 1);
        }
        if (this.slots != null) {
            _os.write((Collection) this.slots, 2);
        }
        if (this.extra_info != null) {
            _os.write((JceStruct) this.extra_info, 3);
        }
        _os.write(this.turn_type, 4);
    }

    static {
        cache_slots.add(new NluSlot());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.domain = _is.readString(0, false);
        this.intent = _is.readString(1, false);
        this.slots = (ArrayList) _is.read((Object) cache_slots, 2, false);
        this.extra_info = (NluExtraInfo) _is.read((JceStruct) cache_extra_info, 3, false);
        this.turn_type = _is.read(this.turn_type, 4, false);
    }
}
