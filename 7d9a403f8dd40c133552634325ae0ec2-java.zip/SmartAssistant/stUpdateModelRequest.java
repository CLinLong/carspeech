package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class stUpdateModelRequest extends JceStruct {
    static ArrayList<String> cache_appkeys = new ArrayList<>();
    public ArrayList<String> appkeys = null;

    public stUpdateModelRequest() {
    }

    public stUpdateModelRequest(ArrayList<String> appkeys2) {
        this.appkeys = appkeys2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.appkeys, 0);
    }

    static {
        cache_appkeys.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.appkeys = (ArrayList) _is.read((Object) cache_appkeys, 0, true);
    }
}
