package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class UpdateDMSessionResponse extends JceStruct {
    static Status cache_status = new Status();
    public Status status = null;

    public UpdateDMSessionResponse() {
    }

    public UpdateDMSessionResponse(Status status2) {
        this.status = status2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.status, 0);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.status = (Status) _is.read((JceStruct) cache_status, 0, true);
    }
}
