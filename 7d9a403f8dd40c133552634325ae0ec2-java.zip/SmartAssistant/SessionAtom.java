package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SessionAtom extends JceStruct {
    static ArrayList<QAPair> cache_qa_pairs = new ArrayList<>();
    static ArrayList<SemanticSlot> cache_server_session_slots = new ArrayList<>();
    static ArrayList<SemanticSlot> cache_slots = new ArrayList<>();
    static int cache_status = 0;
    public String domain = "";
    public String intent = "";
    public long last_active_time = 0;
    public ArrayList<QAPair> qa_pairs = null;
    public ArrayList<SemanticSlot> server_session_slots = null;
    public boolean session_complete = true;
    public ArrayList<SemanticSlot> slots = null;
    public int status = 0;
    public String uuid = "";

    public SessionAtom() {
    }

    public SessionAtom(String uuid2, String domain2, String intent2, boolean session_complete2, ArrayList<SemanticSlot> slots2, ArrayList<QAPair> qa_pairs2, long last_active_time2, ArrayList<SemanticSlot> server_session_slots2, int status2) {
        this.uuid = uuid2;
        this.domain = domain2;
        this.intent = intent2;
        this.session_complete = session_complete2;
        this.slots = slots2;
        this.qa_pairs = qa_pairs2;
        this.last_active_time = last_active_time2;
        this.server_session_slots = server_session_slots2;
        this.status = status2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.uuid, 0);
        _os.write(this.domain, 1);
        _os.write(this.intent, 2);
        _os.write(this.session_complete, 3);
        _os.write((Collection) this.slots, 4);
        if (this.qa_pairs != null) {
            _os.write((Collection) this.qa_pairs, 5);
        }
        _os.write(this.last_active_time, 6);
        if (this.server_session_slots != null) {
            _os.write((Collection) this.server_session_slots, 7);
        }
        _os.write(this.status, 8);
    }

    static {
        cache_slots.add(new SemanticSlot());
        cache_qa_pairs.add(new QAPair());
        cache_server_session_slots.add(new SemanticSlot());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.uuid = _is.readString(0, true);
        this.domain = _is.readString(1, true);
        this.intent = _is.readString(2, true);
        this.session_complete = _is.read(this.session_complete, 3, true);
        this.slots = (ArrayList) _is.read((Object) cache_slots, 4, true);
        this.qa_pairs = (ArrayList) _is.read((Object) cache_qa_pairs, 5, false);
        this.last_active_time = _is.read(this.last_active_time, 6, false);
        this.server_session_slots = (ArrayList) _is.read((Object) cache_server_session_slots, 7, false);
        this.status = _is.read(this.status, 8, false);
    }
}
