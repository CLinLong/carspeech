package SmartAssistant;

import java.io.Serializable;

public final class EnumCalendarType implements Serializable {
    public static final int _HOLIDAY_Calendar = 3;
    public static final int _LUNAR_Calendar = 2;
    public static final int _SOLAR_Calendar = 1;
}
