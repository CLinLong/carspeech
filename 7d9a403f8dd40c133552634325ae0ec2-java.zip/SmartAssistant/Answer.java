package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public final class Answer extends JceStruct {
    static Map<String, ArrayList<NlpEntity>> cache_params = new HashMap();
    public float confidence = 0.0f;
    public String domain = "";
    public String id = "";
    public String intent = "";
    public Map<String, ArrayList<NlpEntity>> params = null;

    public Answer() {
    }

    public Answer(String domain2, String intent2, Map<String, ArrayList<NlpEntity>> params2, float confidence2, String id2) {
        this.domain = domain2;
        this.intent = intent2;
        this.params = params2;
        this.confidence = confidence2;
        this.id = id2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.domain != null) {
            _os.write(this.domain, 0);
        }
        if (this.intent != null) {
            _os.write(this.intent, 1);
        }
        if (this.params != null) {
            _os.write((Map) this.params, 2);
        }
        _os.write(this.confidence, 3);
        if (this.id != null) {
            _os.write(this.id, 4);
        }
    }

    static {
        ArrayList<NlpEntity> __var_10 = new ArrayList<>();
        __var_10.add(new NlpEntity());
        cache_params.put("", __var_10);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.domain = _is.readString(0, false);
        this.intent = _is.readString(1, false);
        this.params = (Map) _is.read((Object) cache_params, 2, false);
        this.confidence = _is.read(this.confidence, 3, false);
        this.id = _is.readString(4, false);
    }
}
