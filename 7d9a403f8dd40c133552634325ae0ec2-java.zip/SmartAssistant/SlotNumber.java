package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SlotNumber extends JceStruct {
    static int cache_number_type = 0;
    public String decimal = "";
    public String fraction = "";
    public String integer = "";
    public int number_type = 0;
    public String ordinal = "";
    public String original_text = "";

    public SlotNumber() {
    }

    public SlotNumber(String original_text2, int number_type2, String fraction2, String decimal2, String integer2, String ordinal2) {
        this.original_text = original_text2;
        this.number_type = number_type2;
        this.fraction = fraction2;
        this.decimal = decimal2;
        this.integer = integer2;
        this.ordinal = ordinal2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.original_text, 0);
        _os.write(this.number_type, 1);
        if (this.fraction != null) {
            _os.write(this.fraction, 2);
        }
        if (this.decimal != null) {
            _os.write(this.decimal, 3);
        }
        if (this.integer != null) {
            _os.write(this.integer, 4);
        }
        if (this.ordinal != null) {
            _os.write(this.ordinal, 5);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.original_text = _is.readString(0, true);
        this.number_type = _is.read(this.number_type, 1, true);
        this.fraction = _is.readString(2, false);
        this.decimal = _is.readString(3, false);
        this.integer = _is.readString(4, false);
        this.ordinal = _is.readString(5, false);
    }
}
