package SmartAssistant;

import java.io.Serializable;

public final class EnumSemanticCmd implements Serializable {
    public static final int _SEMANTIC_CMD_FORCE_CLEAR_PREV_SESSION = 3;
    public static final int _SEMANTIC_CMD_FORCE_CLEAR_SESSION = 2;
    public static final int _SEMANTIC_CMD_FORCE_SESSION_COMPLETE = 1;
}
