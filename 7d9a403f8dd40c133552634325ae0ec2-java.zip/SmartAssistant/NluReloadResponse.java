package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NluReloadResponse extends JceStruct {
    static ArrayList<Integer> cache_results = new ArrayList<>();
    public ArrayList<Integer> results = null;

    public NluReloadResponse() {
    }

    public NluReloadResponse(ArrayList<Integer> results2) {
        this.results = results2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.results != null) {
            _os.write((Collection) this.results, 0);
        }
    }

    static {
        cache_results.add(0);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.results = (ArrayList) _is.read((Object) cache_results, 0, false);
    }
}
