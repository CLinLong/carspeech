package SmartAssistant;

import java.io.Serializable;

public final class ResponseDataType implements Serializable {
    public static final int _E_DATATYPE_TEXT = 0;
    public static final int _E_DATATYPE_URL = 1;
}
