package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class stMediaDataItem extends JceStruct {
    static int cache_eActionType = 0;
    static ArrayList<stMeidaBaseItem> cache_vMediaDataList = new ArrayList<>();
    public int eActionType = 0;
    public ArrayList<stMeidaBaseItem> vMediaDataList = null;

    public stMediaDataItem() {
    }

    public stMediaDataItem(int eActionType2, ArrayList<stMeidaBaseItem> vMediaDataList2) {
        this.eActionType = eActionType2;
        this.vMediaDataList = vMediaDataList2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eActionType, 0);
        if (this.vMediaDataList != null) {
            _os.write((Collection) this.vMediaDataList, 1);
        }
    }

    static {
        cache_vMediaDataList.add(new stMeidaBaseItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eActionType = _is.read(this.eActionType, 0, false);
        this.vMediaDataList = (ArrayList) _is.read((Object) cache_vMediaDataList, 1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        stMediaDataItem temp = (stMediaDataItem) a.parseObject(text, stMediaDataItem.class);
        this.eActionType = temp.eActionType;
        this.vMediaDataList = temp.vMediaDataList;
    }
}
