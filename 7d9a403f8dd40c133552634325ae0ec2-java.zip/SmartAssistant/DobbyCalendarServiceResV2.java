package SmartAssistant;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DobbyCalendarServiceResV2 extends JceStruct {
    static Semantic cache_semantic = new Semantic();
    static int cache_terminal_operation = 0;
    public Semantic semantic = null;
    public int terminal_operation = 0;

    public DobbyCalendarServiceResV2() {
    }

    public DobbyCalendarServiceResV2(Semantic semantic2, int terminal_operation2) {
        this.semantic = semantic2;
        this.terminal_operation = terminal_operation2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.semantic != null) {
            _os.write((JceStruct) this.semantic, 0);
        }
        _os.write(this.terminal_operation, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.semantic = (Semantic) _is.read((JceStruct) cache_semantic, 0, false);
        this.terminal_operation = _is.read(this.terminal_operation, 1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        DobbyCalendarServiceResV2 temp = (DobbyCalendarServiceResV2) a.parseObject(text, DobbyCalendarServiceResV2.class);
        this.semantic = temp.semantic;
        this.terminal_operation = temp.terminal_operation;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
