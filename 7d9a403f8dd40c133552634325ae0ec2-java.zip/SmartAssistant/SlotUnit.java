package SmartAssistant;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SlotUnit extends JceStruct {
    static SlotNumber cache_amount = new SlotNumber();
    public SlotNumber amount = null;
    public String original_text = "";
    public String unit = "";

    public SlotUnit() {
    }

    public SlotUnit(String original_text2, SlotNumber amount2, String unit2) {
        this.original_text = original_text2;
        this.amount = amount2;
        this.unit = unit2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.original_text != null) {
            _os.write(this.original_text, 0);
        }
        if (this.amount != null) {
            _os.write((JceStruct) this.amount, 1);
        }
        if (this.unit != null) {
            _os.write(this.unit, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.original_text = _is.readString(0, false);
        this.amount = (SlotNumber) _is.read((JceStruct) cache_amount, 1, false);
        this.unit = _is.readString(2, false);
    }
}
