package SmartAssistant;

import java.io.Serializable;

public final class EnumSlotValueType implements Serializable {
    public static final int _SLOT_VALUE_DATETIME = 0;
    public static final int _SLOT_VALUE_ENTITY = 1;
    public static final int _SLOT_VALUE_LOCATION = 2;
    public static final int _SLOT_VALUE_NUMBER = 3;
    public static final int _SLOT_VALUE_UNIT = 4;
}
