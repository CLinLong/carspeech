package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class PhoneAreaCodeInfo extends JceStruct {
    public String sCity = "";
    public String sCode = "";
    public String sCounty = "";
    public String sProvince = "";

    public PhoneAreaCodeInfo() {
    }

    public PhoneAreaCodeInfo(String sProvince2, String sCity2, String sCounty2, String sCode2) {
        this.sProvince = sProvince2;
        this.sCity = sCity2;
        this.sCounty = sCounty2;
        this.sCode = sCode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sProvince != null) {
            _os.write(this.sProvince, 0);
        }
        if (this.sCity != null) {
            _os.write(this.sCity, 1);
        }
        if (this.sCounty != null) {
            _os.write(this.sCounty, 2);
        }
        if (this.sCode != null) {
            _os.write(this.sCode, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sProvince = _is.readString(0, false);
        this.sCity = _is.readString(1, false);
        this.sCounty = _is.readString(2, false);
        this.sCode = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        PhoneAreaCodeInfo temp = (PhoneAreaCodeInfo) a.parseObject(text, PhoneAreaCodeInfo.class);
        this.sProvince = temp.sProvince;
        this.sCity = temp.sCity;
        this.sCounty = temp.sCounty;
        this.sCode = temp.sCode;
    }
}
