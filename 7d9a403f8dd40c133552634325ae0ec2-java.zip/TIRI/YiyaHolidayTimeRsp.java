package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class YiyaHolidayTimeRsp extends JceStruct {
    public int iRet = 0;
    public long iTime = 0;
    public String sOrigin = "";

    public YiyaHolidayTimeRsp() {
    }

    public YiyaHolidayTimeRsp(int iRet2, String sOrigin2, long iTime2) {
        this.iRet = iRet2;
        this.sOrigin = sOrigin2;
        this.iTime = iTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iRet, 0);
        if (this.sOrigin != null) {
            _os.write(this.sOrigin, 1);
        }
        _os.write(this.iTime, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iRet = _is.read(this.iRet, 0, false);
        this.sOrigin = _is.readString(1, false);
        this.iTime = _is.read(this.iTime, 2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        YiyaHolidayTimeRsp temp = (YiyaHolidayTimeRsp) a.parseObject(text, YiyaHolidayTimeRsp.class);
        this.iRet = temp.iRet;
        this.sOrigin = temp.sOrigin;
        this.iTime = temp.iTime;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
