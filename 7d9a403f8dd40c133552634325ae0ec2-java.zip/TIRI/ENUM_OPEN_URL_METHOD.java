package TIRI;

import java.io.Serializable;

public final class ENUM_OPEN_URL_METHOD implements Serializable {
    public static final int _E_OPEN_URL_METHOD_BROWSER = 0;
    public static final int _E_OPEN_URL_METHOD_LAYER = 1;
}
