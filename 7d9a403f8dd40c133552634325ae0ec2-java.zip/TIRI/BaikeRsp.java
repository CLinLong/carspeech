package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class BaikeRsp extends JceStruct {
    public String sBaikeInfo = "";
    public String sKeyWord = "";
    public String sPageUrl = "";
    public String sPicUrl = "";

    public BaikeRsp() {
    }

    public BaikeRsp(String sKeyWord2, String sBaikeInfo2, String sPicUrl2, String sPageUrl2) {
        this.sKeyWord = sKeyWord2;
        this.sBaikeInfo = sBaikeInfo2;
        this.sPicUrl = sPicUrl2;
        this.sPageUrl = sPageUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sKeyWord != null) {
            _os.write(this.sKeyWord, 0);
        }
        if (this.sBaikeInfo != null) {
            _os.write(this.sBaikeInfo, 1);
        }
        if (this.sPicUrl != null) {
            _os.write(this.sPicUrl, 2);
        }
        if (this.sPageUrl != null) {
            _os.write(this.sPageUrl, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sKeyWord = _is.readString(0, false);
        this.sBaikeInfo = _is.readString(1, false);
        this.sPicUrl = _is.readString(2, false);
        this.sPageUrl = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        BaikeRsp temp = (BaikeRsp) a.parseObject(text, BaikeRsp.class);
        this.sKeyWord = temp.sKeyWord;
        this.sBaikeInfo = temp.sBaikeInfo;
        this.sPicUrl = temp.sPicUrl;
        this.sPageUrl = temp.sPageUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
