package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class PhoneLocation extends JceStruct {
    public String sCarreier = "";
    public String sCity = "";
    public String sNumber = "";
    public String sProvice = "";

    public PhoneLocation() {
    }

    public PhoneLocation(String sNumber2, String sProvice2, String sCity2, String sCarreier2) {
        this.sNumber = sNumber2;
        this.sProvice = sProvice2;
        this.sCity = sCity2;
        this.sCarreier = sCarreier2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sNumber != null) {
            _os.write(this.sNumber, 0);
        }
        if (this.sProvice != null) {
            _os.write(this.sProvice, 1);
        }
        if (this.sCity != null) {
            _os.write(this.sCity, 2);
        }
        if (this.sCarreier != null) {
            _os.write(this.sCarreier, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sNumber = _is.readString(0, false);
        this.sProvice = _is.readString(1, false);
        this.sCity = _is.readString(2, false);
        this.sCarreier = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        PhoneLocation temp = (PhoneLocation) a.parseObject(text, PhoneLocation.class);
        this.sNumber = temp.sNumber;
        this.sProvice = temp.sProvice;
        this.sCity = temp.sCity;
        this.sCarreier = temp.sCarreier;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
