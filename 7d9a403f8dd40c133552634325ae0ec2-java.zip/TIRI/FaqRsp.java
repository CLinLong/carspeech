package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class FaqRsp extends JceStruct {
    public int iFaqType = 0;

    public FaqRsp() {
    }

    public FaqRsp(int iFaqType2) {
        this.iFaqType = iFaqType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iFaqType, 0);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iFaqType = _is.read(this.iFaqType, 0, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        this.iFaqType = ((FaqRsp) a.parseObject(text, FaqRsp.class)).iFaqType;
    }
}
