package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class YiyaFaqRsp extends JceStruct {
    static ArrayList<YiyaFaqNode> cache_vecFaqNode = new ArrayList<>();
    public int iRequestType = 13000;
    public int iSpecialType = 0;
    public ArrayList<YiyaFaqNode> vecFaqNode = null;

    public YiyaFaqRsp() {
    }

    public YiyaFaqRsp(ArrayList<YiyaFaqNode> vecFaqNode2, int iSpecialType2, int iRequestType2) {
        this.vecFaqNode = vecFaqNode2;
        this.iSpecialType = iSpecialType2;
        this.iRequestType = iRequestType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vecFaqNode != null) {
            _os.write((Collection) this.vecFaqNode, 0);
        }
        _os.write(this.iSpecialType, 1);
        _os.write(this.iRequestType, 2);
    }

    static {
        cache_vecFaqNode.add(new YiyaFaqNode());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecFaqNode = (ArrayList) _is.read((Object) cache_vecFaqNode, 0, false);
        this.iSpecialType = _is.read(this.iSpecialType, 1, false);
        this.iRequestType = _is.read(this.iRequestType, 2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        YiyaFaqRsp temp = (YiyaFaqRsp) a.parseObject(text, YiyaFaqRsp.class);
        this.vecFaqNode = temp.vecFaqNode;
        this.iSpecialType = temp.iSpecialType;
        this.iRequestType = temp.iRequestType;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
