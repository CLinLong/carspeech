package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class YiyaFaqCardContentNode extends JceStruct {
    static ArrayList<String> cache_vecContent = new ArrayList<>();
    public ArrayList<String> vecContent = null;

    public YiyaFaqCardContentNode() {
    }

    public YiyaFaqCardContentNode(ArrayList<String> vecContent2) {
        this.vecContent = vecContent2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vecContent != null) {
            _os.write((Collection) this.vecContent, 1);
        }
    }

    static {
        cache_vecContent.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecContent = (ArrayList) _is.read((Object) cache_vecContent, 1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        this.vecContent = ((YiyaFaqCardContentNode) a.parseObject(text, YiyaFaqCardContentNode.class)).vecContent;
    }
}
