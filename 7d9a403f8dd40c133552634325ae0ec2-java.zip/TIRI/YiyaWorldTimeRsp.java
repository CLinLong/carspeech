package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class YiyaWorldTimeRsp extends JceStruct {
    public int iRet = 0;
    public long iTime = 0;
    public String sCity = "";
    public String sCountry = "";
    public String sOriginPlace = "";
    public String sState = "";

    public YiyaWorldTimeRsp() {
    }

    public YiyaWorldTimeRsp(int iRet2, String sOriginPlace2, String sCountry2, String sState2, String sCity2, long iTime2) {
        this.iRet = iRet2;
        this.sOriginPlace = sOriginPlace2;
        this.sCountry = sCountry2;
        this.sState = sState2;
        this.sCity = sCity2;
        this.iTime = iTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iRet, 0);
        if (this.sOriginPlace != null) {
            _os.write(this.sOriginPlace, 1);
        }
        if (this.sCountry != null) {
            _os.write(this.sCountry, 2);
        }
        if (this.sState != null) {
            _os.write(this.sState, 3);
        }
        if (this.sCity != null) {
            _os.write(this.sCity, 4);
        }
        _os.write(this.iTime, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iRet = _is.read(this.iRet, 0, false);
        this.sOriginPlace = _is.readString(1, false);
        this.sCountry = _is.readString(2, false);
        this.sState = _is.readString(3, false);
        this.sCity = _is.readString(4, false);
        this.iTime = _is.read(this.iTime, 5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        YiyaWorldTimeRsp temp = (YiyaWorldTimeRsp) a.parseObject(text, YiyaWorldTimeRsp.class);
        this.iRet = temp.iRet;
        this.sOriginPlace = temp.sOriginPlace;
        this.sCountry = temp.sCountry;
        this.sState = temp.sState;
        this.sCity = temp.sCity;
        this.iTime = temp.iTime;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
