package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AstroIntroduction extends JceStruct {
    public String sAstroBirthday = "";
    public String sAstroName = "";
    public String sAstroSigns = "";
    public String sAstroSymbolize = "";
    public String sBestMatch = "";
    public String sCharacter = "";
    public String sLogo = "";

    public AstroIntroduction() {
    }

    public AstroIntroduction(String sAstroName2, String sLogo2, String sAstroBirthday2, String sAstroSigns2, String sAstroSymbolize2, String sBestMatch2, String sCharacter2) {
        this.sAstroName = sAstroName2;
        this.sLogo = sLogo2;
        this.sAstroBirthday = sAstroBirthday2;
        this.sAstroSigns = sAstroSigns2;
        this.sAstroSymbolize = sAstroSymbolize2;
        this.sBestMatch = sBestMatch2;
        this.sCharacter = sCharacter2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sAstroName != null) {
            _os.write(this.sAstroName, 0);
        }
        if (this.sLogo != null) {
            _os.write(this.sLogo, 1);
        }
        if (this.sAstroBirthday != null) {
            _os.write(this.sAstroBirthday, 2);
        }
        if (this.sAstroSigns != null) {
            _os.write(this.sAstroSigns, 3);
        }
        if (this.sAstroSymbolize != null) {
            _os.write(this.sAstroSymbolize, 4);
        }
        if (this.sBestMatch != null) {
            _os.write(this.sBestMatch, 5);
        }
        if (this.sCharacter != null) {
            _os.write(this.sCharacter, 6);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAstroName = _is.readString(0, false);
        this.sLogo = _is.readString(1, false);
        this.sAstroBirthday = _is.readString(2, false);
        this.sAstroSigns = _is.readString(3, false);
        this.sAstroSymbolize = _is.readString(4, false);
        this.sBestMatch = _is.readString(5, false);
        this.sCharacter = _is.readString(6, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        AstroIntroduction temp = (AstroIntroduction) a.parseObject(text, AstroIntroduction.class);
        this.sAstroName = temp.sAstroName;
        this.sLogo = temp.sLogo;
        this.sAstroBirthday = temp.sAstroBirthday;
        this.sAstroSigns = temp.sAstroSigns;
        this.sAstroSymbolize = temp.sAstroSymbolize;
        this.sBestMatch = temp.sBestMatch;
        this.sCharacter = temp.sCharacter;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
