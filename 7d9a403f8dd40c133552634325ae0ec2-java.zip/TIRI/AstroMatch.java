package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AstroMatch extends JceStruct {
    static ArrayList<AstroMatchNode> cache_vcMatchNode = new ArrayList<>();
    public ArrayList<AstroMatchNode> vcMatchNode = null;

    public AstroMatch() {
    }

    public AstroMatch(ArrayList<AstroMatchNode> vcMatchNode2) {
        this.vcMatchNode = vcMatchNode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vcMatchNode != null) {
            _os.write((Collection) this.vcMatchNode, 0);
        }
    }

    static {
        cache_vcMatchNode.add(new AstroMatchNode());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vcMatchNode = (ArrayList) _is.read((Object) cache_vcMatchNode, 0, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        this.vcMatchNode = ((AstroMatch) a.parseObject(text, AstroMatch.class)).vcMatchNode;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
