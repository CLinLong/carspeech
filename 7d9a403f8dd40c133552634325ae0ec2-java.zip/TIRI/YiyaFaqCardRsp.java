package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class YiyaFaqCardRsp extends JceStruct {
    static int cache_iType = 0;
    static ArrayList<String> cache_vPicUrls = new ArrayList<>();
    static ArrayList<YiyaFaqCardContentNode> cache_vecContentNode = new ArrayList<>();
    public int iType = 0;
    public String sTitle = "";
    public ArrayList<String> vPicUrls = null;
    public ArrayList<YiyaFaqCardContentNode> vecContentNode = null;

    public YiyaFaqCardRsp() {
    }

    public YiyaFaqCardRsp(int iType2, String sTitle2, ArrayList<YiyaFaqCardContentNode> vecContentNode2, ArrayList<String> vPicUrls2) {
        this.iType = iType2;
        this.sTitle = sTitle2;
        this.vecContentNode = vecContentNode2;
        this.vPicUrls = vPicUrls2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iType, 0);
        if (this.sTitle != null) {
            _os.write(this.sTitle, 1);
        }
        if (this.vecContentNode != null) {
            _os.write((Collection) this.vecContentNode, 2);
        }
        if (this.vPicUrls != null) {
            _os.write((Collection) this.vPicUrls, 3);
        }
    }

    static {
        cache_vecContentNode.add(new YiyaFaqCardContentNode());
        cache_vPicUrls.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iType = _is.read(this.iType, 0, false);
        this.sTitle = _is.readString(1, false);
        this.vecContentNode = (ArrayList) _is.read((Object) cache_vecContentNode, 2, false);
        this.vPicUrls = (ArrayList) _is.read((Object) cache_vPicUrls, 3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        YiyaFaqCardRsp temp = (YiyaFaqCardRsp) a.parseObject(text, YiyaFaqCardRsp.class);
        this.iType = temp.iType;
        this.sTitle = temp.sTitle;
        this.vecContentNode = temp.vecContentNode;
        this.vPicUrls = temp.vPicUrls;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
