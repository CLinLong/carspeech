package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class PhoneAreaCodeVec extends JceStruct {
    static ArrayList<PhoneAreaCodeInfo> cache_vCode = new ArrayList<>();
    public ArrayList<PhoneAreaCodeInfo> vCode = null;

    public PhoneAreaCodeVec() {
    }

    public PhoneAreaCodeVec(ArrayList<PhoneAreaCodeInfo> vCode2) {
        this.vCode = vCode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vCode != null) {
            _os.write((Collection) this.vCode, 0);
        }
    }

    static {
        cache_vCode.add(new PhoneAreaCodeInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vCode = (ArrayList) _is.read((Object) cache_vCode, 0, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        this.vCode = ((PhoneAreaCodeVec) a.parseObject(text, PhoneAreaCodeVec.class)).vCode;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
