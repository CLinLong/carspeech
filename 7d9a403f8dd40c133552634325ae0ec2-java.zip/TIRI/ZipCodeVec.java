package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class ZipCodeVec extends JceStruct {
    static ArrayList<ZipCodeInfo> cache_vZip = new ArrayList<>();
    public int iCmdType = 0;
    public ArrayList<ZipCodeInfo> vZip = null;

    public ZipCodeVec() {
    }

    public ZipCodeVec(ArrayList<ZipCodeInfo> vZip2, int iCmdType2) {
        this.vZip = vZip2;
        this.iCmdType = iCmdType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vZip != null) {
            _os.write((Collection) this.vZip, 0);
        }
        _os.write(this.iCmdType, 1);
    }

    static {
        cache_vZip.add(new ZipCodeInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vZip = (ArrayList) _is.read((Object) cache_vZip, 0, false);
        this.iCmdType = _is.read(this.iCmdType, 1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        ZipCodeVec temp = (ZipCodeVec) a.parseObject(text, ZipCodeVec.class);
        this.vZip = temp.vZip;
        this.iCmdType = temp.iCmdType;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
