package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class OpenUrlRsp extends JceStruct {
    static int cache_enmOpenUrlMethod = 0;
    public int enmOpenUrlMethod = 0;
    public int iOpenUrlDelaySeconds = 3;
    public int iUseKeyword = 0;
    public String sKeyword = "";
    public String sURL = "";

    public OpenUrlRsp() {
    }

    public OpenUrlRsp(String sURL2, String sKeyword2, int iUseKeyword2, int enmOpenUrlMethod2, int iOpenUrlDelaySeconds2) {
        this.sURL = sURL2;
        this.sKeyword = sKeyword2;
        this.iUseKeyword = iUseKeyword2;
        this.enmOpenUrlMethod = enmOpenUrlMethod2;
        this.iOpenUrlDelaySeconds = iOpenUrlDelaySeconds2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sURL != null) {
            _os.write(this.sURL, 0);
        }
        if (this.sKeyword != null) {
            _os.write(this.sKeyword, 1);
        }
        _os.write(this.iUseKeyword, 2);
        _os.write(this.enmOpenUrlMethod, 3);
        _os.write(this.iOpenUrlDelaySeconds, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sURL = _is.readString(0, false);
        this.sKeyword = _is.readString(1, false);
        this.iUseKeyword = _is.read(this.iUseKeyword, 2, false);
        this.enmOpenUrlMethod = _is.read(this.enmOpenUrlMethod, 3, false);
        this.iOpenUrlDelaySeconds = _is.read(this.iOpenUrlDelaySeconds, 4, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        OpenUrlRsp temp = (OpenUrlRsp) a.parseObject(text, OpenUrlRsp.class);
        this.sURL = temp.sURL;
        this.sKeyword = temp.sKeyword;
        this.iUseKeyword = temp.iUseKeyword;
        this.enmOpenUrlMethod = temp.enmOpenUrlMethod;
        this.iOpenUrlDelaySeconds = temp.iOpenUrlDelaySeconds;
    }
}
