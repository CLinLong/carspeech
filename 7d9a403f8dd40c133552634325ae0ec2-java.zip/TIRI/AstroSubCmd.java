package TIRI;

import java.io.Serializable;

public final class AstroSubCmd implements Serializable {
    public static final int _ASTRO_SUBCMD_FORTUNE = 2;
    public static final int _ASTRO_SUBCMD_INTRODUCTION = 1;
    public static final int _ASTRO_SUBCMD_MATCH = 3;
}
