package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class GasPrice extends JceStruct {
    static ArrayList<GasPriceDesc> cache_vecGasPriceDesc = new ArrayList<>();
    public float fPrice1 = 0.0f;
    public float fPrice2 = 0.0f;
    public float fPrice3 = 0.0f;
    public float fPrice4 = 0.0f;
    public String sDistrict = "";
    public ArrayList<GasPriceDesc> vecGasPriceDesc = null;

    public GasPrice() {
    }

    public GasPrice(String sDistrict2, float fPrice12, float fPrice22, float fPrice32, float fPrice42, ArrayList<GasPriceDesc> vecGasPriceDesc2) {
        this.sDistrict = sDistrict2;
        this.fPrice1 = fPrice12;
        this.fPrice2 = fPrice22;
        this.fPrice3 = fPrice32;
        this.fPrice4 = fPrice42;
        this.vecGasPriceDesc = vecGasPriceDesc2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sDistrict != null) {
            _os.write(this.sDistrict, 0);
        }
        _os.write(this.fPrice1, 1);
        _os.write(this.fPrice2, 2);
        _os.write(this.fPrice3, 3);
        _os.write(this.fPrice4, 4);
        if (this.vecGasPriceDesc != null) {
            _os.write((Collection) this.vecGasPriceDesc, 5);
        }
    }

    static {
        cache_vecGasPriceDesc.add(new GasPriceDesc());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sDistrict = _is.readString(0, false);
        this.fPrice1 = _is.read(this.fPrice1, 1, false);
        this.fPrice2 = _is.read(this.fPrice2, 2, false);
        this.fPrice3 = _is.read(this.fPrice3, 3, false);
        this.fPrice4 = _is.read(this.fPrice4, 4, false);
        this.vecGasPriceDesc = (ArrayList) _is.read((Object) cache_vecGasPriceDesc, 5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        GasPrice temp = (GasPrice) a.parseObject(text, GasPrice.class);
        this.sDistrict = temp.sDistrict;
        this.fPrice1 = temp.fPrice1;
        this.fPrice2 = temp.fPrice2;
        this.fPrice3 = temp.fPrice3;
        this.fPrice4 = temp.fPrice4;
        this.vecGasPriceDesc = temp.vecGasPriceDesc;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
