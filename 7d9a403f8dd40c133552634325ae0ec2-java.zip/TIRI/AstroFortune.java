package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AstroFortune extends JceStruct {
    public int iFortuneLevel = 0;
    public String sAstroName = "";
    public String sFortuneDesc = "";
    public String sFortuneType = "";
    public String sLogo = "";
    public String sValidDate = "";

    public AstroFortune() {
    }

    public AstroFortune(String sAstroName2, String sLogo2, String sFortuneType2, String sValidDate2, int iFortuneLevel2, String sFortuneDesc2) {
        this.sAstroName = sAstroName2;
        this.sLogo = sLogo2;
        this.sFortuneType = sFortuneType2;
        this.sValidDate = sValidDate2;
        this.iFortuneLevel = iFortuneLevel2;
        this.sFortuneDesc = sFortuneDesc2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sAstroName != null) {
            _os.write(this.sAstroName, 0);
        }
        if (this.sLogo != null) {
            _os.write(this.sLogo, 1);
        }
        if (this.sFortuneType != null) {
            _os.write(this.sFortuneType, 2);
        }
        if (this.sValidDate != null) {
            _os.write(this.sValidDate, 3);
        }
        _os.write(this.iFortuneLevel, 4);
        if (this.sFortuneDesc != null) {
            _os.write(this.sFortuneDesc, 5);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAstroName = _is.readString(0, false);
        this.sLogo = _is.readString(1, false);
        this.sFortuneType = _is.readString(2, false);
        this.sValidDate = _is.readString(3, false);
        this.iFortuneLevel = _is.read(this.iFortuneLevel, 4, false);
        this.sFortuneDesc = _is.readString(5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        AstroFortune temp = (AstroFortune) a.parseObject(text, AstroFortune.class);
        this.sAstroName = temp.sAstroName;
        this.sLogo = temp.sLogo;
        this.sFortuneType = temp.sFortuneType;
        this.sValidDate = temp.sValidDate;
        this.iFortuneLevel = temp.iFortuneLevel;
        this.sFortuneDesc = temp.sFortuneDesc;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
