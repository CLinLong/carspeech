package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class GasPriceDesc extends JceStruct {
    public float gasprice = 0.0f;
    public String gastype = "";

    public GasPriceDesc() {
    }

    public GasPriceDesc(float gasprice2, String gastype2) {
        this.gasprice = gasprice2;
        this.gastype = gastype2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.gasprice, 0);
        if (this.gastype != null) {
            _os.write(this.gastype, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.gasprice = _is.read(this.gasprice, 0, false);
        this.gastype = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        GasPriceDesc temp = (GasPriceDesc) a.parseObject(text, GasPriceDesc.class);
        this.gasprice = temp.gasprice;
        this.gastype = temp.gastype;
    }
}
