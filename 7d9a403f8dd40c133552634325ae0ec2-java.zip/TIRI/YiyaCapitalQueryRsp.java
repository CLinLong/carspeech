package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class YiyaCapitalQueryRsp extends JceStruct {
    public int iRet = 0;
    public String sCapitalName = "";
    public String sCountryName = "";

    public YiyaCapitalQueryRsp() {
    }

    public YiyaCapitalQueryRsp(int iRet2, String sCountryName2, String sCapitalName2) {
        this.iRet = iRet2;
        this.sCountryName = sCountryName2;
        this.sCapitalName = sCapitalName2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iRet, 0);
        if (this.sCountryName != null) {
            _os.write(this.sCountryName, 1);
        }
        if (this.sCapitalName != null) {
            _os.write(this.sCapitalName, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iRet = _is.read(this.iRet, 0, false);
        this.sCountryName = _is.readString(1, false);
        this.sCapitalName = _is.readString(2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        YiyaCapitalQueryRsp temp = (YiyaCapitalQueryRsp) a.parseObject(text, YiyaCapitalQueryRsp.class);
        this.iRet = temp.iRet;
        this.sCountryName = temp.sCountryName;
        this.sCapitalName = temp.sCapitalName;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
