package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AstroMatchNode extends JceStruct {
    public int iAQLevel = 0;
    public int iHYLevel = 0;
    public int iMatchLevel = 0;
    public int iQQLevel = 0;
    public int iYQLevel = 0;
    public String sAstroName = "";
    public String sLogo = "";
    public String sMatchAstroLogo = "";
    public String sMatchAstroName = "";
    public String sMatchDesc = "";

    public AstroMatchNode() {
    }

    public AstroMatchNode(String sAstroName2, String sLogo2, String sMatchAstroName2, String sMatchAstroLogo2, int iQQLevel2, int iAQLevel2, int iYQLevel2, int iHYLevel2, int iMatchLevel2, String sMatchDesc2) {
        this.sAstroName = sAstroName2;
        this.sLogo = sLogo2;
        this.sMatchAstroName = sMatchAstroName2;
        this.sMatchAstroLogo = sMatchAstroLogo2;
        this.iQQLevel = iQQLevel2;
        this.iAQLevel = iAQLevel2;
        this.iYQLevel = iYQLevel2;
        this.iHYLevel = iHYLevel2;
        this.iMatchLevel = iMatchLevel2;
        this.sMatchDesc = sMatchDesc2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sAstroName != null) {
            _os.write(this.sAstroName, 0);
        }
        if (this.sLogo != null) {
            _os.write(this.sLogo, 1);
        }
        if (this.sMatchAstroName != null) {
            _os.write(this.sMatchAstroName, 2);
        }
        if (this.sMatchAstroLogo != null) {
            _os.write(this.sMatchAstroLogo, 3);
        }
        _os.write(this.iQQLevel, 4);
        _os.write(this.iAQLevel, 5);
        _os.write(this.iYQLevel, 6);
        _os.write(this.iHYLevel, 7);
        _os.write(this.iMatchLevel, 8);
        if (this.sMatchDesc != null) {
            _os.write(this.sMatchDesc, 9);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAstroName = _is.readString(0, false);
        this.sLogo = _is.readString(1, false);
        this.sMatchAstroName = _is.readString(2, false);
        this.sMatchAstroLogo = _is.readString(3, false);
        this.iQQLevel = _is.read(this.iQQLevel, 4, false);
        this.iAQLevel = _is.read(this.iAQLevel, 5, false);
        this.iYQLevel = _is.read(this.iYQLevel, 6, false);
        this.iHYLevel = _is.read(this.iHYLevel, 7, false);
        this.iMatchLevel = _is.read(this.iMatchLevel, 8, false);
        this.sMatchDesc = _is.readString(9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        AstroMatchNode temp = (AstroMatchNode) a.parseObject(text, AstroMatchNode.class);
        this.sAstroName = temp.sAstroName;
        this.sLogo = temp.sLogo;
        this.sMatchAstroName = temp.sMatchAstroName;
        this.sMatchAstroLogo = temp.sMatchAstroLogo;
        this.iQQLevel = temp.iQQLevel;
        this.iAQLevel = temp.iAQLevel;
        this.iYQLevel = temp.iYQLevel;
        this.iHYLevel = temp.iHYLevel;
        this.iMatchLevel = temp.iMatchLevel;
        this.sMatchDesc = temp.sMatchDesc;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
