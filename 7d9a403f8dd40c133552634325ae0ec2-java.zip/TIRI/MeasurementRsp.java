package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class MeasurementRsp extends JceStruct {
    public int iRet = 0;
    public String sDesc = "";
    public String sResult = "";

    public MeasurementRsp() {
    }

    public MeasurementRsp(int iRet2, String sDesc2, String sResult2) {
        this.iRet = iRet2;
        this.sDesc = sDesc2;
        this.sResult = sResult2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iRet, 0);
        if (this.sDesc != null) {
            _os.write(this.sDesc, 1);
        }
        if (this.sResult != null) {
            _os.write(this.sResult, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iRet = _is.read(this.iRet, 0, false);
        this.sDesc = _is.readString(1, false);
        this.sResult = _is.readString(2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        MeasurementRsp temp = (MeasurementRsp) a.parseObject(text, MeasurementRsp.class);
        this.iRet = temp.iRet;
        this.sDesc = temp.sDesc;
        this.sResult = temp.sResult;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
