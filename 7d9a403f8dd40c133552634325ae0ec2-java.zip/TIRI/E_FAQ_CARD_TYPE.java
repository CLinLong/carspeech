package TIRI;

import java.io.Serializable;

public final class E_FAQ_CARD_TYPE implements Serializable {
    public static final int _E_FAQ_CARD_TYPE_BLANK = 2;
    public static final int _E_FAQ_CARD_TYPE_DEFAULT = 0;
    public static final int _E_FAQ_CARD_TYPE_WITH_LINE = 1;
}
