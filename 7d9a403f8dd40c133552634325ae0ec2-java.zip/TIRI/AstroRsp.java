package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AstroRsp extends JceStruct {
    static byte[] cache_vcData = new byte[1];
    public int iSubCmd = 0;
    public String sMoreUrl = "";
    public byte[] vcData = null;

    public AstroRsp() {
    }

    public AstroRsp(int iSubCmd2, byte[] vcData2, String sMoreUrl2) {
        this.iSubCmd = iSubCmd2;
        this.vcData = vcData2;
        this.sMoreUrl = sMoreUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iSubCmd, 0);
        if (this.vcData != null) {
            _os.write(this.vcData, 1);
        }
        if (this.sMoreUrl != null) {
            _os.write(this.sMoreUrl, 2);
        }
    }

    static {
        cache_vcData[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iSubCmd = _is.read(this.iSubCmd, 0, false);
        this.vcData = _is.read(cache_vcData, 1, false);
        this.sMoreUrl = _is.readString(2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        AstroRsp temp = (AstroRsp) a.parseObject(text, AstroRsp.class);
        this.iSubCmd = temp.iSubCmd;
        this.vcData = temp.vcData;
        this.sMoreUrl = temp.sMoreUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
