package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class GoldPrice extends JceStruct {
    public String sDollarGoldName = "";
    public String sDollarIncrease = "";
    public String sDollarPrice = "";
    public String sRmbGoldName = "";
    public String sRmbIncrease = "";
    public String sRmbPrice = "";

    public GoldPrice() {
    }

    public GoldPrice(String sDollarPrice2, String sDollarIncrease2, String sDollarGoldName2, String sRmbPrice2, String sRmbIncrease2, String sRmbGoldName2) {
        this.sDollarPrice = sDollarPrice2;
        this.sDollarIncrease = sDollarIncrease2;
        this.sDollarGoldName = sDollarGoldName2;
        this.sRmbPrice = sRmbPrice2;
        this.sRmbIncrease = sRmbIncrease2;
        this.sRmbGoldName = sRmbGoldName2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sDollarPrice != null) {
            _os.write(this.sDollarPrice, 0);
        }
        if (this.sDollarIncrease != null) {
            _os.write(this.sDollarIncrease, 1);
        }
        if (this.sDollarGoldName != null) {
            _os.write(this.sDollarGoldName, 2);
        }
        if (this.sRmbPrice != null) {
            _os.write(this.sRmbPrice, 3);
        }
        if (this.sRmbIncrease != null) {
            _os.write(this.sRmbIncrease, 4);
        }
        if (this.sRmbGoldName != null) {
            _os.write(this.sRmbGoldName, 5);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sDollarPrice = _is.readString(0, false);
        this.sDollarIncrease = _is.readString(1, false);
        this.sDollarGoldName = _is.readString(2, false);
        this.sRmbPrice = _is.readString(3, false);
        this.sRmbIncrease = _is.readString(4, false);
        this.sRmbGoldName = _is.readString(5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        GoldPrice temp = (GoldPrice) a.parseObject(text, GoldPrice.class);
        this.sDollarPrice = temp.sDollarPrice;
        this.sDollarIncrease = temp.sDollarIncrease;
        this.sDollarGoldName = temp.sDollarGoldName;
        this.sRmbPrice = temp.sRmbPrice;
        this.sRmbIncrease = temp.sRmbIncrease;
        this.sRmbGoldName = temp.sRmbGoldName;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
