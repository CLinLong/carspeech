package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ExchangeRsp extends JceStruct {
    public double dNumber1 = 0.0d;
    public double dNumber2 = 0.0d;
    public int iRet = 0;
    public long lTime = 0;
    public String sCurrency1 = "";
    public String sCurrency2 = "";

    public ExchangeRsp() {
    }

    public ExchangeRsp(int iRet2, double dNumber12, double dNumber22, String sCurrency12, String sCurrency22, long lTime2) {
        this.iRet = iRet2;
        this.dNumber1 = dNumber12;
        this.dNumber2 = dNumber22;
        this.sCurrency1 = sCurrency12;
        this.sCurrency2 = sCurrency22;
        this.lTime = lTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iRet, 0);
        _os.write(this.dNumber1, 1);
        _os.write(this.dNumber2, 2);
        if (this.sCurrency1 != null) {
            _os.write(this.sCurrency1, 3);
        }
        if (this.sCurrency2 != null) {
            _os.write(this.sCurrency2, 4);
        }
        _os.write(this.lTime, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iRet = _is.read(this.iRet, 0, false);
        this.dNumber1 = _is.read(this.dNumber1, 1, false);
        this.dNumber2 = _is.read(this.dNumber2, 2, false);
        this.sCurrency1 = _is.readString(3, false);
        this.sCurrency2 = _is.readString(4, false);
        this.lTime = _is.read(this.lTime, 5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        ExchangeRsp temp = (ExchangeRsp) a.parseObject(text, ExchangeRsp.class);
        this.iRet = temp.iRet;
        this.dNumber1 = temp.dNumber1;
        this.dNumber2 = temp.dNumber2;
        this.sCurrency1 = temp.sCurrency1;
        this.sCurrency2 = temp.sCurrency2;
        this.lTime = temp.lTime;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
