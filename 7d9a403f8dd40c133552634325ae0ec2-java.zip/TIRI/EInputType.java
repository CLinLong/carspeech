package TIRI;

import java.io.Serializable;

public final class EInputType implements Serializable {
    public static final int _iGrettingTipsClickFlag = 14000;
    public static final int _iMultiSceneClickFlag = 11000;
    public static final int _iPureTextFlag = 10000;
    public static final int _iPureTextInputFlag = 12000;
    public static final int _iRichFaqClickFlag = 13000;
    public static final int _iUnknowQuestionClickFlag = 15000;
}
