package TIRI;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class YiyaFaqNode extends JceStruct {
    public int iNodeType = 0;
    public String sExtraInfo = "";
    public String sReadInfo = "";
    public String sTextInfo = "";

    public YiyaFaqNode() {
    }

    public YiyaFaqNode(String sTextInfo2, String sReadInfo2, String sExtraInfo2, int iNodeType2) {
        this.sTextInfo = sTextInfo2;
        this.sReadInfo = sReadInfo2;
        this.sExtraInfo = sExtraInfo2;
        this.iNodeType = iNodeType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sTextInfo != null) {
            _os.write(this.sTextInfo, 0);
        }
        if (this.sReadInfo != null) {
            _os.write(this.sReadInfo, 1);
        }
        if (this.sExtraInfo != null) {
            _os.write(this.sExtraInfo, 2);
        }
        _os.write(this.iNodeType, 3);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sTextInfo = _is.readString(0, false);
        this.sReadInfo = _is.readString(1, false);
        this.sExtraInfo = _is.readString(2, false);
        this.iNodeType = _is.read(this.iNodeType, 3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        YiyaFaqNode temp = (YiyaFaqNode) a.parseObject(text, YiyaFaqNode.class);
        this.sTextInfo = temp.sTextInfo;
        this.sReadInfo = temp.sReadInfo;
        this.sExtraInfo = temp.sExtraInfo;
        this.iNodeType = temp.iNodeType;
    }
}
