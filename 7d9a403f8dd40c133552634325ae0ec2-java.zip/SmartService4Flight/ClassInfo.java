package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ClassInfo extends JceStruct {
    public int iClassCode = 0;
    public String strClassName = "";
    public String strSubClass = "";

    public ClassInfo() {
    }

    public ClassInfo(int iClassCode2, String strClassName2, String strSubClass2) {
        this.iClassCode = iClassCode2;
        this.strClassName = strClassName2;
        this.strSubClass = strSubClass2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iClassCode, 0);
        _os.write(this.strClassName, 1);
        _os.write(this.strSubClass, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iClassCode = _is.read(this.iClassCode, 0, true);
        this.strClassName = _is.readString(1, true);
        this.strSubClass = _is.readString(2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        ClassInfo temp = (ClassInfo) a.parseObject(text, ClassInfo.class);
        this.iClassCode = temp.iClassCode;
        this.strClassName = temp.strClassName;
        this.strSubClass = temp.strSubClass;
    }
}
