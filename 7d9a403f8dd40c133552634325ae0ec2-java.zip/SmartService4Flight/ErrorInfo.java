package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ErrorInfo extends JceStruct {
    public int iErrorCode = 0;
    public String strErrorMsg = "";

    public ErrorInfo() {
    }

    public ErrorInfo(int iErrorCode2, String strErrorMsg2) {
        this.iErrorCode = iErrorCode2;
        this.strErrorMsg = strErrorMsg2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iErrorCode, 0);
        _os.write(this.strErrorMsg, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iErrorCode = _is.read(this.iErrorCode, 0, true);
        this.strErrorMsg = _is.readString(1, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        ErrorInfo temp = (ErrorInfo) a.parseObject(text, ErrorInfo.class);
        this.iErrorCode = temp.iErrorCode;
        this.strErrorMsg = temp.strErrorMsg;
    }
}
