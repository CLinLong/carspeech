package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class CraftInfo extends JceStruct {
    public String strCraftCode = "";
    public String strCraftName = "";
    public String strKind = "";

    public CraftInfo() {
    }

    public CraftInfo(String strCraftCode2, String strCraftName2, String strKind2) {
        this.strCraftCode = strCraftCode2;
        this.strCraftName = strCraftName2;
        this.strKind = strKind2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strCraftCode, 0);
        if (this.strCraftName != null) {
            _os.write(this.strCraftName, 1);
        }
        if (this.strKind != null) {
            _os.write(this.strKind, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strCraftCode = _is.readString(0, true);
        this.strCraftName = _is.readString(1, false);
        this.strKind = _is.readString(2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        CraftInfo temp = (CraftInfo) a.parseObject(text, CraftInfo.class);
        this.strCraftCode = temp.strCraftCode;
        this.strCraftName = temp.strCraftName;
        this.strKind = temp.strKind;
    }
}
