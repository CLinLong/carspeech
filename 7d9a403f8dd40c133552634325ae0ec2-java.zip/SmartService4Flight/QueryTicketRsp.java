package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QueryTicketRsp extends JceStruct {
    static ErrorInfo cache_sErrorInfo = new ErrorInfo();
    static QueryTicketParams cache_sQueryParams = new QueryTicketParams();
    static ArrayList<Flight> cache_vFlightList = new ArrayList<>();
    public ErrorInfo sErrorInfo = null;
    public QueryTicketParams sQueryParams = null;
    public String strMoreUrl = "";
    public ArrayList<Flight> vFlightList = null;

    public QueryTicketRsp() {
    }

    public QueryTicketRsp(ArrayList<Flight> vFlightList2, QueryTicketParams sQueryParams2, String strMoreUrl2, ErrorInfo sErrorInfo2) {
        this.vFlightList = vFlightList2;
        this.sQueryParams = sQueryParams2;
        this.strMoreUrl = strMoreUrl2;
        this.sErrorInfo = sErrorInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vFlightList, 0);
        if (this.sQueryParams != null) {
            _os.write((JceStruct) this.sQueryParams, 1);
        }
        if (this.strMoreUrl != null) {
            _os.write(this.strMoreUrl, 2);
        }
        if (this.sErrorInfo != null) {
            _os.write((JceStruct) this.sErrorInfo, 3);
        }
    }

    static {
        cache_vFlightList.add(new Flight());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vFlightList = (ArrayList) _is.read((Object) cache_vFlightList, 0, true);
        this.sQueryParams = (QueryTicketParams) _is.read((JceStruct) cache_sQueryParams, 1, false);
        this.strMoreUrl = _is.readString(2, false);
        this.sErrorInfo = (ErrorInfo) _is.read((JceStruct) cache_sErrorInfo, 3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QueryTicketRsp temp = (QueryTicketRsp) a.parseObject(text, QueryTicketRsp.class);
        this.vFlightList = temp.vFlightList;
        this.sQueryParams = temp.sQueryParams;
        this.strMoreUrl = temp.strMoreUrl;
        this.sErrorInfo = temp.sErrorInfo;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
