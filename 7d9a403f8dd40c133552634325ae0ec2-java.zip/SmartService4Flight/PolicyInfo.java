package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class PolicyInfo extends JceStruct {
    static ArrayList<ClassInfo> cache_vClassInfoList = new ArrayList<>();
    static ArrayList<PolicyPackage> cache_vPolicyPkgList = new ArrayList<>();
    public float fDiscountRate = 0.0f;
    public float fReturnDiscount = 0.0f;
    public int iFlag = 0;
    public int iPrice = 0;
    public int iRemainCount = 0;
    public int iReturnCash = 0;
    public String strPolicyName = "";
    public String strProductId = "";
    public ArrayList<ClassInfo> vClassInfoList = null;
    public ArrayList<PolicyPackage> vPolicyPkgList = null;

    public PolicyInfo() {
    }

    public PolicyInfo(String strProductId2, int iFlag2, String strPolicyName2, float fReturnDiscount2, ArrayList<ClassInfo> vClassInfoList2, float fDiscountRate2, int iPrice2, int iRemainCount2, int iReturnCash2, ArrayList<PolicyPackage> vPolicyPkgList2) {
        this.strProductId = strProductId2;
        this.iFlag = iFlag2;
        this.strPolicyName = strPolicyName2;
        this.fReturnDiscount = fReturnDiscount2;
        this.vClassInfoList = vClassInfoList2;
        this.fDiscountRate = fDiscountRate2;
        this.iPrice = iPrice2;
        this.iRemainCount = iRemainCount2;
        this.iReturnCash = iReturnCash2;
        this.vPolicyPkgList = vPolicyPkgList2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strProductId, 0);
        _os.write(this.iFlag, 1);
        _os.write(this.strPolicyName, 2);
        _os.write(this.fReturnDiscount, 3);
        _os.write((Collection) this.vClassInfoList, 4);
        _os.write(this.fDiscountRate, 5);
        _os.write(this.iPrice, 6);
        _os.write(this.iRemainCount, 7);
        _os.write(this.iReturnCash, 8);
        _os.write((Collection) this.vPolicyPkgList, 9);
    }

    static {
        cache_vClassInfoList.add(new ClassInfo());
        cache_vPolicyPkgList.add(new PolicyPackage());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strProductId = _is.readString(0, true);
        this.iFlag = _is.read(this.iFlag, 1, true);
        this.strPolicyName = _is.readString(2, true);
        this.fReturnDiscount = _is.read(this.fReturnDiscount, 3, true);
        this.vClassInfoList = (ArrayList) _is.read((Object) cache_vClassInfoList, 4, true);
        this.fDiscountRate = _is.read(this.fDiscountRate, 5, true);
        this.iPrice = _is.read(this.iPrice, 6, true);
        this.iRemainCount = _is.read(this.iRemainCount, 7, true);
        this.iReturnCash = _is.read(this.iReturnCash, 8, true);
        this.vPolicyPkgList = (ArrayList) _is.read((Object) cache_vPolicyPkgList, 9, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        PolicyInfo temp = (PolicyInfo) a.parseObject(text, PolicyInfo.class);
        this.strProductId = temp.strProductId;
        this.iFlag = temp.iFlag;
        this.strPolicyName = temp.strPolicyName;
        this.fReturnDiscount = temp.fReturnDiscount;
        this.vClassInfoList = temp.vClassInfoList;
        this.fDiscountRate = temp.fDiscountRate;
        this.iPrice = temp.iPrice;
        this.iRemainCount = temp.iRemainCount;
        this.iReturnCash = temp.iReturnCash;
        this.vPolicyPkgList = temp.vPolicyPkgList;
    }
}
