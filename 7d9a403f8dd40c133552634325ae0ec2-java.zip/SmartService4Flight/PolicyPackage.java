package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class PolicyPackage extends JceStruct {
    public float fPrice = 0.0f;
    public int iPkgType = 0;
    public String strPkgName = "";

    public PolicyPackage() {
    }

    public PolicyPackage(int iPkgType2, String strPkgName2, float fPrice2) {
        this.iPkgType = iPkgType2;
        this.strPkgName = strPkgName2;
        this.fPrice = fPrice2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iPkgType, 0);
        _os.write(this.strPkgName, 1);
        _os.write(this.fPrice, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iPkgType = _is.read(this.iPkgType, 0, true);
        this.strPkgName = _is.readString(1, true);
        this.fPrice = _is.read(this.fPrice, 2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        PolicyPackage temp = (PolicyPackage) a.parseObject(text, PolicyPackage.class);
        this.iPkgType = temp.iPkgType;
        this.strPkgName = temp.strPkgName;
        this.fPrice = temp.fPrice;
    }
}
