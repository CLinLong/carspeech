package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class EndpointInfo extends JceStruct {
    static Airport cache_sAirport = new Airport();
    public Airport sAirport = null;
    public String strTerminal = "";

    public EndpointInfo() {
    }

    public EndpointInfo(Airport sAirport2, String strTerminal2) {
        this.sAirport = sAirport2;
        this.strTerminal = strTerminal2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.sAirport, 0);
        _os.write(this.strTerminal, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAirport = (Airport) _is.read((JceStruct) cache_sAirport, 0, true);
        this.strTerminal = _is.readString(1, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        EndpointInfo temp = (EndpointInfo) a.parseObject(text, EndpointInfo.class);
        this.sAirport = temp.sAirport;
        this.strTerminal = temp.strTerminal;
    }
}
