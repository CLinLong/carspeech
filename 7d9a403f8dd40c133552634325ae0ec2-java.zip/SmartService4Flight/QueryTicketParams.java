package SmartService4Flight;

import SmartAssistant.UserBase;
import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class QueryTicketParams extends JceStruct {
    static UserBase cache_userBase = new UserBase();
    public String strDate = "";
    public String strFrom = "";
    public String strFromAirport = "";
    public String strFromAirportCode = "";
    public String strFromCode = "";
    public String strPeroidEnd = "";
    public String strPeroidStart = "";
    public String strTime = "";
    public String strTo = "";
    public String strToAirport = "";
    public String strToAirportCode = "";
    public String strToCode = "";
    public UserBase userBase = null;

    public QueryTicketParams() {
    }

    public QueryTicketParams(String strFromAirport2, String strFromAirportCode2, String strToAirport2, String strToAirportCode2, String strDate2, UserBase userBase2, String strFrom2, String strTo2, String strTime2, String strPeroidStart2, String strPeroidEnd2, String strFromCode2, String strToCode2) {
        this.strFromAirport = strFromAirport2;
        this.strFromAirportCode = strFromAirportCode2;
        this.strToAirport = strToAirport2;
        this.strToAirportCode = strToAirportCode2;
        this.strDate = strDate2;
        this.userBase = userBase2;
        this.strFrom = strFrom2;
        this.strTo = strTo2;
        this.strTime = strTime2;
        this.strPeroidStart = strPeroidStart2;
        this.strPeroidEnd = strPeroidEnd2;
        this.strFromCode = strFromCode2;
        this.strToCode = strToCode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strFromAirport, 0);
        _os.write(this.strFromAirportCode, 1);
        _os.write(this.strToAirport, 2);
        _os.write(this.strToAirportCode, 3);
        _os.write(this.strDate, 4);
        _os.write((JceStruct) this.userBase, 5);
        if (this.strFrom != null) {
            _os.write(this.strFrom, 6);
        }
        if (this.strTo != null) {
            _os.write(this.strTo, 7);
        }
        if (this.strTime != null) {
            _os.write(this.strTime, 8);
        }
        if (this.strPeroidStart != null) {
            _os.write(this.strPeroidStart, 9);
        }
        if (this.strPeroidEnd != null) {
            _os.write(this.strPeroidEnd, 10);
        }
        if (this.strFromCode != null) {
            _os.write(this.strFromCode, 11);
        }
        if (this.strToCode != null) {
            _os.write(this.strToCode, 12);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strFromAirport = _is.readString(0, true);
        this.strFromAirportCode = _is.readString(1, true);
        this.strToAirport = _is.readString(2, true);
        this.strToAirportCode = _is.readString(3, true);
        this.strDate = _is.readString(4, true);
        this.userBase = (UserBase) _is.read((JceStruct) cache_userBase, 5, true);
        this.strFrom = _is.readString(6, false);
        this.strTo = _is.readString(7, false);
        this.strTime = _is.readString(8, false);
        this.strPeroidStart = _is.readString(9, false);
        this.strPeroidEnd = _is.readString(10, false);
        this.strFromCode = _is.readString(11, false);
        this.strToCode = _is.readString(12, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QueryTicketParams temp = (QueryTicketParams) a.parseObject(text, QueryTicketParams.class);
        this.strFromAirport = temp.strFromAirport;
        this.strFromAirportCode = temp.strFromAirportCode;
        this.strToAirport = temp.strToAirport;
        this.strToAirportCode = temp.strToAirportCode;
        this.strDate = temp.strDate;
        this.userBase = temp.userBase;
        this.strFrom = temp.strFrom;
        this.strTo = temp.strTo;
        this.strTime = temp.strTime;
        this.strPeroidStart = temp.strPeroidStart;
        this.strPeroidEnd = temp.strPeroidEnd;
        this.strFromCode = temp.strFromCode;
        this.strToCode = temp.strToCode;
    }
}
