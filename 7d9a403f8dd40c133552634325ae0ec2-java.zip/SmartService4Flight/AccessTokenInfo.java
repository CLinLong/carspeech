package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AccessTokenInfo extends JceStruct {
    public long lExpiresIn = 0;
    public String strAccessToken = "";
    public String strAllianceId = "";
    public String strRefreshToken = "";
    public String strSId = "";

    public AccessTokenInfo() {
    }

    public AccessTokenInfo(String strSId2, String strAllianceId2, String strAccessToken2, long lExpiresIn2, String strRefreshToken2) {
        this.strSId = strSId2;
        this.strAllianceId = strAllianceId2;
        this.strAccessToken = strAccessToken2;
        this.lExpiresIn = lExpiresIn2;
        this.strRefreshToken = strRefreshToken2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strSId, 0);
        _os.write(this.strAllianceId, 1);
        _os.write(this.strAccessToken, 2);
        _os.write(this.lExpiresIn, 3);
        _os.write(this.strRefreshToken, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strSId = _is.readString(0, true);
        this.strAllianceId = _is.readString(1, true);
        this.strAccessToken = _is.readString(2, true);
        this.lExpiresIn = _is.read(this.lExpiresIn, 3, true);
        this.strRefreshToken = _is.readString(4, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        AccessTokenInfo temp = (AccessTokenInfo) a.parseObject(text, AccessTokenInfo.class);
        this.strSId = temp.strSId;
        this.strAllianceId = temp.strAllianceId;
        this.strAccessToken = temp.strAccessToken;
        this.lExpiresIn = temp.lExpiresIn;
        this.strRefreshToken = temp.strRefreshToken;
    }
}
