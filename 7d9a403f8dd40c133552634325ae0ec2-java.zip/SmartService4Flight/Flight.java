package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class Flight extends JceStruct {
    static CraftInfo cache_sCraftInfo = new CraftInfo();
    static EndpointInfo cache_sDestination = new EndpointInfo();
    static EndpointInfo cache_sOrigin = new EndpointInfo();
    static ArrayList<PolicyInfo> cache_vPolicyInfoList = new ArrayList<>();
    static ArrayList<StopCityInfo> cache_vStopCityInfoList = new ArrayList<>();
    public boolean bIsShared = true;
    public boolean bIsStop = true;
    public float fBottomPrice = 0.0f;
    public long lArriveTimestamp = 0;
    public long lDepartTimestamp = 0;
    public CraftInfo sCraftInfo = null;
    public EndpointInfo sDestination = null;
    public EndpointInfo sOrigin = null;
    public String strBuyTicketUrl = "";
    public String strComfort = "";
    public String strCompanyCode = "";
    public String strCompanyName = "";
    public String strFlightNo = "";
    public String strIconUrl = "";
    public ArrayList<PolicyInfo> vPolicyInfoList = null;
    public ArrayList<StopCityInfo> vStopCityInfoList = null;

    public Flight() {
    }

    public Flight(String strFlightNo2, String strCompanyCode2, String strCompanyName2, EndpointInfo sOrigin2, EndpointInfo sDestination2, long lDepartTimestamp2, long lArriveTimestamp2, CraftInfo sCraftInfo2, ArrayList<PolicyInfo> vPolicyInfoList2, boolean bIsShared2, String strComfort2, boolean bIsStop2, ArrayList<StopCityInfo> vStopCityInfoList2, String strBuyTicketUrl2, float fBottomPrice2, String strIconUrl2) {
        this.strFlightNo = strFlightNo2;
        this.strCompanyCode = strCompanyCode2;
        this.strCompanyName = strCompanyName2;
        this.sOrigin = sOrigin2;
        this.sDestination = sDestination2;
        this.lDepartTimestamp = lDepartTimestamp2;
        this.lArriveTimestamp = lArriveTimestamp2;
        this.sCraftInfo = sCraftInfo2;
        this.vPolicyInfoList = vPolicyInfoList2;
        this.bIsShared = bIsShared2;
        this.strComfort = strComfort2;
        this.bIsStop = bIsStop2;
        this.vStopCityInfoList = vStopCityInfoList2;
        this.strBuyTicketUrl = strBuyTicketUrl2;
        this.fBottomPrice = fBottomPrice2;
        this.strIconUrl = strIconUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strFlightNo, 0);
        _os.write(this.strCompanyCode, 1);
        _os.write(this.strCompanyName, 2);
        _os.write((JceStruct) this.sOrigin, 3);
        _os.write((JceStruct) this.sDestination, 4);
        _os.write(this.lDepartTimestamp, 5);
        _os.write(this.lArriveTimestamp, 6);
        _os.write((JceStruct) this.sCraftInfo, 7);
        _os.write((Collection) this.vPolicyInfoList, 8);
        _os.write(this.bIsShared, 9);
        if (this.strComfort != null) {
            _os.write(this.strComfort, 10);
        }
        _os.write(this.bIsStop, 11);
        _os.write((Collection) this.vStopCityInfoList, 12);
        if (this.strBuyTicketUrl != null) {
            _os.write(this.strBuyTicketUrl, 13);
        }
        _os.write(this.fBottomPrice, 14);
        if (this.strIconUrl != null) {
            _os.write(this.strIconUrl, 15);
        }
    }

    static {
        cache_vPolicyInfoList.add(new PolicyInfo());
        cache_vStopCityInfoList.add(new StopCityInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strFlightNo = _is.readString(0, true);
        this.strCompanyCode = _is.readString(1, true);
        this.strCompanyName = _is.readString(2, true);
        this.sOrigin = (EndpointInfo) _is.read((JceStruct) cache_sOrigin, 3, true);
        this.sDestination = (EndpointInfo) _is.read((JceStruct) cache_sDestination, 4, true);
        this.lDepartTimestamp = _is.read(this.lDepartTimestamp, 5, true);
        this.lArriveTimestamp = _is.read(this.lArriveTimestamp, 6, true);
        this.sCraftInfo = (CraftInfo) _is.read((JceStruct) cache_sCraftInfo, 7, true);
        this.vPolicyInfoList = (ArrayList) _is.read((Object) cache_vPolicyInfoList, 8, true);
        this.bIsShared = _is.read(this.bIsShared, 9, true);
        this.strComfort = _is.readString(10, false);
        this.bIsStop = _is.read(this.bIsStop, 11, true);
        this.vStopCityInfoList = (ArrayList) _is.read((Object) cache_vStopCityInfoList, 12, true);
        this.strBuyTicketUrl = _is.readString(13, false);
        this.fBottomPrice = _is.read(this.fBottomPrice, 14, false);
        this.strIconUrl = _is.readString(15, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Flight temp = (Flight) a.parseObject(text, Flight.class);
        this.strFlightNo = temp.strFlightNo;
        this.strCompanyCode = temp.strCompanyCode;
        this.strCompanyName = temp.strCompanyName;
        this.sOrigin = temp.sOrigin;
        this.sDestination = temp.sDestination;
        this.lDepartTimestamp = temp.lDepartTimestamp;
        this.lArriveTimestamp = temp.lArriveTimestamp;
        this.sCraftInfo = temp.sCraftInfo;
        this.vPolicyInfoList = temp.vPolicyInfoList;
        this.bIsShared = temp.bIsShared;
        this.strComfort = temp.strComfort;
        this.bIsStop = temp.bIsStop;
        this.vStopCityInfoList = temp.vStopCityInfoList;
        this.strBuyTicketUrl = temp.strBuyTicketUrl;
        this.fBottomPrice = temp.fBottomPrice;
        this.strIconUrl = temp.strIconUrl;
    }
}
