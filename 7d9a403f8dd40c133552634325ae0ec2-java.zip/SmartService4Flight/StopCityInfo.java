package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class StopCityInfo extends JceStruct {
    public String strArriveTime = "";
    public String strCityName = "";
    public String strDepartTime = "";

    public StopCityInfo() {
    }

    public StopCityInfo(String strCityName2, String strArriveTime2, String strDepartTime2) {
        this.strCityName = strCityName2;
        this.strArriveTime = strArriveTime2;
        this.strDepartTime = strDepartTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strCityName, 0);
        _os.write(this.strArriveTime, 1);
        _os.write(this.strDepartTime, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strCityName = _is.readString(0, true);
        this.strArriveTime = _is.readString(1, true);
        this.strDepartTime = _is.readString(2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        StopCityInfo temp = (StopCityInfo) a.parseObject(text, StopCityInfo.class);
        this.strCityName = temp.strCityName;
        this.strArriveTime = temp.strArriveTime;
        this.strDepartTime = temp.strDepartTime;
    }
}
