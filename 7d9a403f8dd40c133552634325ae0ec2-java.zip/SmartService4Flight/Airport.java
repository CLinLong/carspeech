package SmartService4Flight;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Airport extends JceStruct {
    public float fLat = 0.0f;
    public float fLng = 0.0f;
    public String strAirportCode = "";
    public String strAirportName = "";
    public String strCityCode = "";
    public String strCityName = "";

    public Airport() {
    }

    public Airport(String strAirportCode2, String strAirportName2, String strCityName2, String strCityCode2, float fLat2, float fLng2) {
        this.strAirportCode = strAirportCode2;
        this.strAirportName = strAirportName2;
        this.strCityName = strCityName2;
        this.strCityCode = strCityCode2;
        this.fLat = fLat2;
        this.fLng = fLng2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strAirportCode, 0);
        _os.write(this.strAirportName, 1);
        _os.write(this.strCityName, 2);
        _os.write(this.strCityCode, 3);
        _os.write(this.fLat, 4);
        _os.write(this.fLng, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strAirportCode = _is.readString(0, true);
        this.strAirportName = _is.readString(1, true);
        this.strCityName = _is.readString(2, true);
        this.strCityCode = _is.readString(3, true);
        this.fLat = _is.read(this.fLat, 4, true);
        this.fLng = _is.read(this.fLng, 5, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Airport temp = (Airport) a.parseObject(text, Airport.class);
        this.strAirportCode = temp.strAirportCode;
        this.strAirportName = temp.strAirportName;
        this.strCityName = temp.strCityName;
        this.strCityCode = temp.strCityCode;
        this.fLat = temp.fLat;
        this.fLng = temp.fLng;
    }
}
