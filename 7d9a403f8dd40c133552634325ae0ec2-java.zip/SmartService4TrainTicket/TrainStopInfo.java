package SmartService4TrainTicket;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class TrainStopInfo extends JceStruct {
    public String arriveTime = "";
    public String distance = "";
    public String startTime = "";
    public int stationDiff = 0;
    public String stationId = "";
    public String stationName = "";
    public int stationNo = 0;
    public int stopDuration = 0;
    public String subTrainNum = "";
    public String trainNum = "";

    public TrainStopInfo() {
    }

    public TrainStopInfo(String stationId2, String stationName2, int stationNo2, String startTime2, String arriveTime2, int stopDuration2, String subTrainNum2, String distance2, String trainNum2, int stationDiff2) {
        this.stationId = stationId2;
        this.stationName = stationName2;
        this.stationNo = stationNo2;
        this.startTime = startTime2;
        this.arriveTime = arriveTime2;
        this.stopDuration = stopDuration2;
        this.subTrainNum = subTrainNum2;
        this.distance = distance2;
        this.trainNum = trainNum2;
        this.stationDiff = stationDiff2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.stationId, 0);
        _os.write(this.stationName, 1);
        _os.write(this.stationNo, 2);
        _os.write(this.startTime, 3);
        _os.write(this.arriveTime, 4);
        _os.write(this.stopDuration, 5);
        if (this.subTrainNum != null) {
            _os.write(this.subTrainNum, 6);
        }
        if (this.distance != null) {
            _os.write(this.distance, 7);
        }
        _os.write(this.trainNum, 8);
        _os.write(this.stationDiff, 9);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.stationId = _is.readString(0, true);
        this.stationName = _is.readString(1, true);
        this.stationNo = _is.read(this.stationNo, 2, true);
        this.startTime = _is.readString(3, true);
        this.arriveTime = _is.readString(4, true);
        this.stopDuration = _is.read(this.stopDuration, 5, true);
        this.subTrainNum = _is.readString(6, false);
        this.distance = _is.readString(7, false);
        this.trainNum = _is.readString(8, true);
        this.stationDiff = _is.read(this.stationDiff, 9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        TrainStopInfo temp = (TrainStopInfo) a.parseObject(text, TrainStopInfo.class);
        this.stationId = temp.stationId;
        this.stationName = temp.stationName;
        this.stationNo = temp.stationNo;
        this.startTime = temp.startTime;
        this.arriveTime = temp.arriveTime;
        this.stopDuration = temp.stopDuration;
        this.subTrainNum = temp.subTrainNum;
        this.distance = temp.distance;
        this.trainNum = temp.trainNum;
        this.stationDiff = temp.stationDiff;
    }
}
