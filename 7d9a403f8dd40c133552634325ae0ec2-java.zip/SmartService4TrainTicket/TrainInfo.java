package SmartService4TrainTicket;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class TrainInfo extends JceStruct {
    static ArrayList<Integer> cache_filterType = new ArrayList<>();
    static ArrayList<SeatInfo> cache_realTrainSeats = new ArrayList<>();
    static ArrayList<SeatInfo> cache_seats = new ArrayList<>();
    static int cache_trainType = 0;
    public int additionStationNum = 0;
    public String buyTicketUrl = "";
    public boolean canWebBuy = true;
    public int controlDay = 0;
    public String date = "";
    public int dayDiff = 0;
    public ArrayList<Integer> filterType = null;
    public String fromStation = "";
    public String fromStationType = "";
    public String fromTime = "";
    public String note = "";
    public String realStationName = "";
    public ArrayList<SeatInfo> realTrainSeats = null;
    public String saleDate = "";
    public String saleTime = "";
    public long saleTimestamp = 0;
    public ArrayList<SeatInfo> seats = null;
    public String toStation = "";
    public String toStationType = "";
    public String toTime = "";
    public String trainId = "";
    public String trainNum = "";
    public int trainType = 0;
    public int useTime = 0;

    public TrainInfo() {
    }

    public TrainInfo(String trainId2, String trainNum2, String fromStation2, String toStation2, String fromTime2, String toTime2, String fromStationType2, String toStationType2, int dayDiff2, int useTime2, String saleTime2, int controlDay2, boolean canWebBuy2, String note2, ArrayList<SeatInfo> seats2, ArrayList<Integer> filterType2, String buyTicketUrl2, String date2, int trainType2, int additionStationNum2, String realStationName2, ArrayList<SeatInfo> realTrainSeats2, String saleDate2, long saleTimestamp2) {
        this.trainId = trainId2;
        this.trainNum = trainNum2;
        this.fromStation = fromStation2;
        this.toStation = toStation2;
        this.fromTime = fromTime2;
        this.toTime = toTime2;
        this.fromStationType = fromStationType2;
        this.toStationType = toStationType2;
        this.dayDiff = dayDiff2;
        this.useTime = useTime2;
        this.saleTime = saleTime2;
        this.controlDay = controlDay2;
        this.canWebBuy = canWebBuy2;
        this.note = note2;
        this.seats = seats2;
        this.filterType = filterType2;
        this.buyTicketUrl = buyTicketUrl2;
        this.date = date2;
        this.trainType = trainType2;
        this.additionStationNum = additionStationNum2;
        this.realStationName = realStationName2;
        this.realTrainSeats = realTrainSeats2;
        this.saleDate = saleDate2;
        this.saleTimestamp = saleTimestamp2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.trainId, 0);
        _os.write(this.trainNum, 1);
        _os.write(this.fromStation, 2);
        _os.write(this.toStation, 3);
        _os.write(this.fromTime, 4);
        _os.write(this.toTime, 5);
        _os.write(this.fromStationType, 6);
        _os.write(this.toStationType, 7);
        _os.write(this.dayDiff, 8);
        _os.write(this.useTime, 9);
        _os.write(this.saleTime, 10);
        _os.write(this.controlDay, 11);
        _os.write(this.canWebBuy, 12);
        if (this.note != null) {
            _os.write(this.note, 13);
        }
        _os.write((Collection) this.seats, 14);
        if (this.filterType != null) {
            _os.write((Collection) this.filterType, 15);
        }
        _os.write(this.buyTicketUrl, 16);
        _os.write(this.date, 17);
        _os.write(this.trainType, 18);
        _os.write(this.additionStationNum, 19);
        if (this.realStationName != null) {
            _os.write(this.realStationName, 20);
        }
        if (this.realTrainSeats != null) {
            _os.write((Collection) this.realTrainSeats, 21);
        }
        if (this.saleDate != null) {
            _os.write(this.saleDate, 22);
        }
        _os.write(this.saleTimestamp, 23);
    }

    static {
        cache_seats.add(new SeatInfo());
        cache_filterType.add(0);
        cache_realTrainSeats.add(new SeatInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.trainId = _is.readString(0, true);
        this.trainNum = _is.readString(1, true);
        this.fromStation = _is.readString(2, true);
        this.toStation = _is.readString(3, true);
        this.fromTime = _is.readString(4, true);
        this.toTime = _is.readString(5, true);
        this.fromStationType = _is.readString(6, true);
        this.toStationType = _is.readString(7, true);
        this.dayDiff = _is.read(this.dayDiff, 8, true);
        this.useTime = _is.read(this.useTime, 9, true);
        this.saleTime = _is.readString(10, true);
        this.controlDay = _is.read(this.controlDay, 11, true);
        this.canWebBuy = _is.read(this.canWebBuy, 12, true);
        this.note = _is.readString(13, false);
        this.seats = (ArrayList) _is.read((Object) cache_seats, 14, true);
        this.filterType = (ArrayList) _is.read((Object) cache_filterType, 15, false);
        this.buyTicketUrl = _is.readString(16, true);
        this.date = _is.readString(17, true);
        this.trainType = _is.read(this.trainType, 18, false);
        this.additionStationNum = _is.read(this.additionStationNum, 19, false);
        this.realStationName = _is.readString(20, false);
        this.realTrainSeats = (ArrayList) _is.read((Object) cache_realTrainSeats, 21, false);
        this.saleDate = _is.readString(22, false);
        this.saleTimestamp = _is.read(this.saleTimestamp, 23, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        TrainInfo temp = (TrainInfo) a.parseObject(text, TrainInfo.class);
        this.trainId = temp.trainId;
        this.trainNum = temp.trainNum;
        this.fromStation = temp.fromStation;
        this.toStation = temp.toStation;
        this.fromTime = temp.fromTime;
        this.toTime = temp.toTime;
        this.fromStationType = temp.fromStationType;
        this.toStationType = temp.toStationType;
        this.dayDiff = temp.dayDiff;
        this.useTime = temp.useTime;
        this.saleTime = temp.saleTime;
        this.controlDay = temp.controlDay;
        this.canWebBuy = temp.canWebBuy;
        this.note = temp.note;
        this.seats = temp.seats;
        this.filterType = temp.filterType;
        this.buyTicketUrl = temp.buyTicketUrl;
        this.date = temp.date;
        this.trainType = temp.trainType;
        this.additionStationNum = temp.additionStationNum;
        this.realStationName = temp.realStationName;
        this.realTrainSeats = temp.realTrainSeats;
        this.saleDate = temp.saleDate;
        this.saleTimestamp = temp.saleTimestamp;
    }
}
