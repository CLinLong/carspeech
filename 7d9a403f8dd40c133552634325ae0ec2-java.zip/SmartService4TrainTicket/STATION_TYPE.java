package SmartService4TrainTicket;

import java.io.Serializable;

public final class STATION_TYPE implements Serializable {
    public static final int _E_STATIONTYPE_DESTINATION = 1;
    public static final int _E_STATIONTYPE_ORIGIN = 0;
    public static final int _E_STATIONTYPE_PASSBY = 2;
}
