package SmartService4TrainTicket;

import java.io.Serializable;

public final class SEAT_TYPE implements Serializable {
    public static final int _E_SEATTYPE_EDZ = 5;
    public static final int _E_SEATTYPE_GJRW = 6;
    public static final int _E_SEATTYPE_OTHERS = 9;
    public static final int _E_SEATTYPE_RW = 7;
    public static final int _E_SEATTYPE_SWZ = 2;
    public static final int _E_SEATTYPE_TDZ = 3;
    public static final int _E_SEATTYPE_WZ = 8;
    public static final int _E_SEATTYPE_YDZ = 4;
    public static final int _E_SEATTYPE_YW = 1;
    public static final int _E_SEATTYPE_YZ = 0;
}
