package SmartService4TrainTicket;

import java.io.Serializable;

public final class TRAIN_TYPE implements Serializable {
    public static final int _E_TRAINTYPE_C = 1;
    public static final int _E_TRAINTYPE_D = 2;
    public static final int _E_TRAINTYPE_G = 0;
    public static final int _E_TRAINTYPE_K = 5;
    public static final int _E_TRAINTYPE_OTHERS = 6;
    public static final int _E_TRAINTYPE_T = 4;
    public static final int _E_TRAINTYPE_Z = 3;
}
