package SmartService4TrainTicket;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class StationInfo extends JceStruct {
    public String bureauId = "";
    public String bureauName = "";
    public String cityId = "";
    public String cityName = "";
    public String cityPinyin = "";
    public String cityShortPinyin = "";
    public String grade = "";
    public String provinceId = "";
    public String provinceName = "";
    public String provincePinyin = "";
    public String shortCode = "";
    public String startSaleTime = "";
    public String stationId = "";
    public String stationName = "";
    public String stationPinyin = "";
    public String stationShortName = "";
    public String teleCode = "";
    public String updateTime = "";

    public StationInfo() {
    }

    public StationInfo(String stationId2, String stationName2, String stationShortName2, String stationPinyin2, String cityId2, String cityName2, String cityPinyin2, String cityShortPinyin2, String grade2, String bureauId2, String bureauName2, String provinceId2, String provinceName2, String provincePinyin2, String startSaleTime2, String updateTime2, String teleCode2, String shortCode2) {
        this.stationId = stationId2;
        this.stationName = stationName2;
        this.stationShortName = stationShortName2;
        this.stationPinyin = stationPinyin2;
        this.cityId = cityId2;
        this.cityName = cityName2;
        this.cityPinyin = cityPinyin2;
        this.cityShortPinyin = cityShortPinyin2;
        this.grade = grade2;
        this.bureauId = bureauId2;
        this.bureauName = bureauName2;
        this.provinceId = provinceId2;
        this.provinceName = provinceName2;
        this.provincePinyin = provincePinyin2;
        this.startSaleTime = startSaleTime2;
        this.updateTime = updateTime2;
        this.teleCode = teleCode2;
        this.shortCode = shortCode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.stationId, 0);
        _os.write(this.stationName, 1);
        if (this.stationShortName != null) {
            _os.write(this.stationShortName, 2);
        }
        if (this.stationPinyin != null) {
            _os.write(this.stationPinyin, 3);
        }
        _os.write(this.cityId, 4);
        _os.write(this.cityName, 5);
        if (this.cityPinyin != null) {
            _os.write(this.cityPinyin, 6);
        }
        if (this.cityShortPinyin != null) {
            _os.write(this.cityShortPinyin, 7);
        }
        if (this.grade != null) {
            _os.write(this.grade, 8);
        }
        if (this.bureauId != null) {
            _os.write(this.bureauId, 9);
        }
        if (this.bureauName != null) {
            _os.write(this.bureauName, 10);
        }
        if (this.provinceId != null) {
            _os.write(this.provinceId, 11);
        }
        if (this.provinceName != null) {
            _os.write(this.provinceName, 12);
        }
        if (this.provincePinyin != null) {
            _os.write(this.provincePinyin, 13);
        }
        if (this.startSaleTime != null) {
            _os.write(this.startSaleTime, 14);
        }
        if (this.updateTime != null) {
            _os.write(this.updateTime, 15);
        }
        if (this.teleCode != null) {
            _os.write(this.teleCode, 16);
        }
        if (this.shortCode != null) {
            _os.write(this.shortCode, 17);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.stationId = _is.readString(0, true);
        this.stationName = _is.readString(1, true);
        this.stationShortName = _is.readString(2, false);
        this.stationPinyin = _is.readString(3, false);
        this.cityId = _is.readString(4, true);
        this.cityName = _is.readString(5, true);
        this.cityPinyin = _is.readString(6, false);
        this.cityShortPinyin = _is.readString(7, false);
        this.grade = _is.readString(8, false);
        this.bureauId = _is.readString(9, false);
        this.bureauName = _is.readString(10, false);
        this.provinceId = _is.readString(11, false);
        this.provinceName = _is.readString(12, false);
        this.provincePinyin = _is.readString(13, false);
        this.startSaleTime = _is.readString(14, false);
        this.updateTime = _is.readString(15, false);
        this.teleCode = _is.readString(16, false);
        this.shortCode = _is.readString(17, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        StationInfo temp = (StationInfo) a.parseObject(text, StationInfo.class);
        this.stationId = temp.stationId;
        this.stationName = temp.stationName;
        this.stationShortName = temp.stationShortName;
        this.stationPinyin = temp.stationPinyin;
        this.cityId = temp.cityId;
        this.cityName = temp.cityName;
        this.cityPinyin = temp.cityPinyin;
        this.cityShortPinyin = temp.cityShortPinyin;
        this.grade = temp.grade;
        this.bureauId = temp.bureauId;
        this.bureauName = temp.bureauName;
        this.provinceId = temp.provinceId;
        this.provinceName = temp.provinceName;
        this.provincePinyin = temp.provincePinyin;
        this.startSaleTime = temp.startSaleTime;
        this.updateTime = temp.updateTime;
        this.teleCode = temp.teleCode;
        this.shortCode = temp.shortCode;
    }
}
