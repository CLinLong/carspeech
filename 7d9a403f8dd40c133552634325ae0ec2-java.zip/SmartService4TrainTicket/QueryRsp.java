package SmartService4TrainTicket;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QueryRsp extends JceStruct {
    static QueryParams cache_queryParams = new QueryParams();
    static ArrayList<TrainInfo> cache_trainInfos = new ArrayList<>();
    public String moreUrl = "";
    public QueryParams queryParams = null;
    public ArrayList<TrainInfo> trainInfos = null;

    public QueryRsp() {
    }

    public QueryRsp(ArrayList<TrainInfo> trainInfos2, String moreUrl2, QueryParams queryParams2) {
        this.trainInfos = trainInfos2;
        this.moreUrl = moreUrl2;
        this.queryParams = queryParams2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.trainInfos, 0);
        if (this.moreUrl != null) {
            _os.write(this.moreUrl, 1);
        }
        _os.write((JceStruct) this.queryParams, 2);
    }

    static {
        cache_trainInfos.add(new TrainInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.trainInfos = (ArrayList) _is.read((Object) cache_trainInfos, 0, true);
        this.moreUrl = _is.readString(1, false);
        this.queryParams = (QueryParams) _is.read((JceStruct) cache_queryParams, 2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QueryRsp temp = (QueryRsp) a.parseObject(text, QueryRsp.class);
        this.trainInfos = temp.trainInfos;
        this.moreUrl = temp.moreUrl;
        this.queryParams = temp.queryParams;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
