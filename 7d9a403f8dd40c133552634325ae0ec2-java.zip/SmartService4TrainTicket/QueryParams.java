package SmartService4TrainTicket;

import SmartAssistant.UserBase;
import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QueryParams extends JceStruct {
    static ArrayList<Integer> cache_eSeatTypes = new ArrayList<>();
    static UserBase cache_userBase = new UserBase();
    public ArrayList<Integer> eSeatTypes = null;
    public String fromName = "";
    public String inputTime = "";
    public String lunarTime = "";
    public String period = "";
    public String periodEnd = "";
    public String periodStart = "";
    public String seatType = "";
    public String startDate = "";
    public String time = "";
    public String toName = "";
    public String trainNum = "";
    public String trainType = "";
    public UserBase userBase = null;
    public String userId = "";

    public QueryParams() {
    }

    public QueryParams(String fromName2, String toName2, String trainType2, String trainNum2, String seatType2, String startDate2, String time2, String userId2, UserBase userBase2, String period2, String periodStart2, String periodEnd2, String inputTime2, ArrayList<Integer> eSeatTypes2, String lunarTime2) {
        this.fromName = fromName2;
        this.toName = toName2;
        this.trainType = trainType2;
        this.trainNum = trainNum2;
        this.seatType = seatType2;
        this.startDate = startDate2;
        this.time = time2;
        this.userId = userId2;
        this.userBase = userBase2;
        this.period = period2;
        this.periodStart = periodStart2;
        this.periodEnd = periodEnd2;
        this.inputTime = inputTime2;
        this.eSeatTypes = eSeatTypes2;
        this.lunarTime = lunarTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.fromName != null) {
            _os.write(this.fromName, 0);
        }
        _os.write(this.toName, 1);
        if (this.trainType != null) {
            _os.write(this.trainType, 2);
        }
        if (this.trainNum != null) {
            _os.write(this.trainNum, 3);
        }
        if (this.seatType != null) {
            _os.write(this.seatType, 4);
        }
        _os.write(this.startDate, 5);
        if (this.time != null) {
            _os.write(this.time, 6);
        }
        _os.write(this.userId, 7);
        _os.write((JceStruct) this.userBase, 8);
        if (this.period != null) {
            _os.write(this.period, 9);
        }
        if (this.periodStart != null) {
            _os.write(this.periodStart, 10);
        }
        if (this.periodEnd != null) {
            _os.write(this.periodEnd, 11);
        }
        _os.write(this.inputTime, 12);
        if (this.eSeatTypes != null) {
            _os.write((Collection) this.eSeatTypes, 13);
        }
        if (this.lunarTime != null) {
            _os.write(this.lunarTime, 14);
        }
    }

    static {
        cache_eSeatTypes.add(0);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.fromName = _is.readString(0, false);
        this.toName = _is.readString(1, true);
        this.trainType = _is.readString(2, false);
        this.trainNum = _is.readString(3, false);
        this.seatType = _is.readString(4, false);
        this.startDate = _is.readString(5, true);
        this.time = _is.readString(6, false);
        this.userId = _is.readString(7, true);
        this.userBase = (UserBase) _is.read((JceStruct) cache_userBase, 8, true);
        this.period = _is.readString(9, false);
        this.periodStart = _is.readString(10, false);
        this.periodEnd = _is.readString(11, false);
        this.inputTime = _is.readString(12, true);
        this.eSeatTypes = (ArrayList) _is.read((Object) cache_eSeatTypes, 13, false);
        this.lunarTime = _is.readString(14, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QueryParams temp = (QueryParams) a.parseObject(text, QueryParams.class);
        this.fromName = temp.fromName;
        this.toName = temp.toName;
        this.trainType = temp.trainType;
        this.trainNum = temp.trainNum;
        this.seatType = temp.seatType;
        this.startDate = temp.startDate;
        this.time = temp.time;
        this.userId = temp.userId;
        this.userBase = temp.userBase;
        this.period = temp.period;
        this.periodStart = temp.periodStart;
        this.periodEnd = temp.periodEnd;
        this.inputTime = temp.inputTime;
        this.eSeatTypes = temp.eSeatTypes;
        this.lunarTime = temp.lunarTime;
    }
}
