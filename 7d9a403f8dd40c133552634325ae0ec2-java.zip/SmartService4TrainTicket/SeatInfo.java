package SmartService4TrainTicket;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SeatInfo extends JceStruct {
    static int cache_seatType = 0;
    public boolean bookable = false;
    public float price = 0.0f;
    public int remainNum = 0;
    public String seatName = "";
    public int seatType = 0;

    public SeatInfo() {
    }

    public SeatInfo(String seatName2, int remainNum2, boolean bookable2, float price2, int seatType2) {
        this.seatName = seatName2;
        this.remainNum = remainNum2;
        this.bookable = bookable2;
        this.price = price2;
        this.seatType = seatType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.seatName, 0);
        _os.write(this.remainNum, 1);
        _os.write(this.bookable, 2);
        _os.write(this.price, 3);
        _os.write(this.seatType, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.seatName = _is.readString(0, true);
        this.remainNum = _is.read(this.remainNum, 1, true);
        this.bookable = _is.read(this.bookable, 2, true);
        this.price = _is.read(this.price, 3, false);
        this.seatType = _is.read(this.seatType, 4, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SeatInfo temp = (SeatInfo) a.parseObject(text, SeatInfo.class);
        this.seatName = temp.seatName;
        this.remainNum = temp.remainNum;
        this.bookable = temp.bookable;
        this.price = temp.price;
        this.seatType = temp.seatType;
    }
}
