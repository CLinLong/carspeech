package SmartService4TrainTicket;

import java.io.Serializable;

public final class TRAIN_SPECIAL implements Serializable {
    public static final int _E_TRAINSPECIAL_BESTREACH = 3;
    public static final int _E_TRAINSPECIAL_BESTSTART = 2;
    public static final int _E_TRAINSPECIAL_CHEAPEST = 0;
    public static final int _E_TRAINSPECIAL_FASTEST = 1;
    public static final int _E_TRAINSPECIAL_OTHERS = 4;
}
