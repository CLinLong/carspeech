package SmartService4Express;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ExpressCompany extends JceStruct {
    public String companyCode = "";
    public String companyName = "";
    public String iconUrl = "";
    public String kfPhone = "";
    public String shortName = "";
    public String website = "";

    public ExpressCompany() {
    }

    public ExpressCompany(String companyCode2, String companyName2, String kfPhone2, String iconUrl2, String website2, String shortName2) {
        this.companyCode = companyCode2;
        this.companyName = companyName2;
        this.kfPhone = kfPhone2;
        this.iconUrl = iconUrl2;
        this.website = website2;
        this.shortName = shortName2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.companyCode, 1);
        _os.write(this.companyName, 2);
        if (this.kfPhone != null) {
            _os.write(this.kfPhone, 3);
        }
        if (this.iconUrl != null) {
            _os.write(this.iconUrl, 4);
        }
        if (this.website != null) {
            _os.write(this.website, 5);
        }
        if (this.shortName != null) {
            _os.write(this.shortName, 6);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.companyCode = _is.readString(1, true);
        this.companyName = _is.readString(2, true);
        this.kfPhone = _is.readString(3, false);
        this.iconUrl = _is.readString(4, false);
        this.website = _is.readString(5, false);
        this.shortName = _is.readString(6, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        ExpressCompany temp = (ExpressCompany) a.parseObject(text, ExpressCompany.class);
        this.companyCode = temp.companyCode;
        this.companyName = temp.companyName;
        this.kfPhone = temp.kfPhone;
        this.iconUrl = temp.iconUrl;
        this.website = temp.website;
        this.shortName = temp.shortName;
    }
}
