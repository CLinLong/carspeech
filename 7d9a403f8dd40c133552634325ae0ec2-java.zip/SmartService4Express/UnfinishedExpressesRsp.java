package SmartService4Express;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class UnfinishedExpressesRsp extends JceStruct {
    static ArrayList<UserExpressInfo> cache_expresses = new ArrayList<>();
    public int errorCode = 0;
    public String errorMsg = "";
    public ArrayList<UserExpressInfo> expresses = null;
    public String moreUrl = "";
    public String scanUrl = "";

    public UnfinishedExpressesRsp() {
    }

    public UnfinishedExpressesRsp(String moreUrl2, ArrayList<UserExpressInfo> expresses2, int errorCode2, String errorMsg2, String scanUrl2) {
        this.moreUrl = moreUrl2;
        this.expresses = expresses2;
        this.errorCode = errorCode2;
        this.errorMsg = errorMsg2;
        this.scanUrl = scanUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.moreUrl != null) {
            _os.write(this.moreUrl, 0);
        }
        _os.write((Collection) this.expresses, 1);
        _os.write(this.errorCode, 2);
        if (this.errorMsg != null) {
            _os.write(this.errorMsg, 3);
        }
        if (this.scanUrl != null) {
            _os.write(this.scanUrl, 4);
        }
    }

    static {
        cache_expresses.add(new UserExpressInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.moreUrl = _is.readString(0, false);
        this.expresses = (ArrayList) _is.read((Object) cache_expresses, 1, true);
        this.errorCode = _is.read(this.errorCode, 2, false);
        this.errorMsg = _is.readString(3, false);
        this.scanUrl = _is.readString(4, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        UnfinishedExpressesRsp temp = (UnfinishedExpressesRsp) a.parseObject(text, UnfinishedExpressesRsp.class);
        this.moreUrl = temp.moreUrl;
        this.expresses = temp.expresses;
        this.errorCode = temp.errorCode;
        this.errorMsg = temp.errorMsg;
        this.scanUrl = temp.scanUrl;
    }
}
