package SmartService4Express;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class UserSettings extends JceStruct {
    public boolean isFirstNotify = true;
    public boolean isFirstQuery = true;
    public boolean isFirstScan = true;
    public boolean isFirstUncheckQuery = true;
    public boolean needNotified = true;
    public String userId = "";

    public UserSettings() {
    }

    public UserSettings(String userId2, boolean needNotified2, boolean isFirstScan2, boolean isFirstNotify2, boolean isFirstQuery2, boolean isFirstUncheckQuery2) {
        this.userId = userId2;
        this.needNotified = needNotified2;
        this.isFirstScan = isFirstScan2;
        this.isFirstNotify = isFirstNotify2;
        this.isFirstQuery = isFirstQuery2;
        this.isFirstUncheckQuery = isFirstUncheckQuery2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.userId, 0);
        _os.write(this.needNotified, 1);
        _os.write(this.isFirstScan, 2);
        _os.write(this.isFirstNotify, 3);
        _os.write(this.isFirstQuery, 4);
        _os.write(this.isFirstUncheckQuery, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.userId = _is.readString(0, true);
        this.needNotified = _is.read(this.needNotified, 1, true);
        this.isFirstScan = _is.read(this.isFirstScan, 2, false);
        this.isFirstNotify = _is.read(this.isFirstNotify, 3, true);
        this.isFirstQuery = _is.read(this.isFirstQuery, 4, false);
        this.isFirstUncheckQuery = _is.read(this.isFirstUncheckQuery, 5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        UserSettings temp = (UserSettings) a.parseObject(text, UserSettings.class);
        this.userId = temp.userId;
        this.needNotified = temp.needNotified;
        this.isFirstScan = temp.isFirstScan;
        this.isFirstNotify = temp.isFirstNotify;
        this.isFirstQuery = temp.isFirstQuery;
        this.isFirstUncheckQuery = temp.isFirstUncheckQuery;
    }
}
