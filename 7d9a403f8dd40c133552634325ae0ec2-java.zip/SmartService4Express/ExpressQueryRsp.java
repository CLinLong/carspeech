package SmartService4Express;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ExpressQueryRsp extends JceStruct {
    static UserExpressInfo cache_express = new UserExpressInfo();
    public int errorCode = 0;
    public String errorMsg = "";
    public UserExpressInfo express = null;

    public ExpressQueryRsp() {
    }

    public ExpressQueryRsp(UserExpressInfo express2, int errorCode2, String errorMsg2) {
        this.express = express2;
        this.errorCode = errorCode2;
        this.errorMsg = errorMsg2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((JceStruct) this.express, 1);
        _os.write(this.errorCode, 2);
        if (this.errorMsg != null) {
            _os.write(this.errorMsg, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.express = (UserExpressInfo) _is.read((JceStruct) cache_express, 1, true);
        this.errorCode = _is.read(this.errorCode, 2, false);
        this.errorMsg = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        ExpressQueryRsp temp = (ExpressQueryRsp) a.parseObject(text, ExpressQueryRsp.class);
        this.express = temp.express;
        this.errorCode = temp.errorCode;
        this.errorMsg = temp.errorMsg;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
