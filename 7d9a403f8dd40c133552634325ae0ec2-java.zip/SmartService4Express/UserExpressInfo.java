package SmartService4Express;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class UserExpressInfo extends JceStruct {
    static ExpressCompany cache_company = new ExpressCompany();
    static ArrayList<ExpressRoute> cache_routes = new ArrayList<>();
    public ExpressCompany company = null;
    public String departure = "";
    public String destination = "";
    public String detailUrl = "";
    public String expressNum = "";
    public int lastState = 0;
    public ArrayList<ExpressRoute> routes = null;
    public String stateName = "";
    public String userId = "";

    public UserExpressInfo() {
    }

    public UserExpressInfo(String userId2, String expressNum2, ExpressCompany company2, ArrayList<ExpressRoute> routes2, int lastState2, String departure2, String destination2, String detailUrl2, String stateName2) {
        this.userId = userId2;
        this.expressNum = expressNum2;
        this.company = company2;
        this.routes = routes2;
        this.lastState = lastState2;
        this.departure = departure2;
        this.destination = destination2;
        this.detailUrl = detailUrl2;
        this.stateName = stateName2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.userId, 1);
        _os.write(this.expressNum, 2);
        _os.write((JceStruct) this.company, 3);
        _os.write((Collection) this.routes, 4);
        _os.write(this.lastState, 5);
        if (this.departure != null) {
            _os.write(this.departure, 6);
        }
        if (this.destination != null) {
            _os.write(this.destination, 7);
        }
        if (this.detailUrl != null) {
            _os.write(this.detailUrl, 8);
        }
        if (this.stateName != null) {
            _os.write(this.stateName, 9);
        }
    }

    static {
        cache_routes.add(new ExpressRoute());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.userId = _is.readString(1, true);
        this.expressNum = _is.readString(2, true);
        this.company = (ExpressCompany) _is.read((JceStruct) cache_company, 3, true);
        this.routes = (ArrayList) _is.read((Object) cache_routes, 4, true);
        this.lastState = _is.read(this.lastState, 5, true);
        this.departure = _is.readString(6, false);
        this.destination = _is.readString(7, false);
        this.detailUrl = _is.readString(8, false);
        this.stateName = _is.readString(9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        UserExpressInfo temp = (UserExpressInfo) a.parseObject(text, UserExpressInfo.class);
        this.userId = temp.userId;
        this.expressNum = temp.expressNum;
        this.company = temp.company;
        this.routes = temp.routes;
        this.lastState = temp.lastState;
        this.departure = temp.departure;
        this.destination = temp.destination;
        this.detailUrl = temp.detailUrl;
        this.stateName = temp.stateName;
    }
}
