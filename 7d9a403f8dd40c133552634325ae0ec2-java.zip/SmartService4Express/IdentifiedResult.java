package SmartService4Express;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class IdentifiedResult extends JceStruct {
    static ArrayList<ExpressCompany> cache_possibleCompanies = new ArrayList<>();
    public String expressNum = "";
    public ArrayList<ExpressCompany> possibleCompanies = null;

    public IdentifiedResult() {
    }

    public IdentifiedResult(String expressNum2, ArrayList<ExpressCompany> possibleCompanies2) {
        this.expressNum = expressNum2;
        this.possibleCompanies = possibleCompanies2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.expressNum, 1);
        _os.write((Collection) this.possibleCompanies, 2);
    }

    static {
        cache_possibleCompanies.add(new ExpressCompany());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.expressNum = _is.readString(1, true);
        this.possibleCompanies = (ArrayList) _is.read((Object) cache_possibleCompanies, 2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        IdentifiedResult temp = (IdentifiedResult) a.parseObject(text, IdentifiedResult.class);
        this.expressNum = temp.expressNum;
        this.possibleCompanies = temp.possibleCompanies;
    }
}
