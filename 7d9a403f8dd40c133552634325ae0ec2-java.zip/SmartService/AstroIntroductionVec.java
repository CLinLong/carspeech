package SmartService;

import TIRI.AstroIntroduction;
import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AstroIntroductionVec extends JceStruct {
    static ArrayList<AstroIntroduction> cache_vcAstroIntroduction = new ArrayList<>();
    public ArrayList<AstroIntroduction> vcAstroIntroduction = null;

    public AstroIntroductionVec() {
    }

    public AstroIntroductionVec(ArrayList<AstroIntroduction> vcAstroIntroduction2) {
        this.vcAstroIntroduction = vcAstroIntroduction2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vcAstroIntroduction != null) {
            _os.write((Collection) this.vcAstroIntroduction, 0);
        }
    }

    static {
        cache_vcAstroIntroduction.add(new AstroIntroduction());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vcAstroIntroduction = (ArrayList) _is.read((Object) cache_vcAstroIntroduction, 0, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        this.vcAstroIntroduction = ((AstroIntroductionVec) a.parseObject(text, AstroIntroductionVec.class)).vcAstroIntroduction;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
