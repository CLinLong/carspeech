package SmartService;

import java.io.Serializable;

public final class QB_VIDEO_TYPE implements Serializable {
    public static final int _E_QBVIDEO_TYPE_CARTOON = 4;
    public static final int _E_QBVIDEO_TYPE_FILM = 1;
    public static final int _E_QBVIDEO_TYPE_SHOW = 3;
    public static final int _E_QBVIDEO_TYPE_TVSERIES = 2;
    public static final int _E_QBVIDEO_TYPE_UNKNOWN = 0;
}
