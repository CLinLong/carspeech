package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AIInputContent extends JceStruct {
    static int cache_iReqType = 0;
    static ArrayList<AISDKContent> cache_vecData = new ArrayList<>();
    public int iIndex = 0;
    public int iOffset = 0;
    public int iReqType = 0;
    public String strSessionId = "";
    public ArrayList<AISDKContent> vecData = null;

    public AIInputContent() {
    }

    public AIInputContent(ArrayList<AISDKContent> vecData2, String strSessionId2, int iReqType2, int iOffset2, int iIndex2) {
        this.vecData = vecData2;
        this.strSessionId = strSessionId2;
        this.iReqType = iReqType2;
        this.iOffset = iOffset2;
        this.iIndex = iIndex2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vecData != null) {
            _os.write((Collection) this.vecData, 0);
        }
        if (this.strSessionId != null) {
            _os.write(this.strSessionId, 1);
        }
        _os.write(this.iReqType, 2);
        _os.write(this.iOffset, 3);
        _os.write(this.iIndex, 4);
    }

    static {
        cache_vecData.add(new AISDKContent());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecData = (ArrayList) _is.read((Object) cache_vecData, 0, false);
        this.strSessionId = _is.readString(1, false);
        this.iReqType = _is.read(this.iReqType, 2, false);
        this.iOffset = _is.read(this.iOffset, 3, false);
        this.iIndex = _is.read(this.iIndex, 4, false);
    }
}
