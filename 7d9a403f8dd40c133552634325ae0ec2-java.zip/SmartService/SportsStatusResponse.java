package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SportsStatusResponse extends JceStruct {
    static LinkObj cache_allMatchObj = new LinkObj();
    static SportsScore cache_sportsScore = new SportsScore();
    static ArrayList<SportsDataObj> cache_sportsdataObjs = new ArrayList<>();
    public LinkObj allMatchObj = null;
    public String noSupport = "";
    public String replyWords = "";
    public String sGuid = "";
    public String speakerReplyWords = "";
    public SportsScore sportsScore = null;
    public ArrayList<SportsDataObj> sportsdataObjs = null;

    public SportsStatusResponse() {
    }

    public SportsStatusResponse(String sGuid2, ArrayList<SportsDataObj> sportsdataObjs2, SportsScore sportsScore2, String noSupport2, String replyWords2, LinkObj allMatchObj2, String speakerReplyWords2) {
        this.sGuid = sGuid2;
        this.sportsdataObjs = sportsdataObjs2;
        this.sportsScore = sportsScore2;
        this.noSupport = noSupport2;
        this.replyWords = replyWords2;
        this.allMatchObj = allMatchObj2;
        this.speakerReplyWords = speakerReplyWords2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        if (this.sportsdataObjs != null) {
            _os.write((Collection) this.sportsdataObjs, 1);
        }
        if (this.sportsScore != null) {
            _os.write((JceStruct) this.sportsScore, 2);
        }
        if (this.noSupport != null) {
            _os.write(this.noSupport, 3);
        }
        if (this.replyWords != null) {
            _os.write(this.replyWords, 4);
        }
        if (this.allMatchObj != null) {
            _os.write((JceStruct) this.allMatchObj, 5);
        }
        if (this.speakerReplyWords != null) {
            _os.write(this.speakerReplyWords, 6);
        }
    }

    static {
        cache_sportsdataObjs.add(new SportsDataObj());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.sportsdataObjs = (ArrayList) _is.read((Object) cache_sportsdataObjs, 1, false);
        this.sportsScore = (SportsScore) _is.read((JceStruct) cache_sportsScore, 2, false);
        this.noSupport = _is.readString(3, false);
        this.replyWords = _is.readString(4, false);
        this.allMatchObj = (LinkObj) _is.read((JceStruct) cache_allMatchObj, 5, false);
        this.speakerReplyWords = _is.readString(6, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SportsStatusResponse temp = (SportsStatusResponse) a.parseObject(text, SportsStatusResponse.class);
        this.sGuid = temp.sGuid;
        this.sportsdataObjs = temp.sportsdataObjs;
        this.sportsScore = temp.sportsScore;
        this.noSupport = temp.noSupport;
        this.replyWords = temp.replyWords;
        this.allMatchObj = temp.allMatchObj;
        this.speakerReplyWords = temp.speakerReplyWords;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
