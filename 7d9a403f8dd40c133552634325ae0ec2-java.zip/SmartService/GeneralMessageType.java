package SmartService;

import java.io.Serializable;

public final class GeneralMessageType implements Serializable {
    public static final int _E_APP_ABILITY_BLACK_LIST = 3;
    public static final int _E_DINGDANG_ID = 10;
    public static final int _E_FM_GET_DATA_SERVICE = 5;
    public static final int _E_GUID_SERVICE = 9;
    public static final int _E_IDENTIFYING_ID = 10;
    public static final int _E_MEDIA_PLAYSTATE = 1;
    public static final int _E_NEWS_GET_DATA_SERVICE = 6;
    public static final int _E_PHONE_NUM = 11;
    public static final int _E_RESOURCE_URL_SERVICE = 9;
    public static final int _E_THIRD_PARTY_APP_ACCESS_SERVICE = 2;
    public static final int _E_TUTORIAL = 0;
    public static final int _E_USER_LOCATION_SERVICE = 8;
    public static final int _E_VIDEO_CALL = 4;
    public static final int _E_WEATHER_SEMANTIC_SERVICE = 7;
}
