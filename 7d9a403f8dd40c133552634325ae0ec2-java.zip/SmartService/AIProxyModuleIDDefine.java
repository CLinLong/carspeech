package SmartService;

import java.io.Serializable;

public final class AIProxyModuleIDDefine implements Serializable {
    public static final int _E_AIPROXYMODULEIDDEFINE_AIPROXY = 1;
    public static final int _E_AIPROXYMODULEIDDEFINE_ASR = 0;
    public static final int _E_AIPROXYMODULEIDDEFINE_SEMANTIC = 2;
    public static final int _E_AIPROXYMODULEIDDEFINE_SKILL = 3;
    public static final int _E_AIPROXYMODULEIDDEFINE_TTS = 4;
}
