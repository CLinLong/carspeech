package SmartService;

import java.io.Serializable;

public final class AISpeechFileFormat implements Serializable {
    public static final int _E_AISPEECHFILE_AMR = 2;
    public static final int _E_AISPEECHFILE_MP3 = 0;
    public static final int _E_AISPEECHFILE_WAV = 1;
}
