package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AppDataItem extends JceStruct {
    public String alias = "";
    public String apkSize = "";
    public String cateDesc = "";
    public String cdnUrl = "";
    public String detailUrl = "";
    public String hot = "";
    public String iconUrl = "";
    public String name = "";
    public String player = "";
    public String rawId = "";
    public String tags = "";
    public int type = 0;
    public String version = "";

    public AppDataItem() {
    }

    public AppDataItem(String name2, String alias2, String apkSize2, String cateDesc2, String cdnUrl2, String detailUrl2, String iconUrl2, String player2, String rawId2, String tags2, String version2, String hot2, int type2) {
        this.name = name2;
        this.alias = alias2;
        this.apkSize = apkSize2;
        this.cateDesc = cateDesc2;
        this.cdnUrl = cdnUrl2;
        this.detailUrl = detailUrl2;
        this.iconUrl = iconUrl2;
        this.player = player2;
        this.rawId = rawId2;
        this.tags = tags2;
        this.version = version2;
        this.hot = hot2;
        this.type = type2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.name, 0);
        if (this.alias != null) {
            _os.write(this.alias, 1);
        }
        if (this.apkSize != null) {
            _os.write(this.apkSize, 2);
        }
        if (this.cateDesc != null) {
            _os.write(this.cateDesc, 3);
        }
        if (this.cdnUrl != null) {
            _os.write(this.cdnUrl, 4);
        }
        if (this.detailUrl != null) {
            _os.write(this.detailUrl, 5);
        }
        if (this.iconUrl != null) {
            _os.write(this.iconUrl, 6);
        }
        if (this.player != null) {
            _os.write(this.player, 7);
        }
        if (this.rawId != null) {
            _os.write(this.rawId, 8);
        }
        if (this.tags != null) {
            _os.write(this.tags, 9);
        }
        if (this.version != null) {
            _os.write(this.version, 10);
        }
        if (this.hot != null) {
            _os.write(this.hot, 11);
        }
        _os.write(this.type, 12);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.name = _is.readString(0, true);
        this.alias = _is.readString(1, false);
        this.apkSize = _is.readString(2, false);
        this.cateDesc = _is.readString(3, false);
        this.cdnUrl = _is.readString(4, false);
        this.detailUrl = _is.readString(5, false);
        this.iconUrl = _is.readString(6, false);
        this.player = _is.readString(7, false);
        this.rawId = _is.readString(8, false);
        this.tags = _is.readString(9, false);
        this.version = _is.readString(10, false);
        this.hot = _is.readString(11, false);
        this.type = _is.read(this.type, 12, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        AppDataItem temp = (AppDataItem) a.parseObject(text, AppDataItem.class);
        this.name = temp.name;
        this.alias = temp.alias;
        this.apkSize = temp.apkSize;
        this.cateDesc = temp.cateDesc;
        this.cdnUrl = temp.cdnUrl;
        this.detailUrl = temp.detailUrl;
        this.iconUrl = temp.iconUrl;
        this.player = temp.player;
        this.rawId = temp.rawId;
        this.tags = temp.tags;
        this.version = temp.version;
        this.hot = temp.hot;
        this.type = temp.type;
    }
}
