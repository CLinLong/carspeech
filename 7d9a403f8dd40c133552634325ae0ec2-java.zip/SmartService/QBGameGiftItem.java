package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class QBGameGiftItem extends JceStruct {
    public int iRealId = -1;
    public int iUnusedCount = -1;
    public int iUsedCount = -1;
    public long lGivenTime = 0;
    public String strDetailUrl = "";
    public String strGiftBagId = "";
    public String strIconUrl = "";
    public String strPlatform = "";
    public String strSummary = "";
    public String strTitle = "";

    public QBGameGiftItem() {
    }

    public QBGameGiftItem(String strGiftBagId2, int iRealId2, String strSummary2, String strIconUrl2, String strTitle2, long lGivenTime2, int iUsedCount2, int iUnusedCount2, String strPlatform2, String strDetailUrl2) {
        this.strGiftBagId = strGiftBagId2;
        this.iRealId = iRealId2;
        this.strSummary = strSummary2;
        this.strIconUrl = strIconUrl2;
        this.strTitle = strTitle2;
        this.lGivenTime = lGivenTime2;
        this.iUsedCount = iUsedCount2;
        this.iUnusedCount = iUnusedCount2;
        this.strPlatform = strPlatform2;
        this.strDetailUrl = strDetailUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strGiftBagId, 0);
        _os.write(this.iRealId, 1);
        if (this.strSummary != null) {
            _os.write(this.strSummary, 2);
        }
        if (this.strIconUrl != null) {
            _os.write(this.strIconUrl, 3);
        }
        if (this.strTitle != null) {
            _os.write(this.strTitle, 4);
        }
        _os.write(this.lGivenTime, 5);
        _os.write(this.iUsedCount, 6);
        _os.write(this.iUnusedCount, 7);
        if (this.strPlatform != null) {
            _os.write(this.strPlatform, 8);
        }
        if (this.strDetailUrl != null) {
            _os.write(this.strDetailUrl, 9);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strGiftBagId = _is.readString(0, true);
        this.iRealId = _is.read(this.iRealId, 1, true);
        this.strSummary = _is.readString(2, false);
        this.strIconUrl = _is.readString(3, false);
        this.strTitle = _is.readString(4, false);
        this.lGivenTime = _is.read(this.lGivenTime, 5, false);
        this.iUsedCount = _is.read(this.iUsedCount, 6, false);
        this.iUnusedCount = _is.read(this.iUnusedCount, 7, false);
        this.strPlatform = _is.readString(8, false);
        this.strDetailUrl = _is.readString(9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QBGameGiftItem temp = (QBGameGiftItem) a.parseObject(text, QBGameGiftItem.class);
        this.strGiftBagId = temp.strGiftBagId;
        this.iRealId = temp.iRealId;
        this.strSummary = temp.strSummary;
        this.strIconUrl = temp.strIconUrl;
        this.strTitle = temp.strTitle;
        this.lGivenTime = temp.lGivenTime;
        this.iUsedCount = temp.iUsedCount;
        this.iUnusedCount = temp.iUnusedCount;
        this.strPlatform = temp.strPlatform;
        this.strDetailUrl = temp.strDetailUrl;
    }
}
