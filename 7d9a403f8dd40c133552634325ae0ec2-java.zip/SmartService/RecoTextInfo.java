package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class RecoTextInfo extends JceStruct {
    public double dAcousticWeight = 0.0d;
    public double dGraphWeight = 0.0d;
    public String sText = "";

    public RecoTextInfo() {
    }

    public RecoTextInfo(String sText2, double dAcousticWeight2, double dGraphWeight2) {
        this.sText = sText2;
        this.dAcousticWeight = dAcousticWeight2;
        this.dGraphWeight = dGraphWeight2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sText != null) {
            _os.write(this.sText, 0);
        }
        _os.write(this.dAcousticWeight, 1);
        _os.write(this.dGraphWeight, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sText = _is.readString(0, false);
        this.dAcousticWeight = _is.read(this.dAcousticWeight, 1, false);
        this.dGraphWeight = _is.read(this.dGraphWeight, 2, false);
    }
}
