package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SurroundMoreParams extends JceStruct {
    public boolean isNext = false;
    public String userId = "";

    public SurroundMoreParams() {
    }

    public SurroundMoreParams(boolean isNext2, String userId2) {
        this.isNext = isNext2;
        this.userId = userId2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.isNext, 0);
        _os.write(this.userId, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.isNext = _is.read(this.isNext, 0, true);
        this.userId = _is.readString(1, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SurroundMoreParams temp = (SurroundMoreParams) a.parseObject(text, SurroundMoreParams.class);
        this.isNext = temp.isNext;
        this.userId = temp.userId;
    }
}
