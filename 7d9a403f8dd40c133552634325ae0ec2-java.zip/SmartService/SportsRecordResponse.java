package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SportsRecordResponse extends JceStruct {
    static LinkObj cache_detailLink = new LinkObj();
    static ArrayList<SportRecord> cache_sportsRecords = new ArrayList<>();
    public LinkObj detailLink = null;
    public String noSupport = "";
    public String replyWords = "";
    public String sGuid = "";
    public String speakerReplyWords = "";
    public ArrayList<SportRecord> sportsRecords = null;

    public SportsRecordResponse() {
    }

    public SportsRecordResponse(String sGuid2, ArrayList<SportRecord> sportsRecords2, String noSupport2, String replyWords2, LinkObj detailLink2, String speakerReplyWords2) {
        this.sGuid = sGuid2;
        this.sportsRecords = sportsRecords2;
        this.noSupport = noSupport2;
        this.replyWords = replyWords2;
        this.detailLink = detailLink2;
        this.speakerReplyWords = speakerReplyWords2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        _os.write((Collection) this.sportsRecords, 1);
        if (this.noSupport != null) {
            _os.write(this.noSupport, 2);
        }
        if (this.replyWords != null) {
            _os.write(this.replyWords, 3);
        }
        if (this.detailLink != null) {
            _os.write((JceStruct) this.detailLink, 4);
        }
        if (this.speakerReplyWords != null) {
            _os.write(this.speakerReplyWords, 5);
        }
    }

    static {
        cache_sportsRecords.add(new SportRecord());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.sportsRecords = (ArrayList) _is.read((Object) cache_sportsRecords, 1, true);
        this.noSupport = _is.readString(2, false);
        this.replyWords = _is.readString(3, false);
        this.detailLink = (LinkObj) _is.read((JceStruct) cache_detailLink, 4, false);
        this.speakerReplyWords = _is.readString(5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SportsRecordResponse temp = (SportsRecordResponse) a.parseObject(text, SportsRecordResponse.class);
        this.sGuid = temp.sGuid;
        this.sportsRecords = temp.sportsRecords;
        this.noSupport = temp.noSupport;
        this.replyWords = temp.replyWords;
        this.detailLink = temp.detailLink;
        this.speakerReplyWords = temp.speakerReplyWords;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
