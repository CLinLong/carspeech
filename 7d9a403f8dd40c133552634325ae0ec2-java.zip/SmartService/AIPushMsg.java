package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIPushMsg extends JceStruct {
    public String strMessage = "";
    public String strMsgId = "";

    public AIPushMsg() {
    }

    public AIPushMsg(String strMsgId2, String strMessage2) {
        this.strMsgId = strMsgId2;
        this.strMessage = strMessage2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strMsgId != null) {
            _os.write(this.strMsgId, 0);
        }
        if (this.strMessage != null) {
            _os.write(this.strMessage, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strMsgId = _is.readString(0, false);
        this.strMessage = _is.readString(1, false);
    }
}
