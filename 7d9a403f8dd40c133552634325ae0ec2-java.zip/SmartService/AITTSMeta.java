package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AITTSMeta extends JceStruct {
    public int iEngineType = 0;
    public int iLanguageType = 0;
    public int iSingleRequest = 1;
    public int iSpeechFormat = 1;
    public int iSpeechPitch = 50;
    public int iSpeechSpeed = 50;
    public int iSpeechType = 0;
    public int iSpeechVolume = 50;
    public String strBusineseName = "";

    public AITTSMeta() {
    }

    public AITTSMeta(int iEngineType2, int iSpeechFormat2, int iSpeechType2, String strBusineseName2, int iSpeechVolume2, int iSpeechSpeed2, int iSpeechPitch2, int iSingleRequest2, int iLanguageType2) {
        this.iEngineType = iEngineType2;
        this.iSpeechFormat = iSpeechFormat2;
        this.iSpeechType = iSpeechType2;
        this.strBusineseName = strBusineseName2;
        this.iSpeechVolume = iSpeechVolume2;
        this.iSpeechSpeed = iSpeechSpeed2;
        this.iSpeechPitch = iSpeechPitch2;
        this.iSingleRequest = iSingleRequest2;
        this.iLanguageType = iLanguageType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iEngineType, 1);
        _os.write(this.iSpeechFormat, 2);
        _os.write(this.iSpeechType, 3);
        if (this.strBusineseName != null) {
            _os.write(this.strBusineseName, 4);
        }
        _os.write(this.iSpeechVolume, 6);
        _os.write(this.iSpeechSpeed, 7);
        _os.write(this.iSpeechPitch, 8);
        _os.write(this.iSingleRequest, 10);
        _os.write(this.iLanguageType, 11);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iEngineType = _is.read(this.iEngineType, 1, false);
        this.iSpeechFormat = _is.read(this.iSpeechFormat, 2, false);
        this.iSpeechType = _is.read(this.iSpeechType, 3, false);
        this.strBusineseName = _is.readString(4, false);
        this.iSpeechVolume = _is.read(this.iSpeechVolume, 6, false);
        this.iSpeechSpeed = _is.read(this.iSpeechSpeed, 7, false);
        this.iSpeechPitch = _is.read(this.iSpeechPitch, 8, false);
        this.iSingleRequest = _is.read(this.iSingleRequest, 10, false);
        this.iLanguageType = _is.read(this.iLanguageType, 11, false);
    }
}
