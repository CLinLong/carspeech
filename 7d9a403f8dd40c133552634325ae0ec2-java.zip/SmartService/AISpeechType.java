package SmartService;

import java.io.Serializable;

public final class AISpeechType implements Serializable {
    public static final int _E_AISPEECHType_CHENANQI = 3;
    public static final int _E_AISPEECHType_DAJI = 6;
    public static final int _E_AISPEECHType_Default = 0;
    public static final int _E_AISPEECHType_LIBAI = 7;
    public static final int _E_AISPEECHType_MARTIN = 8;
    public static final int _E_AISPEECHType_NAZHA = 9;
    public static final int _E_AISPEECHType_YEWAN = 5;
    public static final int _E_AISPEECHType_YEZI = 4;
    public static final int _E_AISPEECHType_ZHOULONGFEI = 2;
}
