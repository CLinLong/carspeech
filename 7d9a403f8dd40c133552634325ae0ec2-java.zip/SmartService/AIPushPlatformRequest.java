package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIPushPlatformRequest extends JceStruct {
    static int cache_ePlatType = 0;
    static AIPushMsgData cache_sMsgData = new AIPushMsgData();
    public int ePlatType = 0;
    public AIPushMsgData sMsgData = null;

    public AIPushPlatformRequest() {
    }

    public AIPushPlatformRequest(int ePlatType2, AIPushMsgData sMsgData2) {
        this.ePlatType = ePlatType2;
        this.sMsgData = sMsgData2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.ePlatType, 0);
        _os.write((JceStruct) this.sMsgData, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.ePlatType = _is.read(this.ePlatType, 0, true);
        this.sMsgData = (AIPushMsgData) _is.read((JceStruct) cache_sMsgData, 1, true);
    }
}
