package SmartService;

import java.io.Serializable;

public final class NEWS_DIMEN_FIELD implements Serializable {
    public static final int _KEYWORD = 2;
    public static final int _TIME = 3;
    public static final int _TYPE = 1;
}
