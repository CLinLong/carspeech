package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AITTSResponse extends JceStruct {
    static ArrayList<CostTimeInfo> cache_vecCostTime = new ArrayList<>();
    static byte[] cache_vecSpeechData = new byte[1];
    public int iEngineType = 0;
    public int iRet = 0;
    public String strErrorMsg = "";
    public String strSessionId = "";
    public ArrayList<CostTimeInfo> vecCostTime = null;
    public byte[] vecSpeechData = null;

    public AITTSResponse() {
    }

    public AITTSResponse(byte[] vecSpeechData2, int iRet2, String strErrorMsg2, int iEngineType2, String strSessionId2, ArrayList<CostTimeInfo> vecCostTime2) {
        this.vecSpeechData = vecSpeechData2;
        this.iRet = iRet2;
        this.strErrorMsg = strErrorMsg2;
        this.iEngineType = iEngineType2;
        this.strSessionId = strSessionId2;
        this.vecCostTime = vecCostTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.vecSpeechData, 0);
        _os.write(this.iRet, 1);
        if (this.strErrorMsg != null) {
            _os.write(this.strErrorMsg, 2);
        }
        _os.write(this.iEngineType, 3);
        if (this.strSessionId != null) {
            _os.write(this.strSessionId, 4);
        }
        if (this.vecCostTime != null) {
            _os.write((Collection) this.vecCostTime, 5);
        }
    }

    static {
        cache_vecSpeechData[0] = 0;
        cache_vecCostTime.add(new CostTimeInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecSpeechData = _is.read(cache_vecSpeechData, 0, true);
        this.iRet = _is.read(this.iRet, 1, false);
        this.strErrorMsg = _is.readString(2, false);
        this.iEngineType = _is.read(this.iEngineType, 3, false);
        this.strSessionId = _is.readString(4, false);
        this.vecCostTime = (ArrayList) _is.read((Object) cache_vecCostTime, 5, false);
    }
}
