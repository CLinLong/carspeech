package SmartService;

import java.io.Serializable;

public final class EPlatformType implements Serializable {
    public static final int _EAndroidPlatform = 1;
    public static final int _ELinuxPlatfrom = 3;
    public static final int _EOther = -1;
    public static final int _EiOSPlatfrom = 2;
}
