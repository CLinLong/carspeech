package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIVoiceUserInfo extends JceStruct {
    public long iBid = 0;
    public int iNet = 0;
    public int iOSType = 0;
    public String sAndroidPkgName = "";
    public String sAndroidSignature = "";
    public String sDeviceInfo = "";
    public String sIOSBundleId = "";
    public String sOSVersion = "";
    public String sSignInfo = "";

    public AIVoiceUserInfo() {
    }

    public AIVoiceUserInfo(long iBid2, int iOSType2, String sOSVersion2, int iNet2, String sDeviceInfo2, String sSignInfo2, String sAndroidSignature2, String sAndroidPkgName2, String sIOSBundleId2) {
        this.iBid = iBid2;
        this.iOSType = iOSType2;
        this.sOSVersion = sOSVersion2;
        this.iNet = iNet2;
        this.sDeviceInfo = sDeviceInfo2;
        this.sSignInfo = sSignInfo2;
        this.sAndroidSignature = sAndroidSignature2;
        this.sAndroidPkgName = sAndroidPkgName2;
        this.sIOSBundleId = sIOSBundleId2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iBid, 0);
        _os.write(this.iOSType, 1);
        if (this.sOSVersion != null) {
            _os.write(this.sOSVersion, 2);
        }
        _os.write(this.iNet, 3);
        if (this.sDeviceInfo != null) {
            _os.write(this.sDeviceInfo, 4);
        }
        if (this.sSignInfo != null) {
            _os.write(this.sSignInfo, 5);
        }
        if (this.sAndroidSignature != null) {
            _os.write(this.sAndroidSignature, 6);
        }
        if (this.sAndroidPkgName != null) {
            _os.write(this.sAndroidPkgName, 7);
        }
        if (this.sIOSBundleId != null) {
            _os.write(this.sIOSBundleId, 8);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iBid = _is.read(this.iBid, 0, false);
        this.iOSType = _is.read(this.iOSType, 1, false);
        this.sOSVersion = _is.readString(2, false);
        this.iNet = _is.read(this.iNet, 3, false);
        this.sDeviceInfo = _is.readString(4, false);
        this.sSignInfo = _is.readString(5, false);
        this.sAndroidSignature = _is.readString(6, false);
        this.sAndroidPkgName = _is.readString(7, false);
        this.sIOSBundleId = _is.readString(8, false);
    }
}
