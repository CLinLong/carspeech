package SmartService;

import java.io.Serializable;

public final class AIServerReturnType implements Serializable {
    public static final int _E_AISERVERRETURNTYPE_JSON_RESPONSE_DATA = 4;
    public static final int _E_AISERVERRETURNTYPE_RESPONSE_TEXT = 0;
    public static final int _E_AISERVERRETURNTYPE_SPEAK_TEXT = 2;
    public static final int _E_AISERVERRETURNTYPE_SPEAK_TIPS_TEXT = 3;
    public static final int _E_AISERVERRETURNTYPE_TIPS_TEXT = 1;
}
