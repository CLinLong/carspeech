package SmartService;

import java.io.Serializable;

public final class BusinessType implements Serializable {
    public static final int _E_CHANGEHONG_TV = 1;
    public static final int _E_DEFAULT = 0;
    public static final int _E_EXCEPTION_ERROR = 100;
    public static final int _E_HARDWARE_REPORT = 2;
    public static final int _E_REPORT_ALARM_INFO = 6;
    public static final int _E_REPORT_BUSINESS_TRAVEL = 4;
    public static final int _E_REPORT_PHONE_UPLOAD = 3;
    public static final int _E_REPORT_QBGUID_RELATION = 5;
}
