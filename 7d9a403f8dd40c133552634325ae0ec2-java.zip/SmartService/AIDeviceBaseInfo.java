package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIDeviceBaseInfo extends JceStruct {
    public String strAppAcessToken = "";
    public String strAppKey = "";
    public String strGuid = "";

    public AIDeviceBaseInfo() {
    }

    public AIDeviceBaseInfo(String strGuid2, String strAppKey2, String strAppAcessToken2) {
        this.strGuid = strGuid2;
        this.strAppKey = strAppKey2;
        this.strAppAcessToken = strAppAcessToken2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strGuid != null) {
            _os.write(this.strGuid, 0);
        }
        if (this.strAppKey != null) {
            _os.write(this.strAppKey, 1);
        }
        if (this.strAppAcessToken != null) {
            _os.write(this.strAppAcessToken, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strGuid = _is.readString(0, false);
        this.strAppKey = _is.readString(1, false);
        this.strAppAcessToken = _is.readString(2, false);
    }
}
