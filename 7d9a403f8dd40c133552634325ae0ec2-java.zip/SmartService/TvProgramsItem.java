package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class TvProgramsItem extends JceStruct {
    public int iIsPlaying = 0;
    public String strChannel = "";
    public String strDate = "";
    public String strTVName = "";
    public String strTime = "";
    public String strWeekPrint = "";

    public TvProgramsItem() {
    }

    public TvProgramsItem(String strDate2, String strWeekPrint2, String strChannel2, String strTime2, String strTVName2, int iIsPlaying2) {
        this.strDate = strDate2;
        this.strWeekPrint = strWeekPrint2;
        this.strChannel = strChannel2;
        this.strTime = strTime2;
        this.strTVName = strTVName2;
        this.iIsPlaying = iIsPlaying2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strDate != null) {
            _os.write(this.strDate, 0);
        }
        if (this.strWeekPrint != null) {
            _os.write(this.strWeekPrint, 1);
        }
        if (this.strChannel != null) {
            _os.write(this.strChannel, 2);
        }
        if (this.strTime != null) {
            _os.write(this.strTime, 3);
        }
        if (this.strTVName != null) {
            _os.write(this.strTVName, 4);
        }
        _os.write(this.iIsPlaying, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strDate = _is.readString(0, false);
        this.strWeekPrint = _is.readString(1, false);
        this.strChannel = _is.readString(2, false);
        this.strTime = _is.readString(3, false);
        this.strTVName = _is.readString(4, false);
        this.iIsPlaying = _is.read(this.iIsPlaying, 5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        TvProgramsItem temp = (TvProgramsItem) a.parseObject(text, TvProgramsItem.class);
        this.strDate = temp.strDate;
        this.strWeekPrint = temp.strWeekPrint;
        this.strChannel = temp.strChannel;
        this.strTime = temp.strTime;
        this.strTVName = temp.strTVName;
        this.iIsPlaying = temp.iIsPlaying;
    }
}
