package SmartService;

import java.io.Serializable;

public final class AIVoiceReqType implements Serializable {
    public static final int _E_AIVOICEREQTYPE_CONTINUOUS_END = 3;
    public static final int _E_AIVOICEREQTYPE_CONTINUOUS_ING = 2;
    public static final int _E_AIVOICEREQTYPE_CONTINUOUS_START = 1;
    public static final int _E_AIVOICEREQTYPE_NORMAL = 0;
}
