package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SurroundLocation extends JceStruct {
    public String adcode = "";
    public String city = "";
    public int coordType = 1;
    public String distict = "";
    public float lat = 0.0f;
    public float lng = 0.0f;
    public String nation = "";
    public String province = "";
    public String street = "";
    public String streetNum = "";

    public SurroundLocation() {
    }

    public SurroundLocation(float lat2, float lng2, int coordType2, String nation2, String province2, String city2, String distict2, String street2, String streetNum2, String adcode2) {
        this.lat = lat2;
        this.lng = lng2;
        this.coordType = coordType2;
        this.nation = nation2;
        this.province = province2;
        this.city = city2;
        this.distict = distict2;
        this.street = street2;
        this.streetNum = streetNum2;
        this.adcode = adcode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.lat, 0);
        _os.write(this.lng, 1);
        _os.write(this.coordType, 2);
        if (this.nation != null) {
            _os.write(this.nation, 3);
        }
        if (this.province != null) {
            _os.write(this.province, 4);
        }
        if (this.city != null) {
            _os.write(this.city, 5);
        }
        if (this.distict != null) {
            _os.write(this.distict, 6);
        }
        if (this.street != null) {
            _os.write(this.street, 7);
        }
        if (this.streetNum != null) {
            _os.write(this.streetNum, 8);
        }
        if (this.adcode != null) {
            _os.write(this.adcode, 9);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.lat = _is.read(this.lat, 0, true);
        this.lng = _is.read(this.lng, 1, true);
        this.coordType = _is.read(this.coordType, 2, false);
        this.nation = _is.readString(3, false);
        this.province = _is.readString(4, false);
        this.city = _is.readString(5, false);
        this.distict = _is.readString(6, false);
        this.street = _is.readString(7, false);
        this.streetNum = _is.readString(8, false);
        this.adcode = _is.readString(9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SurroundLocation temp = (SurroundLocation) a.parseObject(text, SurroundLocation.class);
        this.lat = temp.lat;
        this.lng = temp.lng;
        this.coordType = temp.coordType;
        this.nation = temp.nation;
        this.province = temp.province;
        this.city = temp.city;
        this.distict = temp.distict;
        this.street = temp.street;
        this.streetNum = temp.streetNum;
        this.adcode = temp.adcode;
    }
}
