package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class CostTimeInfo extends JceStruct {
    public int eCostType = 0;
    public int iCost = 0;
    public long iEnd = 0;
    public long iStart = 0;
    public int iStatus = 0;
    public String strCostName = "";

    public CostTimeInfo() {
    }

    public CostTimeInfo(int eCostType2, String strCostName2, long iStart2, long iEnd2, int iCost2, int iStatus2) {
        this.eCostType = eCostType2;
        this.strCostName = strCostName2;
        this.iStart = iStart2;
        this.iEnd = iEnd2;
        this.iCost = iCost2;
        this.iStatus = iStatus2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eCostType, 0);
        if (this.strCostName != null) {
            _os.write(this.strCostName, 1);
        }
        _os.write(this.iStart, 2);
        _os.write(this.iEnd, 3);
        _os.write(this.iCost, 4);
        _os.write(this.iStatus, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eCostType = _is.read(this.eCostType, 0, false);
        this.strCostName = _is.readString(1, false);
        this.iStart = _is.read(this.iStart, 2, false);
        this.iEnd = _is.read(this.iEnd, 3, false);
        this.iCost = _is.read(this.iCost, 4, false);
        this.iStatus = _is.read(this.iStatus, 5, false);
    }
}
