package SmartService;

import SmartAssistant.SemanticResponse;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AIResponseV2 extends JceStruct {
    static int cache_iStatus = 0;
    static AIServerReturnData cache_sData = new AIServerReturnData();
    static AIParseContent cache_sInput = new AIParseContent();
    static ErrCodeStatus cache_sRet = new ErrCodeStatus();
    static SemanticResponse cache_sSemanticRspData = new SemanticResponse();
    static AITTSResponseV2 cache_sTTSRspData = new AITTSResponseV2();
    static ArrayList<CostTimeInfo> cache_vecCostTime = new ArrayList<>();
    public int iStatus = 0;
    public AIServerReturnData sData = null;
    public AIParseContent sInput = null;
    public ErrCodeStatus sRet = null;
    public SemanticResponse sSemanticRspData = null;
    public AITTSResponseV2 sTTSRspData = null;
    public ArrayList<CostTimeInfo> vecCostTime = null;

    public AIResponseV2() {
    }

    public AIResponseV2(ErrCodeStatus sRet2, AIParseContent sInput2, AIServerReturnData sData2, SemanticResponse sSemanticRspData2, AITTSResponseV2 sTTSRspData2, int iStatus2, ArrayList<CostTimeInfo> vecCostTime2) {
        this.sRet = sRet2;
        this.sInput = sInput2;
        this.sData = sData2;
        this.sSemanticRspData = sSemanticRspData2;
        this.sTTSRspData = sTTSRspData2;
        this.iStatus = iStatus2;
        this.vecCostTime = vecCostTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sRet != null) {
            _os.write((JceStruct) this.sRet, 0);
        }
        if (this.sInput != null) {
            _os.write((JceStruct) this.sInput, 1);
        }
        if (this.sData != null) {
            _os.write((JceStruct) this.sData, 2);
        }
        if (this.sSemanticRspData != null) {
            _os.write((JceStruct) this.sSemanticRspData, 3);
        }
        if (this.sTTSRspData != null) {
            _os.write((JceStruct) this.sTTSRspData, 4);
        }
        _os.write(this.iStatus, 5);
        if (this.vecCostTime != null) {
            _os.write((Collection) this.vecCostTime, 6);
        }
    }

    static {
        cache_vecCostTime.add(new CostTimeInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sRet = (ErrCodeStatus) _is.read((JceStruct) cache_sRet, 0, false);
        this.sInput = (AIParseContent) _is.read((JceStruct) cache_sInput, 1, false);
        this.sData = (AIServerReturnData) _is.read((JceStruct) cache_sData, 2, false);
        this.sSemanticRspData = (SemanticResponse) _is.read((JceStruct) cache_sSemanticRspData, 3, false);
        this.sTTSRspData = (AITTSResponseV2) _is.read((JceStruct) cache_sTTSRspData, 4, false);
        this.iStatus = _is.read(this.iStatus, 5, false);
        this.vecCostTime = (ArrayList) _is.read((Object) cache_vecCostTime, 6, false);
    }
}
