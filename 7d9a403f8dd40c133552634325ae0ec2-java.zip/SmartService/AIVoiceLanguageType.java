package SmartService;

import java.io.Serializable;

public final class AIVoiceLanguageType implements Serializable {
    public static final int _E_AIVOICELANG_CHINESE = 1;
    public static final int _E_AIVOICELANG_DEFAULT = 0;
    public static final int _E_AIVOICELANG_ENGLISH = 2;
}
