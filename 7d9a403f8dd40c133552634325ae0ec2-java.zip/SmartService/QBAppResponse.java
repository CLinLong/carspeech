package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QBAppResponse extends JceStruct {
    static ArrayList<AppDataItem> cache_appDataVec = new ArrayList<>();
    public ArrayList<AppDataItem> appDataVec = null;
    public String moreUrl = "";
    public String sGuid = "";

    public QBAppResponse() {
    }

    public QBAppResponse(String sGuid2, ArrayList<AppDataItem> appDataVec2, String moreUrl2) {
        this.sGuid = sGuid2;
        this.appDataVec = appDataVec2;
        this.moreUrl = moreUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        _os.write((Collection) this.appDataVec, 1);
        if (this.moreUrl != null) {
            _os.write(this.moreUrl, 2);
        }
    }

    static {
        cache_appDataVec.add(new AppDataItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.appDataVec = (ArrayList) _is.read((Object) cache_appDataVec, 1, true);
        this.moreUrl = _is.readString(2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QBAppResponse temp = (QBAppResponse) a.parseObject(text, QBAppResponse.class);
        this.sGuid = temp.sGuid;
        this.appDataVec = temp.appDataVec;
        this.moreUrl = temp.moreUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
