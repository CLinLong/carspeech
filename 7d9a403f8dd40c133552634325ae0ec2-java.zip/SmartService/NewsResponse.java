package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NewsResponse extends JceStruct {
    static newsLink cache_moreLink = new newsLink();
    static ArrayList<NewsDataObj> cache_newsdataObjs = new ArrayList<>();
    static SpeakerInterval cache_speakerInterval = new SpeakerInterval();
    public newsLink moreLink = null;
    public ArrayList<NewsDataObj> newsdataObjs = null;
    public String replySpeakText = "";
    public String replyText = "";
    public String sGuid = "";
    public String sSession = "";
    public SpeakerInterval speakerInterval = null;
    public int total = 0;

    public NewsResponse() {
    }

    public NewsResponse(String sGuid2, ArrayList<NewsDataObj> newsdataObjs2, int total2, String replyText2, String replySpeakText2, String sSession2, newsLink moreLink2, SpeakerInterval speakerInterval2) {
        this.sGuid = sGuid2;
        this.newsdataObjs = newsdataObjs2;
        this.total = total2;
        this.replyText = replyText2;
        this.replySpeakText = replySpeakText2;
        this.sSession = sSession2;
        this.moreLink = moreLink2;
        this.speakerInterval = speakerInterval2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        _os.write((Collection) this.newsdataObjs, 1);
        _os.write(this.total, 2);
        if (this.replyText != null) {
            _os.write(this.replyText, 3);
        }
        if (this.replySpeakText != null) {
            _os.write(this.replySpeakText, 4);
        }
        if (this.sSession != null) {
            _os.write(this.sSession, 5);
        }
        if (this.moreLink != null) {
            _os.write((JceStruct) this.moreLink, 6);
        }
        if (this.speakerInterval != null) {
            _os.write((JceStruct) this.speakerInterval, 7);
        }
    }

    static {
        cache_newsdataObjs.add(new NewsDataObj());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.newsdataObjs = (ArrayList) _is.read((Object) cache_newsdataObjs, 1, true);
        this.total = _is.read(this.total, 2, true);
        this.replyText = _is.readString(3, false);
        this.replySpeakText = _is.readString(4, false);
        this.sSession = _is.readString(5, false);
        this.moreLink = (newsLink) _is.read((JceStruct) cache_moreLink, 6, false);
        this.speakerInterval = (SpeakerInterval) _is.read((JceStruct) cache_speakerInterval, 7, false);
    }
}
