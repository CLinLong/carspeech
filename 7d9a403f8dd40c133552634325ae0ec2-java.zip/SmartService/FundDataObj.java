package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class FundDataObj extends JceStruct {
    public String accnav = "";
    public String navChangeRatio = "";
    public String navTime = "";
    public String netWorth = "";
    public String recentValue = "";
    public String stockCode = "";
    public String stockName = "";
    public String valueChangeRatio = "";
    public String valueTime = "";

    public FundDataObj() {
    }

    public FundDataObj(String stockName2, String stockCode2, String recentValue2, String valueChangeRatio2, String valueTime2, String netWorth2, String accnav2, String navChangeRatio2, String navTime2) {
        this.stockName = stockName2;
        this.stockCode = stockCode2;
        this.recentValue = recentValue2;
        this.valueChangeRatio = valueChangeRatio2;
        this.valueTime = valueTime2;
        this.netWorth = netWorth2;
        this.accnav = accnav2;
        this.navChangeRatio = navChangeRatio2;
        this.navTime = navTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.stockName, 1);
        _os.write(this.stockCode, 2);
        _os.write(this.recentValue, 3);
        _os.write(this.valueChangeRatio, 4);
        _os.write(this.valueTime, 5);
        _os.write(this.netWorth, 6);
        if (this.accnav != null) {
            _os.write(this.accnav, 7);
        }
        if (this.navChangeRatio != null) {
            _os.write(this.navChangeRatio, 8);
        }
        if (this.navTime != null) {
            _os.write(this.navTime, 9);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.stockName = _is.readString(1, true);
        this.stockCode = _is.readString(2, true);
        this.recentValue = _is.readString(3, true);
        this.valueChangeRatio = _is.readString(4, true);
        this.valueTime = _is.readString(5, true);
        this.netWorth = _is.readString(6, true);
        this.accnav = _is.readString(7, false);
        this.navChangeRatio = _is.readString(8, false);
        this.navTime = _is.readString(9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        FundDataObj temp = (FundDataObj) a.parseObject(text, FundDataObj.class);
        this.stockName = temp.stockName;
        this.stockCode = temp.stockCode;
        this.recentValue = temp.recentValue;
        this.valueChangeRatio = temp.valueChangeRatio;
        this.valueTime = temp.valueTime;
        this.netWorth = temp.netWorth;
        this.accnav = temp.accnav;
        this.navChangeRatio = temp.navChangeRatio;
        this.navTime = temp.navTime;
    }
}
