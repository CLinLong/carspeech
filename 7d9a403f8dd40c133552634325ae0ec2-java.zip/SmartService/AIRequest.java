package SmartService;

import SmartAssistant.Response;
import SmartAssistant.UserBase;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public final class AIRequest extends JceStruct {
    static Map<String, String> cache_mapDataSlot = new HashMap();
    static WXIDVerifty cache_sAccountInfo = new WXIDVerifty();
    static AISemanticMeta cache_sSemanticMeta = new AISemanticMeta();
    static Response cache_sSemanticResult = new Response();
    static AIAccountInfo cache_sUserAccount = new AIAccountInfo();
    static UserBase cache_sUserBase = new UserBase();
    static AIVoiceMeta cache_sVoiceMeta = new AIVoiceMeta();
    static ArrayList<AISDKContent> cache_vecDataEx = new ArrayList<>();
    static byte[] cache_vecVoiceData = new byte[1];
    public boolean bForceSessionComplete = false;
    public int eRequestType = 0;
    public int iSemanticType = 1;
    public Map<String, String> mapDataSlot = null;
    public WXIDVerifty sAccountInfo = null;
    public AISemanticMeta sSemanticMeta = null;
    public Response sSemanticResult = null;
    public AIAccountInfo sUserAccount = null;
    public UserBase sUserBase = null;
    public AIVoiceMeta sVoiceMeta = null;
    public String strGUID = "";
    public String strQUA = "";
    public String strText = "";
    public ArrayList<AISDKContent> vecDataEx = null;
    public byte[] vecVoiceData = null;

    public AIRequest() {
    }

    public AIRequest(String strGUID2, String strQUA2, WXIDVerifty sAccountInfo2, int eRequestType2, String strText2, byte[] vecVoiceData2, UserBase sUserBase2, int iSemanticType2, Response sSemanticResult2, AIVoiceMeta sVoiceMeta2, Map<String, String> mapDataSlot2, boolean bForceSessionComplete2, AISemanticMeta sSemanticMeta2, AIAccountInfo sUserAccount2, ArrayList<AISDKContent> vecDataEx2) {
        this.strGUID = strGUID2;
        this.strQUA = strQUA2;
        this.sAccountInfo = sAccountInfo2;
        this.eRequestType = eRequestType2;
        this.strText = strText2;
        this.vecVoiceData = vecVoiceData2;
        this.sUserBase = sUserBase2;
        this.iSemanticType = iSemanticType2;
        this.sSemanticResult = sSemanticResult2;
        this.sVoiceMeta = sVoiceMeta2;
        this.mapDataSlot = mapDataSlot2;
        this.bForceSessionComplete = bForceSessionComplete2;
        this.sSemanticMeta = sSemanticMeta2;
        this.sUserAccount = sUserAccount2;
        this.vecDataEx = vecDataEx2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strGUID, 0);
        _os.write(this.strQUA, 1);
        if (this.sAccountInfo != null) {
            _os.write((JceStruct) this.sAccountInfo, 2);
        }
        _os.write(this.eRequestType, 3);
        if (this.strText != null) {
            _os.write(this.strText, 4);
        }
        if (this.vecVoiceData != null) {
            _os.write(this.vecVoiceData, 5);
        }
        if (this.sUserBase != null) {
            _os.write((JceStruct) this.sUserBase, 6);
        }
        _os.write(this.iSemanticType, 7);
        if (this.sSemanticResult != null) {
            _os.write((JceStruct) this.sSemanticResult, 8);
        }
        if (this.sVoiceMeta != null) {
            _os.write((JceStruct) this.sVoiceMeta, 9);
        }
        if (this.mapDataSlot != null) {
            _os.write((Map) this.mapDataSlot, 10);
        }
        _os.write(this.bForceSessionComplete, 11);
        if (this.sSemanticMeta != null) {
            _os.write((JceStruct) this.sSemanticMeta, 12);
        }
        if (this.sUserAccount != null) {
            _os.write((JceStruct) this.sUserAccount, 13);
        }
        if (this.vecDataEx != null) {
            _os.write((Collection) this.vecDataEx, 14);
        }
    }

    static {
        cache_vecVoiceData[0] = 0;
        cache_mapDataSlot.put("", "");
        cache_vecDataEx.add(new AISDKContent());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strGUID = _is.readString(0, true);
        this.strQUA = _is.readString(1, true);
        this.sAccountInfo = (WXIDVerifty) _is.read((JceStruct) cache_sAccountInfo, 2, false);
        this.eRequestType = _is.read(this.eRequestType, 3, true);
        this.strText = _is.readString(4, false);
        this.vecVoiceData = _is.read(cache_vecVoiceData, 5, false);
        this.sUserBase = (UserBase) _is.read((JceStruct) cache_sUserBase, 6, false);
        this.iSemanticType = _is.read(this.iSemanticType, 7, false);
        this.sSemanticResult = (Response) _is.read((JceStruct) cache_sSemanticResult, 8, false);
        this.sVoiceMeta = (AIVoiceMeta) _is.read((JceStruct) cache_sVoiceMeta, 9, false);
        this.mapDataSlot = (Map) _is.read((Object) cache_mapDataSlot, 10, false);
        this.bForceSessionComplete = _is.read(this.bForceSessionComplete, 11, false);
        this.sSemanticMeta = (AISemanticMeta) _is.read((JceStruct) cache_sSemanticMeta, 12, false);
        this.sUserAccount = (AIAccountInfo) _is.read((JceStruct) cache_sUserAccount, 13, false);
        this.vecDataEx = (ArrayList) _is.read((Object) cache_vecDataEx, 14, false);
    }
}
