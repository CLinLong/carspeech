package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public final class CommonRspData extends JceStruct {
    static int cache_eDataType = 0;
    static Map<Integer, CardElement> cache_mapDataSource = new HashMap();
    static ArrayList<byte[]> cache_vecCommDataBytes = new ArrayList<>();
    public int eDataType = 0;
    public Map<Integer, CardElement> mapDataSource = null;
    public String strAllUrl = "";
    public ArrayList<byte[]> vecCommDataBytes = null;

    public CommonRspData() {
    }

    public CommonRspData(int eDataType2, ArrayList<byte[]> vecCommDataBytes2, String strAllUrl2, Map<Integer, CardElement> mapDataSource2) {
        this.eDataType = eDataType2;
        this.vecCommDataBytes = vecCommDataBytes2;
        this.strAllUrl = strAllUrl2;
        this.mapDataSource = mapDataSource2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eDataType, 0);
        if (this.vecCommDataBytes != null) {
            _os.write((Collection) this.vecCommDataBytes, 1);
        }
        if (this.strAllUrl != null) {
            _os.write(this.strAllUrl, 2);
        }
        if (this.mapDataSource != null) {
            _os.write((Map) this.mapDataSource, 3);
        }
    }

    static {
        byte[] __var_1 = new byte[1];
        __var_1[0] = 0;
        cache_vecCommDataBytes.add(__var_1);
        cache_mapDataSource.put(0, new CardElement());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eDataType = _is.read(this.eDataType, 0, true);
        this.vecCommDataBytes = (ArrayList) _is.read((Object) cache_vecCommDataBytes, 1, false);
        this.strAllUrl = _is.readString(2, false);
        this.mapDataSource = (Map) _is.read((Object) cache_mapDataSource, 3, false);
    }
}
