package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class IDCenterUserInfo extends JceStruct {
    public int iAge = 0;
    public int iSex = 0;
    public String sCity = "";
    public String sImage = "";
    public String sNickName = "";
    public String sProvince = "";
    public String sQBId = "";

    public IDCenterUserInfo() {
    }

    public IDCenterUserInfo(String sQBId2, String sNickName2, String sImage2, int iSex2, int iAge2, String sProvince2, String sCity2) {
        this.sQBId = sQBId2;
        this.sNickName = sNickName2;
        this.sImage = sImage2;
        this.iSex = iSex2;
        this.iAge = iAge2;
        this.sProvince = sProvince2;
        this.sCity = sCity2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sQBId, 0);
        _os.write(this.sNickName, 1);
        _os.write(this.sImage, 2);
        _os.write(this.iSex, 3);
        _os.write(this.iAge, 4);
        if (this.sProvince != null) {
            _os.write(this.sProvince, 5);
        }
        if (this.sCity != null) {
            _os.write(this.sCity, 6);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sQBId = _is.readString(0, true);
        this.sNickName = _is.readString(1, true);
        this.sImage = _is.readString(2, true);
        this.iSex = _is.read(this.iSex, 3, false);
        this.iAge = _is.read(this.iAge, 4, false);
        this.sProvince = _is.readString(5, false);
        this.sCity = _is.readString(6, false);
    }
}
