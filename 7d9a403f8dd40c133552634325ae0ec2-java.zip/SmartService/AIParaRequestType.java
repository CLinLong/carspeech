package SmartService;

import java.io.Serializable;

public final class AIParaRequestType implements Serializable {
    public static final int _E_AIPARAREQUESTTYPE_CLIENT = 0;
    public static final int _E_AIPARAREQUESTTYPE_SERVER = 1;
}
