package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ReportEndStateRequest extends JceStruct {
    static int cache_ePlayState = 0;
    static AIAccountBaseInfo cache_sAccountBaseInfo = new AIAccountBaseInfo();
    static AIDeviceBaseInfo cache_sDeviceBaseInfo = new AIDeviceBaseInfo();
    public int ePlayState = 0;
    public int offset = 0;
    public AIAccountBaseInfo sAccountBaseInfo = null;
    public AIDeviceBaseInfo sDeviceBaseInfo = null;
    public String strDomain = "";
    public String strId = "";
    public String strIntent = "";
    public String strJsonBlobInfo = "";

    public ReportEndStateRequest() {
    }

    public ReportEndStateRequest(AIAccountBaseInfo sAccountBaseInfo2, AIDeviceBaseInfo sDeviceBaseInfo2, String strDomain2, String strIntent2, int ePlayState2, String strId2, int offset2, String strJsonBlobInfo2) {
        this.sAccountBaseInfo = sAccountBaseInfo2;
        this.sDeviceBaseInfo = sDeviceBaseInfo2;
        this.strDomain = strDomain2;
        this.strIntent = strIntent2;
        this.ePlayState = ePlayState2;
        this.strId = strId2;
        this.offset = offset2;
        this.strJsonBlobInfo = strJsonBlobInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sAccountBaseInfo != null) {
            _os.write((JceStruct) this.sAccountBaseInfo, 0);
        }
        if (this.sDeviceBaseInfo != null) {
            _os.write((JceStruct) this.sDeviceBaseInfo, 1);
        }
        if (this.strDomain != null) {
            _os.write(this.strDomain, 2);
        }
        if (this.strIntent != null) {
            _os.write(this.strIntent, 3);
        }
        _os.write(this.ePlayState, 4);
        if (this.strId != null) {
            _os.write(this.strId, 5);
        }
        _os.write(this.offset, 6);
        if (this.strJsonBlobInfo != null) {
            _os.write(this.strJsonBlobInfo, 7);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAccountBaseInfo = (AIAccountBaseInfo) _is.read((JceStruct) cache_sAccountBaseInfo, 0, false);
        this.sDeviceBaseInfo = (AIDeviceBaseInfo) _is.read((JceStruct) cache_sDeviceBaseInfo, 1, false);
        this.strDomain = _is.readString(2, false);
        this.strIntent = _is.readString(3, false);
        this.ePlayState = _is.read(this.ePlayState, 4, false);
        this.strId = _is.readString(5, false);
        this.offset = _is.read(this.offset, 6, false);
        this.strJsonBlobInfo = _is.readString(7, false);
    }
}
