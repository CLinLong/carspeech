package SmartService;

import SmartAssistant.Semantic;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class ServerCommonRsp extends JceStruct {
    static CommonRspData cache_sCommRspData = new CommonRspData();
    static ArrayList<Semantic> cache_vecCandidateSemantic = new ArrayList<>();
    static ArrayList<NotifyServerInfo> cache_vecNotifyInfo = new ArrayList<>();
    static byte[] cache_vecRspDataBytes = new byte[1];
    static ArrayList<AIResponseDataItem> cache_vectRspDataItems = new ArrayList<>();
    public CommonRspData sCommRspData = null;
    public String strJsonToSemantic = "";
    public String strRspJsonData = "";
    public String strSpeakText = "";
    public String strSpeakTipsText = "";
    public String strTipsText = "";
    public ArrayList<Semantic> vecCandidateSemantic = null;
    public ArrayList<NotifyServerInfo> vecNotifyInfo = null;
    public byte[] vecRspDataBytes = null;
    public ArrayList<AIResponseDataItem> vectRspDataItems = null;

    public ServerCommonRsp() {
    }

    public ServerCommonRsp(ArrayList<AIResponseDataItem> vectRspDataItems2, byte[] vecRspDataBytes2, String strTipsText2, String strSpeakText2, ArrayList<Semantic> vecCandidateSemantic2, String strSpeakTipsText2, String strRspJsonData2, CommonRspData sCommRspData2, String strJsonToSemantic2, ArrayList<NotifyServerInfo> vecNotifyInfo2) {
        this.vectRspDataItems = vectRspDataItems2;
        this.vecRspDataBytes = vecRspDataBytes2;
        this.strTipsText = strTipsText2;
        this.strSpeakText = strSpeakText2;
        this.vecCandidateSemantic = vecCandidateSemantic2;
        this.strSpeakTipsText = strSpeakTipsText2;
        this.strRspJsonData = strRspJsonData2;
        this.sCommRspData = sCommRspData2;
        this.strJsonToSemantic = strJsonToSemantic2;
        this.vecNotifyInfo = vecNotifyInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vectRspDataItems, 0);
        _os.write(this.vecRspDataBytes, 1);
        _os.write(this.strTipsText, 2);
        _os.write(this.strSpeakText, 3);
        if (this.vecCandidateSemantic != null) {
            _os.write((Collection) this.vecCandidateSemantic, 4);
        }
        if (this.strSpeakTipsText != null) {
            _os.write(this.strSpeakTipsText, 5);
        }
        if (this.strRspJsonData != null) {
            _os.write(this.strRspJsonData, 6);
        }
        if (this.sCommRspData != null) {
            _os.write((JceStruct) this.sCommRspData, 7);
        }
        if (this.strJsonToSemantic != null) {
            _os.write(this.strJsonToSemantic, 8);
        }
        if (this.vecNotifyInfo != null) {
            _os.write((Collection) this.vecNotifyInfo, 9);
        }
    }

    static {
        cache_vectRspDataItems.add(new AIResponseDataItem());
        cache_vecRspDataBytes[0] = 0;
        cache_vecCandidateSemantic.add(new Semantic());
        cache_vecNotifyInfo.add(new NotifyServerInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vectRspDataItems = (ArrayList) _is.read((Object) cache_vectRspDataItems, 0, true);
        this.vecRspDataBytes = _is.read(cache_vecRspDataBytes, 1, true);
        this.strTipsText = _is.readString(2, true);
        this.strSpeakText = _is.readString(3, true);
        this.vecCandidateSemantic = (ArrayList) _is.read((Object) cache_vecCandidateSemantic, 4, false);
        this.strSpeakTipsText = _is.readString(5, false);
        this.strRspJsonData = _is.readString(6, false);
        this.sCommRspData = (CommonRspData) _is.read((JceStruct) cache_sCommRspData, 7, false);
        this.strJsonToSemantic = _is.readString(8, false);
        this.vecNotifyInfo = (ArrayList) _is.read((Object) cache_vecNotifyInfo, 9, false);
    }
}
