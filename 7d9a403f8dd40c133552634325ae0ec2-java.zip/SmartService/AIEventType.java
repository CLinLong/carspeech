package SmartService;

import java.io.Serializable;

public final class AIEventType implements Serializable {
    public static final int _E_AIEVENTTYPE_CLICK = 5;
    public static final int _E_AIEVENTTYPE_LOCATION = 4;
    public static final int _E_AIEVENTTYPE_SCAN = 3;
    public static final int _E_AIEVENTTYPE_SUBSCRIBE = 1;
    public static final int _E_AIEVENTTYPE_UNKNOWN = 0;
    public static final int _E_AIEVENTTYPE_UNSUBSCRIBE = 2;
    public static final int _E_AIEVENTTYPE_VIEW = 6;
}
