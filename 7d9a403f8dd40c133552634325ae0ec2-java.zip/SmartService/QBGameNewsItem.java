package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QBGameNewsItem extends JceStruct {
    static ArrayList<String> cache_vecImgCovers = new ArrayList<>();
    public long lNewsTime = 0;
    public String strDetailUrl = "";
    public String strNewsId = "";
    public String strSummary = "";
    public String strTags = "";
    public String strTitle = "";
    public String strVideoCover = "";
    public ArrayList<String> vecImgCovers = null;

    public QBGameNewsItem() {
    }

    public QBGameNewsItem(long lNewsTime2, String strNewsId2, String strSummary2, String strTags2, String strTitle2, String strDetailUrl2, String strVideoCover2, ArrayList<String> vecImgCovers2) {
        this.lNewsTime = lNewsTime2;
        this.strNewsId = strNewsId2;
        this.strSummary = strSummary2;
        this.strTags = strTags2;
        this.strTitle = strTitle2;
        this.strDetailUrl = strDetailUrl2;
        this.strVideoCover = strVideoCover2;
        this.vecImgCovers = vecImgCovers2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.lNewsTime, 0);
        _os.write(this.strNewsId, 1);
        if (this.strSummary != null) {
            _os.write(this.strSummary, 2);
        }
        if (this.strTags != null) {
            _os.write(this.strTags, 3);
        }
        _os.write(this.strTitle, 4);
        _os.write(this.strDetailUrl, 5);
        if (this.strVideoCover != null) {
            _os.write(this.strVideoCover, 6);
        }
        if (this.vecImgCovers != null) {
            _os.write((Collection) this.vecImgCovers, 7);
        }
    }

    static {
        cache_vecImgCovers.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.lNewsTime = _is.read(this.lNewsTime, 0, true);
        this.strNewsId = _is.readString(1, true);
        this.strSummary = _is.readString(2, false);
        this.strTags = _is.readString(3, false);
        this.strTitle = _is.readString(4, true);
        this.strDetailUrl = _is.readString(5, true);
        this.strVideoCover = _is.readString(6, false);
        this.vecImgCovers = (ArrayList) _is.read((Object) cache_vecImgCovers, 7, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QBGameNewsItem temp = (QBGameNewsItem) a.parseObject(text, QBGameNewsItem.class);
        this.lNewsTime = temp.lNewsTime;
        this.strNewsId = temp.strNewsId;
        this.strSummary = temp.strSummary;
        this.strTags = temp.strTags;
        this.strTitle = temp.strTitle;
        this.strDetailUrl = temp.strDetailUrl;
        this.strVideoCover = temp.strVideoCover;
        this.vecImgCovers = temp.vecImgCovers;
    }
}
