package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class StockResponse extends JceStruct {
    static ArrayList<FundDataObj> cache_funddataObjs = new ArrayList<>();
    static ArrayList<StockDataObj> cache_stockdataObjs = new ArrayList<>();
    public ArrayList<FundDataObj> funddataObjs = null;
    public String replyWords = "";
    public String sGuid = "";
    public ArrayList<StockDataObj> stockdataObjs = null;

    public StockResponse() {
    }

    public StockResponse(String sGuid2, ArrayList<StockDataObj> stockdataObjs2, ArrayList<FundDataObj> funddataObjs2, String replyWords2) {
        this.sGuid = sGuid2;
        this.stockdataObjs = stockdataObjs2;
        this.funddataObjs = funddataObjs2;
        this.replyWords = replyWords2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        if (this.stockdataObjs != null) {
            _os.write((Collection) this.stockdataObjs, 1);
        }
        if (this.funddataObjs != null) {
            _os.write((Collection) this.funddataObjs, 2);
        }
        if (this.replyWords != null) {
            _os.write(this.replyWords, 3);
        }
    }

    static {
        cache_stockdataObjs.add(new StockDataObj());
        cache_funddataObjs.add(new FundDataObj());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.stockdataObjs = (ArrayList) _is.read((Object) cache_stockdataObjs, 1, false);
        this.funddataObjs = (ArrayList) _is.read((Object) cache_funddataObjs, 2, false);
        this.replyWords = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        StockResponse temp = (StockResponse) a.parseObject(text, StockResponse.class);
        this.sGuid = temp.sGuid;
        this.stockdataObjs = temp.stockdataObjs;
        this.funddataObjs = temp.funddataObjs;
        this.replyWords = temp.replyWords;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
