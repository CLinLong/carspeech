package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NewsDataObj extends JceStruct {
    public String editTime = "";
    public String newsAbstract = "";
    public String newsFrom = "";
    public String newsId = "";
    public String source = "";
    public String title = "";
    public String titleImageUrl = "";
    public String type = "";
    public long voiceSize = 0;
    public String voiceUrl = "";

    public NewsDataObj() {
    }

    public NewsDataObj(String type2, String title2, String newsAbstract2, String source2, String voiceUrl2, long voiceSize2, String editTime2, String titleImageUrl2, String newsFrom2, String newsId2) {
        this.type = type2;
        this.title = title2;
        this.newsAbstract = newsAbstract2;
        this.source = source2;
        this.voiceUrl = voiceUrl2;
        this.voiceSize = voiceSize2;
        this.editTime = editTime2;
        this.titleImageUrl = titleImageUrl2;
        this.newsFrom = newsFrom2;
        this.newsId = newsId2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.type != null) {
            _os.write(this.type, 0);
        }
        _os.write(this.title, 1);
        if (this.newsAbstract != null) {
            _os.write(this.newsAbstract, 2);
        }
        if (this.source != null) {
            _os.write(this.source, 3);
        }
        if (this.voiceUrl != null) {
            _os.write(this.voiceUrl, 4);
        }
        _os.write(this.voiceSize, 5);
        if (this.editTime != null) {
            _os.write(this.editTime, 6);
        }
        if (this.titleImageUrl != null) {
            _os.write(this.titleImageUrl, 7);
        }
        if (this.newsFrom != null) {
            _os.write(this.newsFrom, 8);
        }
        if (this.newsId != null) {
            _os.write(this.newsId, 9);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.type = _is.readString(0, false);
        this.title = _is.readString(1, true);
        this.newsAbstract = _is.readString(2, false);
        this.source = _is.readString(3, false);
        this.voiceUrl = _is.readString(4, false);
        this.voiceSize = _is.read(this.voiceSize, 5, true);
        this.editTime = _is.readString(6, false);
        this.titleImageUrl = _is.readString(7, false);
        this.newsFrom = _is.readString(8, false);
        this.newsId = _is.readString(9, false);
    }
}
