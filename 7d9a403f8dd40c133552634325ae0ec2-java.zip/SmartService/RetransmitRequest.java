package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class RetransmitRequest extends JceStruct {
    static byte[] cache_vAnonymousRequestBuffer = new byte[1];
    public String sClientIp = "";
    public String sFuncName = "";
    public String sGuid = "";
    public String sServantName = "";
    public byte[] vAnonymousRequestBuffer = null;

    public RetransmitRequest() {
    }

    public RetransmitRequest(byte[] vAnonymousRequestBuffer2, String sServantName2, String sFuncName2, String sGuid2, String sClientIp2) {
        this.vAnonymousRequestBuffer = vAnonymousRequestBuffer2;
        this.sServantName = sServantName2;
        this.sFuncName = sFuncName2;
        this.sGuid = sGuid2;
        this.sClientIp = sClientIp2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.vAnonymousRequestBuffer, 0);
        if (this.sServantName != null) {
            _os.write(this.sServantName, 1);
        }
        if (this.sFuncName != null) {
            _os.write(this.sFuncName, 2);
        }
        if (this.sGuid != null) {
            _os.write(this.sGuid, 3);
        }
        if (this.sClientIp != null) {
            _os.write(this.sClientIp, 4);
        }
    }

    static {
        cache_vAnonymousRequestBuffer[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vAnonymousRequestBuffer = _is.read(cache_vAnonymousRequestBuffer, 0, true);
        this.sServantName = _is.readString(1, false);
        this.sFuncName = _is.readString(2, false);
        this.sGuid = _is.readString(3, false);
        this.sClientIp = _is.readString(4, false);
    }
}
