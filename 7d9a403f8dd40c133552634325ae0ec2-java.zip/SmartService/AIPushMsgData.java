package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIPushMsgData extends JceStruct {
    static int cache_eMsgType = 0;
    public boolean bVibrate = true;
    public int eMsgType = 0;
    public String strContent = "";
    public String strTitle = "";

    public AIPushMsgData() {
    }

    public AIPushMsgData(int eMsgType2, String strContent2, String strTitle2, boolean bVibrate2) {
        this.eMsgType = eMsgType2;
        this.strContent = strContent2;
        this.strTitle = strTitle2;
        this.bVibrate = bVibrate2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eMsgType, 0);
        _os.write(this.strContent, 1);
        _os.write(this.strTitle, 2);
        _os.write(this.bVibrate, 3);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eMsgType = _is.read(this.eMsgType, 0, true);
        this.strContent = _is.readString(1, true);
        this.strTitle = _is.readString(2, true);
        this.bVibrate = _is.read(this.bVibrate, 3, false);
    }
}
