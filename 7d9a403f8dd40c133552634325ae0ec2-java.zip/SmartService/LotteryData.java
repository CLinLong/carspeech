package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class LotteryData extends JceStruct {
    static ArrayList<String> cache_codeVec = new ArrayList<>();
    public ArrayList<String> codeVec = null;
    public int colorCodeCnt = 0;
    public String strDate = "";
    public String strName = "";
    public String strPeriod = "";
    public String strUrl = "";

    public LotteryData() {
    }

    public LotteryData(String strName2, String strPeriod2, String strDate2, ArrayList<String> codeVec2, int colorCodeCnt2, String strUrl2) {
        this.strName = strName2;
        this.strPeriod = strPeriod2;
        this.strDate = strDate2;
        this.codeVec = codeVec2;
        this.colorCodeCnt = colorCodeCnt2;
        this.strUrl = strUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strName != null) {
            _os.write(this.strName, 0);
        }
        if (this.strPeriod != null) {
            _os.write(this.strPeriod, 1);
        }
        if (this.strDate != null) {
            _os.write(this.strDate, 2);
        }
        if (this.codeVec != null) {
            _os.write((Collection) this.codeVec, 3);
        }
        _os.write(this.colorCodeCnt, 4);
        if (this.strUrl != null) {
            _os.write(this.strUrl, 5);
        }
    }

    static {
        cache_codeVec.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strName = _is.readString(0, false);
        this.strPeriod = _is.readString(1, false);
        this.strDate = _is.readString(2, false);
        this.codeVec = (ArrayList) _is.read((Object) cache_codeVec, 3, false);
        this.colorCodeCnt = _is.read(this.colorCodeCnt, 4, false);
        this.strUrl = _is.readString(5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        LotteryData temp = (LotteryData) a.parseObject(text, LotteryData.class);
        this.strName = temp.strName;
        this.strPeriod = temp.strPeriod;
        this.strDate = temp.strDate;
        this.codeVec = temp.codeVec;
        this.colorCodeCnt = temp.colorCodeCnt;
        this.strUrl = temp.strUrl;
    }
}
