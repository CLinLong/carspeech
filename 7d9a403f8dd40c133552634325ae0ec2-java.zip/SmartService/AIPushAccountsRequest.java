package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AIPushAccountsRequest extends JceStruct {
    static int cache_eAccountType = 0;
    static AIPushMsgData cache_sMsgData = new AIPushMsgData();
    static ArrayList<String> cache_vecAccounts = new ArrayList<>();
    public int eAccountType = 0;
    public AIPushMsgData sMsgData = null;
    public ArrayList<String> vecAccounts = null;

    public AIPushAccountsRequest() {
    }

    public AIPushAccountsRequest(int eAccountType2, ArrayList<String> vecAccounts2, AIPushMsgData sMsgData2) {
        this.eAccountType = eAccountType2;
        this.vecAccounts = vecAccounts2;
        this.sMsgData = sMsgData2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eAccountType, 0);
        _os.write((Collection) this.vecAccounts, 1);
        _os.write((JceStruct) this.sMsgData, 2);
    }

    static {
        cache_vecAccounts.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eAccountType = _is.read(this.eAccountType, 0, true);
        this.vecAccounts = (ArrayList) _is.read((Object) cache_vecAccounts, 1, true);
        this.sMsgData = (AIPushMsgData) _is.read((JceStruct) cache_sMsgData, 2, true);
    }
}
