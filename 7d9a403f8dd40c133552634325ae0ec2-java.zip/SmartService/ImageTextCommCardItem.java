package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public final class ImageTextCommCardItem extends JceStruct {
    static ImageInfo cache_imageInfo = new ImageInfo();
    static ArrayList<Map<Integer, String>> cache_vecContentItems = new ArrayList<>();
    public ImageInfo imageInfo = null;
    public String strDestURL = "";
    public ArrayList<Map<Integer, String>> vecContentItems = null;

    public ImageTextCommCardItem() {
    }

    public ImageTextCommCardItem(String strDestURL2, ImageInfo imageInfo2, ArrayList<Map<Integer, String>> vecContentItems2) {
        this.strDestURL = strDestURL2;
        this.imageInfo = imageInfo2;
        this.vecContentItems = vecContentItems2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strDestURL != null) {
            _os.write(this.strDestURL, 0);
        }
        if (this.imageInfo != null) {
            _os.write((JceStruct) this.imageInfo, 1);
        }
        if (this.vecContentItems != null) {
            _os.write((Collection) this.vecContentItems, 2);
        }
    }

    static {
        Map<Integer, String> __var_5 = new HashMap<>();
        __var_5.put(0, "");
        cache_vecContentItems.add(__var_5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strDestURL = _is.readString(0, false);
        this.imageInfo = (ImageInfo) _is.read((JceStruct) cache_imageInfo, 1, false);
        this.vecContentItems = (ArrayList) _is.read((Object) cache_vecContentItems, 2, false);
    }
}
