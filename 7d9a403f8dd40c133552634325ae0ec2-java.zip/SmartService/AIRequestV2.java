package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIRequestV2 extends JceStruct {
    static int cache_iParaType = 0;
    static AIRequestParam cache_sPara = new AIRequestParam();
    static AIRequestUserInfo cache_sUserInfo = new AIRequestUserInfo();
    static AIInputContent cache_sUserInput = new AIInputContent();
    public int iParaType = 0;
    public AIRequestParam sPara = null;
    public AIRequestUserInfo sUserInfo = null;
    public AIInputContent sUserInput = null;

    public AIRequestV2() {
    }

    public AIRequestV2(AIRequestUserInfo sUserInfo2, AIInputContent sUserInput2, AIRequestParam sPara2, int iParaType2) {
        this.sUserInfo = sUserInfo2;
        this.sUserInput = sUserInput2;
        this.sPara = sPara2;
        this.iParaType = iParaType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sUserInfo != null) {
            _os.write((JceStruct) this.sUserInfo, 0);
        }
        if (this.sUserInput != null) {
            _os.write((JceStruct) this.sUserInput, 1);
        }
        if (this.sPara != null) {
            _os.write((JceStruct) this.sPara, 2);
        }
        _os.write(this.iParaType, 3);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sUserInfo = (AIRequestUserInfo) _is.read((JceStruct) cache_sUserInfo, 0, false);
        this.sUserInput = (AIInputContent) _is.read((JceStruct) cache_sUserInput, 1, false);
        this.sPara = (AIRequestParam) _is.read((JceStruct) cache_sPara, 2, false);
        this.iParaType = _is.read(this.iParaType, 3, false);
    }
}
