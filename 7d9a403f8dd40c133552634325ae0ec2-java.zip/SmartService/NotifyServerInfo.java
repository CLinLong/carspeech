package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NotifyServerInfo extends JceStruct {
    public int iServerTypeId = 0;
    public String strData = "";

    public NotifyServerInfo() {
    }

    public NotifyServerInfo(int iServerTypeId2, String strData2) {
        this.iServerTypeId = iServerTypeId2;
        this.strData = strData2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iServerTypeId, 0);
        if (this.strData != null) {
            _os.write(this.strData, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iServerTypeId = _is.read(this.iServerTypeId, 0, false);
        this.strData = _is.readString(1, false);
    }
}
