package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QBGameGiftRsp extends JceStruct {
    static ArrayList<QBGameGiftItem> cache_vecGameGifts = new ArrayList<>();
    public String strMoreUrl = "";
    public ArrayList<QBGameGiftItem> vecGameGifts = null;

    public QBGameGiftRsp() {
    }

    public QBGameGiftRsp(ArrayList<QBGameGiftItem> vecGameGifts2, String strMoreUrl2) {
        this.vecGameGifts = vecGameGifts2;
        this.strMoreUrl = strMoreUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vecGameGifts, 0);
        if (this.strMoreUrl != null) {
            _os.write(this.strMoreUrl, 1);
        }
    }

    static {
        cache_vecGameGifts.add(new QBGameGiftItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecGameGifts = (ArrayList) _is.read((Object) cache_vecGameGifts, 0, true);
        this.strMoreUrl = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QBGameGiftRsp temp = (QBGameGiftRsp) a.parseObject(text, QBGameGiftRsp.class);
        this.vecGameGifts = temp.vecGameGifts;
        this.strMoreUrl = temp.strMoreUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
