package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NovelData extends JceStruct {
    public int readerCnt = 0;
    public int retainCnt = 0;
    public int riseCnt = 0;
    public double score = 0.0d;
    public String strAbstract = "";
    public String strAuthor = "";
    public String strImageUrl = "";
    public String strTitle = "";
    public String strType = "";
    public String strUrl = "";
    public int voteCnt = 0;

    public NovelData() {
    }

    public NovelData(String strType2, String strTitle2, String strAuthor2, String strAbstract2, String strImageUrl2, String strUrl2, int riseCnt2, int readerCnt2, int retainCnt2, int voteCnt2, double score2) {
        this.strType = strType2;
        this.strTitle = strTitle2;
        this.strAuthor = strAuthor2;
        this.strAbstract = strAbstract2;
        this.strImageUrl = strImageUrl2;
        this.strUrl = strUrl2;
        this.riseCnt = riseCnt2;
        this.readerCnt = readerCnt2;
        this.retainCnt = retainCnt2;
        this.voteCnt = voteCnt2;
        this.score = score2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strType != null) {
            _os.write(this.strType, 0);
        }
        if (this.strTitle != null) {
            _os.write(this.strTitle, 1);
        }
        if (this.strAuthor != null) {
            _os.write(this.strAuthor, 2);
        }
        if (this.strAbstract != null) {
            _os.write(this.strAbstract, 3);
        }
        if (this.strImageUrl != null) {
            _os.write(this.strImageUrl, 4);
        }
        if (this.strUrl != null) {
            _os.write(this.strUrl, 5);
        }
        _os.write(this.riseCnt, 6);
        _os.write(this.readerCnt, 7);
        _os.write(this.retainCnt, 8);
        _os.write(this.voteCnt, 9);
        _os.write(this.score, 10);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strType = _is.readString(0, false);
        this.strTitle = _is.readString(1, false);
        this.strAuthor = _is.readString(2, false);
        this.strAbstract = _is.readString(3, false);
        this.strImageUrl = _is.readString(4, false);
        this.strUrl = _is.readString(5, false);
        this.riseCnt = _is.read(this.riseCnt, 6, false);
        this.readerCnt = _is.read(this.readerCnt, 7, false);
        this.retainCnt = _is.read(this.retainCnt, 8, false);
        this.voteCnt = _is.read(this.voteCnt, 9, false);
        this.score = _is.read(this.score, 10, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        NovelData temp = (NovelData) a.parseObject(text, NovelData.class);
        this.strType = temp.strType;
        this.strTitle = temp.strTitle;
        this.strAuthor = temp.strAuthor;
        this.strAbstract = temp.strAbstract;
        this.strImageUrl = temp.strImageUrl;
        this.strUrl = temp.strUrl;
        this.riseCnt = temp.riseCnt;
        this.readerCnt = temp.readerCnt;
        this.retainCnt = temp.retainCnt;
        this.voteCnt = temp.voteCnt;
        this.score = temp.score;
    }
}
