package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SportsResponse extends JceStruct {
    static LinkObj cache_allMatchObj = new LinkObj();
    static ArrayList<SportsScore> cache_sportsScores = new ArrayList<>();
    static ArrayList<SportsDataObj> cache_sportsdataObjs = new ArrayList<>();
    public LinkObj allMatchObj = null;
    public String noSupport = "";
    public String replyWords = "";
    public String sGuid = "";
    public String speakerReplyWords = "";
    public ArrayList<SportsScore> sportsScores = null;
    public ArrayList<SportsDataObj> sportsdataObjs = null;

    public SportsResponse() {
    }

    public SportsResponse(String sGuid2, ArrayList<SportsDataObj> sportsdataObjs2, String noSupport2, String replyWords2, ArrayList<SportsScore> sportsScores2, LinkObj allMatchObj2, String speakerReplyWords2) {
        this.sGuid = sGuid2;
        this.sportsdataObjs = sportsdataObjs2;
        this.noSupport = noSupport2;
        this.replyWords = replyWords2;
        this.sportsScores = sportsScores2;
        this.allMatchObj = allMatchObj2;
        this.speakerReplyWords = speakerReplyWords2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        _os.write((Collection) this.sportsdataObjs, 1);
        if (this.noSupport != null) {
            _os.write(this.noSupport, 2);
        }
        if (this.replyWords != null) {
            _os.write(this.replyWords, 3);
        }
        if (this.sportsScores != null) {
            _os.write((Collection) this.sportsScores, 4);
        }
        if (this.allMatchObj != null) {
            _os.write((JceStruct) this.allMatchObj, 5);
        }
        if (this.speakerReplyWords != null) {
            _os.write(this.speakerReplyWords, 6);
        }
    }

    static {
        cache_sportsdataObjs.add(new SportsDataObj());
        cache_sportsScores.add(new SportsScore());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.sportsdataObjs = (ArrayList) _is.read((Object) cache_sportsdataObjs, 1, true);
        this.noSupport = _is.readString(2, false);
        this.replyWords = _is.readString(3, false);
        this.sportsScores = (ArrayList) _is.read((Object) cache_sportsScores, 4, false);
        this.allMatchObj = (LinkObj) _is.read((JceStruct) cache_allMatchObj, 5, false);
        this.speakerReplyWords = _is.readString(6, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SportsResponse temp = (SportsResponse) a.parseObject(text, SportsResponse.class);
        this.sGuid = temp.sGuid;
        this.sportsdataObjs = temp.sportsdataObjs;
        this.noSupport = temp.noSupport;
        this.replyWords = temp.replyWords;
        this.sportsScores = temp.sportsScores;
        this.allMatchObj = temp.allMatchObj;
        this.speakerReplyWords = temp.speakerReplyWords;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
