package SmartService;

import java.io.Serializable;

public final class AISemanticType implements Serializable {
    public static final int _E_AISEMANTICTYPE_AUTO = 1;
    public static final int _E_AISEMANTICTYPE_CLIENT = 0;
}
