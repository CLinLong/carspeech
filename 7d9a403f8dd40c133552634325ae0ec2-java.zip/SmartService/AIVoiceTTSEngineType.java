package SmartService;

import java.io.Serializable;

public final class AIVoiceTTSEngineType implements Serializable {
    public static final int _E_AIVOICETTSENGINETYPE_BAIDU = 1;
    public static final int _E_AIVOICETTSENGINETYPE_BETA = 5;
    public static final int _E_AIVOICETTSENGINETYPE_IFLY = 3;
    public static final int _E_AIVOICETTSENGINETYPE_NONE = 0;
    public static final int _E_AIVOICETTSENGINETYPE_WX = 2;
    public static final int _E_AIVOICETTSENGINETYPE_YIYA = 4;
}
