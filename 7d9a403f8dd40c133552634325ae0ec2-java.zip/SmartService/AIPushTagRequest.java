package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AIPushTagRequest extends JceStruct {
    static int cache_eTagOpt = 0;
    static AIPushMsgData cache_sMsgData = new AIPushMsgData();
    static ArrayList<String> cache_vecTags = new ArrayList<>();
    public int eTagOpt = 0;
    public AIPushMsgData sMsgData = null;
    public ArrayList<String> vecTags = null;

    public AIPushTagRequest() {
    }

    public AIPushTagRequest(ArrayList<String> vecTags2, int eTagOpt2, AIPushMsgData sMsgData2) {
        this.vecTags = vecTags2;
        this.eTagOpt = eTagOpt2;
        this.sMsgData = sMsgData2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vecTags, 0);
        _os.write(this.eTagOpt, 1);
        _os.write((JceStruct) this.sMsgData, 2);
    }

    static {
        cache_vecTags.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecTags = (ArrayList) _is.read((Object) cache_vecTags, 0, true);
        this.eTagOpt = _is.read(this.eTagOpt, 1, true);
        this.sMsgData = (AIPushMsgData) _is.read((JceStruct) cache_sMsgData, 2, true);
    }
}
