package SmartService;

import SmartAssistant.ChatBot;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIRequestUserInfo extends JceStruct {
    static AIAccountBaseInfo cache_sAccountInfo = new AIAccountBaseInfo();
    static ChatBot cache_sBotType = new ChatBot();
    static AIDeviceBaseInfo cache_sDeviceInfo = new AIDeviceBaseInfo();
    static byte[] cache_vecLBSKeyData = new byte[1];
    public AIAccountBaseInfo sAccountInfo = null;
    public ChatBot sBotType = null;
    public AIDeviceBaseInfo sDeviceInfo = null;
    public String strQUA = "";
    public byte[] vecLBSKeyData = null;

    public AIRequestUserInfo() {
    }

    public AIRequestUserInfo(AIDeviceBaseInfo sDeviceInfo2, AIAccountBaseInfo sAccountInfo2, String strQUA2, byte[] vecLBSKeyData2, ChatBot sBotType2) {
        this.sDeviceInfo = sDeviceInfo2;
        this.sAccountInfo = sAccountInfo2;
        this.strQUA = strQUA2;
        this.vecLBSKeyData = vecLBSKeyData2;
        this.sBotType = sBotType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sDeviceInfo != null) {
            _os.write((JceStruct) this.sDeviceInfo, 0);
        }
        if (this.sAccountInfo != null) {
            _os.write((JceStruct) this.sAccountInfo, 1);
        }
        if (this.strQUA != null) {
            _os.write(this.strQUA, 2);
        }
        if (this.vecLBSKeyData != null) {
            _os.write(this.vecLBSKeyData, 3);
        }
        if (this.sBotType != null) {
            _os.write((JceStruct) this.sBotType, 4);
        }
    }

    static {
        cache_vecLBSKeyData[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sDeviceInfo = (AIDeviceBaseInfo) _is.read((JceStruct) cache_sDeviceInfo, 0, false);
        this.sAccountInfo = (AIAccountBaseInfo) _is.read((JceStruct) cache_sAccountInfo, 1, false);
        this.strQUA = _is.readString(2, false);
        this.vecLBSKeyData = _is.read(cache_vecLBSKeyData, 3, false);
        this.sBotType = (ChatBot) _is.read((JceStruct) cache_sBotType, 4, false);
    }
}
