package SmartService;

import java.io.Serializable;

public final class EnumJokeStatus implements Serializable {
    public static final int _RES_JOKE_ERROR = -1;
    public static final int _RES_JOKE_GIF = 2;
    public static final int _RES_JOKE_NONE = 0;
    public static final int _RES_JOKE_PIC = 3;
    public static final int _RES_JOKE_TEXT = 1;
    public static final int _RES_JOKE_VOICE = 4;
}
