package SmartService;

import java.io.Serializable;

public final class EIDCenterTokenType implements Serializable {
    public static final int _IDCENTER_TOKEN_A2 = 4;
    public static final int _IDCENTER_TOKEN_ATOEKN = 2;
    public static final int _IDCENTER_TOKEN_LSKEY = 6;
    public static final int _IDCENTER_TOKEN_QQACCESSTOEKEN = 7;
    public static final int _IDCENTER_TOKEN_SID = 1;
    public static final int _IDCENTER_TOKEN_SKEY = 5;
    public static final int _IDCENTER_TOKEN_ST = 3;
}
