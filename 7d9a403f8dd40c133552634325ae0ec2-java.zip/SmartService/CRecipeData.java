package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class CRecipeData extends JceStruct {
    static ArrayList<CCookStep> cache_cookStepVec = new ArrayList<>();
    static CRecipeImageSet cache_imageSet = new CRecipeImageSet();
    static ArrayList<CCookMaterial> cache_majorVec = new ArrayList<>();
    static ArrayList<CCookMaterial> cache_minorVec = new ArrayList<>();
    static ArrayList<String> cache_strTagVec = new ArrayList<>();
    public int collectCnt = 0;
    public ArrayList<CCookStep> cookStepVec = null;
    public CRecipeImageSet imageSet = null;
    public int imageWeight = 0;
    public int isAuthorVerified = 0;
    public int isRecommend = 0;
    public int learnCnt = 0;
    public int likeCnt = 0;
    public ArrayList<CCookMaterial> majorVec = null;
    public ArrayList<CCookMaterial> minorVec = null;
    public String strAuthorHeadImgUrl = "";
    public String strAuthorId = "";
    public String strAuthorName = "";
    public String strCookDifficulty = "";
    public String strCookStory = "";
    public String strCookTime = "";
    public String strCreateTime = "";
    public String strDetailUrl = "";
    public String strId = "";
    public String strModifyTime = "";
    public String strName = "";
    public ArrayList<String> strTagVec = null;
    public String strTips = "";
    public String strVideoUrl = "";
    public int viewCnt = 0;

    public CRecipeData() {
    }

    public CRecipeData(String strId2, String strName2, ArrayList<CCookMaterial> majorVec2, ArrayList<CCookMaterial> minorVec2, ArrayList<String> strTagVec2, String strDetailUrl2, CRecipeImageSet imageSet2, int imageWeight2, String strVideoUrl2, ArrayList<CCookStep> cookStepVec2, String strCookDifficulty2, String strCookTime2, String strTips2, String strCookStory2, int viewCnt2, int collectCnt2, int likeCnt2, int learnCnt2, String strAuthorId2, String strAuthorName2, String strAuthorHeadImgUrl2, int isAuthorVerified2, int isRecommend2, String strCreateTime2, String strModifyTime2) {
        this.strId = strId2;
        this.strName = strName2;
        this.majorVec = majorVec2;
        this.minorVec = minorVec2;
        this.strTagVec = strTagVec2;
        this.strDetailUrl = strDetailUrl2;
        this.imageSet = imageSet2;
        this.imageWeight = imageWeight2;
        this.strVideoUrl = strVideoUrl2;
        this.cookStepVec = cookStepVec2;
        this.strCookDifficulty = strCookDifficulty2;
        this.strCookTime = strCookTime2;
        this.strTips = strTips2;
        this.strCookStory = strCookStory2;
        this.viewCnt = viewCnt2;
        this.collectCnt = collectCnt2;
        this.likeCnt = likeCnt2;
        this.learnCnt = learnCnt2;
        this.strAuthorId = strAuthorId2;
        this.strAuthorName = strAuthorName2;
        this.strAuthorHeadImgUrl = strAuthorHeadImgUrl2;
        this.isAuthorVerified = isAuthorVerified2;
        this.isRecommend = isRecommend2;
        this.strCreateTime = strCreateTime2;
        this.strModifyTime = strModifyTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strId != null) {
            _os.write(this.strId, 0);
        }
        if (this.strName != null) {
            _os.write(this.strName, 1);
        }
        if (this.majorVec != null) {
            _os.write((Collection) this.majorVec, 2);
        }
        if (this.minorVec != null) {
            _os.write((Collection) this.minorVec, 3);
        }
        if (this.strTagVec != null) {
            _os.write((Collection) this.strTagVec, 4);
        }
        if (this.strDetailUrl != null) {
            _os.write(this.strDetailUrl, 5);
        }
        if (this.imageSet != null) {
            _os.write((JceStruct) this.imageSet, 6);
        }
        _os.write(this.imageWeight, 7);
        if (this.strVideoUrl != null) {
            _os.write(this.strVideoUrl, 8);
        }
        if (this.cookStepVec != null) {
            _os.write((Collection) this.cookStepVec, 9);
        }
        if (this.strCookDifficulty != null) {
            _os.write(this.strCookDifficulty, 10);
        }
        if (this.strCookTime != null) {
            _os.write(this.strCookTime, 11);
        }
        if (this.strTips != null) {
            _os.write(this.strTips, 12);
        }
        if (this.strCookStory != null) {
            _os.write(this.strCookStory, 13);
        }
        _os.write(this.viewCnt, 14);
        _os.write(this.collectCnt, 15);
        _os.write(this.likeCnt, 16);
        _os.write(this.learnCnt, 17);
        if (this.strAuthorId != null) {
            _os.write(this.strAuthorId, 18);
        }
        if (this.strAuthorName != null) {
            _os.write(this.strAuthorName, 19);
        }
        if (this.strAuthorHeadImgUrl != null) {
            _os.write(this.strAuthorHeadImgUrl, 20);
        }
        _os.write(this.isAuthorVerified, 21);
        _os.write(this.isRecommend, 22);
        if (this.strCreateTime != null) {
            _os.write(this.strCreateTime, 23);
        }
        if (this.strModifyTime != null) {
            _os.write(this.strModifyTime, 24);
        }
    }

    static {
        cache_majorVec.add(new CCookMaterial());
        cache_minorVec.add(new CCookMaterial());
        cache_strTagVec.add("");
        cache_cookStepVec.add(new CCookStep());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strId = _is.readString(0, false);
        this.strName = _is.readString(1, false);
        this.majorVec = (ArrayList) _is.read((Object) cache_majorVec, 2, false);
        this.minorVec = (ArrayList) _is.read((Object) cache_minorVec, 3, false);
        this.strTagVec = (ArrayList) _is.read((Object) cache_strTagVec, 4, false);
        this.strDetailUrl = _is.readString(5, false);
        this.imageSet = (CRecipeImageSet) _is.read((JceStruct) cache_imageSet, 6, false);
        this.imageWeight = _is.read(this.imageWeight, 7, false);
        this.strVideoUrl = _is.readString(8, false);
        this.cookStepVec = (ArrayList) _is.read((Object) cache_cookStepVec, 9, false);
        this.strCookDifficulty = _is.readString(10, false);
        this.strCookTime = _is.readString(11, false);
        this.strTips = _is.readString(12, false);
        this.strCookStory = _is.readString(13, false);
        this.viewCnt = _is.read(this.viewCnt, 14, false);
        this.collectCnt = _is.read(this.collectCnt, 15, false);
        this.likeCnt = _is.read(this.likeCnt, 16, false);
        this.learnCnt = _is.read(this.learnCnt, 17, false);
        this.strAuthorId = _is.readString(18, false);
        this.strAuthorName = _is.readString(19, false);
        this.strAuthorHeadImgUrl = _is.readString(20, false);
        this.isAuthorVerified = _is.read(this.isAuthorVerified, 21, false);
        this.isRecommend = _is.read(this.isRecommend, 22, false);
        this.strCreateTime = _is.readString(23, false);
        this.strModifyTime = _is.readString(24, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        CRecipeData temp = (CRecipeData) a.parseObject(text, CRecipeData.class);
        this.strId = temp.strId;
        this.strName = temp.strName;
        this.majorVec = temp.majorVec;
        this.minorVec = temp.minorVec;
        this.strTagVec = temp.strTagVec;
        this.strDetailUrl = temp.strDetailUrl;
        this.imageSet = temp.imageSet;
        this.imageWeight = temp.imageWeight;
        this.strVideoUrl = temp.strVideoUrl;
        this.cookStepVec = temp.cookStepVec;
        this.strCookDifficulty = temp.strCookDifficulty;
        this.strCookTime = temp.strCookTime;
        this.strTips = temp.strTips;
        this.strCookStory = temp.strCookStory;
        this.viewCnt = temp.viewCnt;
        this.collectCnt = temp.collectCnt;
        this.likeCnt = temp.likeCnt;
        this.learnCnt = temp.learnCnt;
        this.strAuthorId = temp.strAuthorId;
        this.strAuthorName = temp.strAuthorName;
        this.strAuthorHeadImgUrl = temp.strAuthorHeadImgUrl;
        this.isAuthorVerified = temp.isAuthorVerified;
        this.isRecommend = temp.isRecommend;
        this.strCreateTime = temp.strCreateTime;
        this.strModifyTime = temp.strModifyTime;
    }
}
