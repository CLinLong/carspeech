package SmartService;

import java.io.Serializable;

public final class AIEventDataType implements Serializable {
    public static final int _E_AIEVENTDATATYPE_EVENTKEY = 1;
    public static final int _E_AIEVENTDATATYPE_LATITUDE = 3;
    public static final int _E_AIEVENTDATATYPE_LONGITUDE = 4;
    public static final int _E_AIEVENTDATATYPE_PRECISION = 5;
    public static final int _E_AIEVENTDATATYPE_TICKET = 2;
    public static final int _E_AIEVENTDATATYPE_UNKNOWN = 0;
}
