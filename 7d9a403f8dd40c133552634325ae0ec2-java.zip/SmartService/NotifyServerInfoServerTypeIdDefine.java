package SmartService;

import java.io.Serializable;

public final class NotifyServerInfoServerTypeIdDefine implements Serializable {
    public static final int _E_NOTIFY_SERVER_INFO_GLOBAL_CTRL_RETURN_DATA = 2;
    public static final int _E_NOTIFY_SERVER_INFO_SERVER_TYPE_ID_GLOBAL_CTRL = 0;
    public static final int _E_NOTIFY_SERVER_INFO_SERVER_TYPE_ID_SEMANTIC = 1;
}
