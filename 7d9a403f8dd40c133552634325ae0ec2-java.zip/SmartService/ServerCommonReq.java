package SmartService;

import SmartAssistant.SemanticRequest;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class ServerCommonReq extends JceStruct {
    static SemanticRequest cache_sSemanticReq = new SemanticRequest();
    static ArrayList<AISDKContent> cache_vecDataEx = new ArrayList<>();
    public SemanticRequest sSemanticReq = null;
    public ArrayList<AISDKContent> vecDataEx = null;

    public ServerCommonReq() {
    }

    public ServerCommonReq(SemanticRequest sSemanticReq2, ArrayList<AISDKContent> vecDataEx2) {
        this.sSemanticReq = sSemanticReq2;
        this.vecDataEx = vecDataEx2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sSemanticReq != null) {
            _os.write((JceStruct) this.sSemanticReq, 0);
        }
        if (this.vecDataEx != null) {
            _os.write((Collection) this.vecDataEx, 1);
        }
    }

    static {
        cache_vecDataEx.add(new AISDKContent());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sSemanticReq = (SemanticRequest) _is.read((JceStruct) cache_sSemanticReq, 0, false);
        this.vecDataEx = (ArrayList) _is.read((Object) cache_vecDataEx, 1, false);
    }
}
