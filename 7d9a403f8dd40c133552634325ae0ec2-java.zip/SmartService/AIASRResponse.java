package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AIASRResponse extends JceStruct {
    static ArrayList<RecoTextInfo> cache_vecRecoTextInfos = new ArrayList<>();
    static ArrayList<String> cache_vecResult = new ArrayList<>();
    public boolean bFinalResult = true;
    public double dParticalDecodedTime = 0.0d;
    public double dSilenceTime = 0.0d;
    public int iResultSeq = 0;
    public String strSegmentText = "";
    public ArrayList<RecoTextInfo> vecRecoTextInfos = null;
    public ArrayList<String> vecResult = null;

    public AIASRResponse() {
    }

    public AIASRResponse(ArrayList<String> vecResult2, int iResultSeq2, boolean bFinalResult2, double dSilenceTime2, double dParticalDecodedTime2, ArrayList<RecoTextInfo> vecRecoTextInfos2, String strSegmentText2) {
        this.vecResult = vecResult2;
        this.iResultSeq = iResultSeq2;
        this.bFinalResult = bFinalResult2;
        this.dSilenceTime = dSilenceTime2;
        this.dParticalDecodedTime = dParticalDecodedTime2;
        this.vecRecoTextInfos = vecRecoTextInfos2;
        this.strSegmentText = strSegmentText2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vecResult != null) {
            _os.write((Collection) this.vecResult, 0);
        }
        _os.write(this.iResultSeq, 1);
        _os.write(this.bFinalResult, 2);
        _os.write(this.dSilenceTime, 3);
        _os.write(this.dParticalDecodedTime, 4);
        if (this.vecRecoTextInfos != null) {
            _os.write((Collection) this.vecRecoTextInfos, 5);
        }
        if (this.strSegmentText != null) {
            _os.write(this.strSegmentText, 6);
        }
    }

    static {
        cache_vecResult.add("");
        cache_vecRecoTextInfos.add(new RecoTextInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecResult = (ArrayList) _is.read((Object) cache_vecResult, 0, false);
        this.iResultSeq = _is.read(this.iResultSeq, 1, false);
        this.bFinalResult = _is.read(this.bFinalResult, 2, false);
        this.dSilenceTime = _is.read(this.dSilenceTime, 3, false);
        this.dParticalDecodedTime = _is.read(this.dParticalDecodedTime, 4, false);
        this.vecRecoTextInfos = (ArrayList) _is.read((Object) cache_vecRecoTextInfos, 5, false);
        this.strSegmentText = _is.readString(6, false);
    }
}
