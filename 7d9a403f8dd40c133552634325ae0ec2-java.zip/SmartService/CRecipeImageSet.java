package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class CRecipeImageSet extends JceStruct {
    public String str120ImageUrl = "";
    public String str200ImageUrl = "";
    public String str300ImageUrl = "";
    public String str600ImageUrl = "";
    public String strBaseImageUrl = "";
    public String strOriginImageUrl = "";

    public CRecipeImageSet() {
    }

    public CRecipeImageSet(String strBaseImageUrl2, String str120ImageUrl2, String str200ImageUrl2, String str300ImageUrl2, String str600ImageUrl2, String strOriginImageUrl2) {
        this.strBaseImageUrl = strBaseImageUrl2;
        this.str120ImageUrl = str120ImageUrl2;
        this.str200ImageUrl = str200ImageUrl2;
        this.str300ImageUrl = str300ImageUrl2;
        this.str600ImageUrl = str600ImageUrl2;
        this.strOriginImageUrl = strOriginImageUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strBaseImageUrl != null) {
            _os.write(this.strBaseImageUrl, 0);
        }
        if (this.str120ImageUrl != null) {
            _os.write(this.str120ImageUrl, 1);
        }
        if (this.str200ImageUrl != null) {
            _os.write(this.str200ImageUrl, 2);
        }
        if (this.str300ImageUrl != null) {
            _os.write(this.str300ImageUrl, 3);
        }
        if (this.str600ImageUrl != null) {
            _os.write(this.str600ImageUrl, 4);
        }
        if (this.strOriginImageUrl != null) {
            _os.write(this.strOriginImageUrl, 5);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strBaseImageUrl = _is.readString(0, false);
        this.str120ImageUrl = _is.readString(1, false);
        this.str200ImageUrl = _is.readString(2, false);
        this.str300ImageUrl = _is.readString(3, false);
        this.str600ImageUrl = _is.readString(4, false);
        this.strOriginImageUrl = _is.readString(5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        CRecipeImageSet temp = (CRecipeImageSet) a.parseObject(text, CRecipeImageSet.class);
        this.strBaseImageUrl = temp.strBaseImageUrl;
        this.str120ImageUrl = temp.str120ImageUrl;
        this.str200ImageUrl = temp.str200ImageUrl;
        this.str300ImageUrl = temp.str300ImageUrl;
        this.str600ImageUrl = temp.str600ImageUrl;
        this.strOriginImageUrl = temp.strOriginImageUrl;
    }
}
