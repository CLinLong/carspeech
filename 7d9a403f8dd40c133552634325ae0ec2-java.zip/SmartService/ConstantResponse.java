package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class ConstantResponse extends JceStruct {
    static ArrayList<String> cache_constantVec = new ArrayList<>();
    public ArrayList<String> constantVec = null;
    public String sGuid = "";

    public ConstantResponse() {
    }

    public ConstantResponse(String sGuid2, ArrayList<String> constantVec2) {
        this.sGuid = sGuid2;
        this.constantVec = constantVec2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        _os.write((Collection) this.constantVec, 1);
    }

    static {
        cache_constantVec.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.constantVec = (ArrayList) _is.read((Object) cache_constantVec, 1, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        ConstantResponse temp = (ConstantResponse) a.parseObject(text, ConstantResponse.class);
        this.sGuid = temp.sGuid;
        this.constantVec = temp.constantVec;
    }
}
