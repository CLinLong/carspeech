package SmartService;

import java.io.Serializable;

public final class EAIPushIdType implements Serializable {
    public static final int _ETVSSpeakerAppIdentifier = 6;
    public static final int _ETVSSpeakerIdentifier = 5;
    public static final int _ETencentXGIdentifier = 2;
    public static final int _EWechatPublicNumber = 1;
    public static final int _EWehomeSpeakerAppIdentifier = 4;
    public static final int _EWehomeSpeakerIdentifier = 3;
}
