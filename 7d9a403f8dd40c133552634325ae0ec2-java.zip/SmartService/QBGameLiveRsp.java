package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QBGameLiveRsp extends JceStruct {
    static ArrayList<QBGameLiveItem> cache_vecGameLives = new ArrayList<>();
    public String strMoreUrl = "";
    public ArrayList<QBGameLiveItem> vecGameLives = null;

    public QBGameLiveRsp() {
    }

    public QBGameLiveRsp(ArrayList<QBGameLiveItem> vecGameLives2, String strMoreUrl2) {
        this.vecGameLives = vecGameLives2;
        this.strMoreUrl = strMoreUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vecGameLives, 0);
        if (this.strMoreUrl != null) {
            _os.write(this.strMoreUrl, 1);
        }
    }

    static {
        cache_vecGameLives.add(new QBGameLiveItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecGameLives = (ArrayList) _is.read((Object) cache_vecGameLives, 0, true);
        this.strMoreUrl = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QBGameLiveRsp temp = (QBGameLiveRsp) a.parseObject(text, QBGameLiveRsp.class);
        this.vecGameLives = temp.vecGameLives;
        this.strMoreUrl = temp.strMoreUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
