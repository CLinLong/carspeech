package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AITTSResponseV2 extends JceStruct {
    static byte[] cache_vecSpeechData = new byte[1];
    public int iEngineType = 0;
    public int iStatus = 0;
    public byte[] vecSpeechData = null;

    public AITTSResponseV2() {
    }

    public AITTSResponseV2(byte[] vecSpeechData2, int iStatus2, int iEngineType2) {
        this.vecSpeechData = vecSpeechData2;
        this.iStatus = iStatus2;
        this.iEngineType = iEngineType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.vecSpeechData != null) {
            _os.write(this.vecSpeechData, 0);
        }
        _os.write(this.iStatus, 1);
        _os.write(this.iEngineType, 2);
    }

    static {
        cache_vecSpeechData[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecSpeechData = _is.read(cache_vecSpeechData, 0, false);
        this.iStatus = _is.read(this.iStatus, 1, false);
        this.iEngineType = _is.read(this.iEngineType, 2, false);
    }
}
