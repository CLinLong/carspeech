package SmartService;

import java.io.Serializable;

public final class QB_VIDEO_CLASS implements Serializable {
    public static final int _E_QBVIDEO_CLASS_LONG = 1;
    public static final int _E_QBVIDEO_CLASS_SHORT = 2;
    public static final int _E_QBVIDEO_CLASS_UNKNOWN = 0;
}
