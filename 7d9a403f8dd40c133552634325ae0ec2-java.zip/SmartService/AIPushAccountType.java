package SmartService;

import java.io.Serializable;

public final class AIPushAccountType implements Serializable {
    public static final int _E_AIPUSHACCOUNT_DEVICETOKEN = 4;
    public static final int _E_AIPUSHACCOUNT_GUID = 5;
    public static final int _E_AIPUSHACCOUNT_QQ = 0;
    public static final int _E_AIPUSHACCOUNT_QQOPENID = 1;
    public static final int _E_AIPUSHACCOUNT_WXOPENID = 3;
    public static final int _E_AIPUSHACCOUNT_WXUNIID = 2;
}
