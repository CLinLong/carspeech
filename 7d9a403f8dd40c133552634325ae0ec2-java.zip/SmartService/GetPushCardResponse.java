package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class GetPushCardResponse extends JceStruct {
    static ArrayList<AIPushMsg> cache_msgVec = new ArrayList<>();
    public String errMsg = "";
    public ArrayList<AIPushMsg> msgVec = null;
    public int retCode = 0;

    public GetPushCardResponse() {
    }

    public GetPushCardResponse(int retCode2, String errMsg2, ArrayList<AIPushMsg> msgVec2) {
        this.retCode = retCode2;
        this.errMsg = errMsg2;
        this.msgVec = msgVec2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.retCode, 0);
        if (this.errMsg != null) {
            _os.write(this.errMsg, 1);
        }
        if (this.msgVec != null) {
            _os.write((Collection) this.msgVec, 2);
        }
    }

    static {
        cache_msgVec.add(new AIPushMsg());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.retCode = _is.read(this.retCode, 0, false);
        this.errMsg = _is.readString(1, false);
        this.msgVec = (ArrayList) _is.read((Object) cache_msgVec, 2, false);
    }
}
