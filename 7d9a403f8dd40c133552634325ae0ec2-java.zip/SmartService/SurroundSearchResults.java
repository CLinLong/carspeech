package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SurroundSearchResults extends JceStruct {
    static SurroundSearchParams cache_searchParams = new SurroundSearchParams();
    static ArrayList<SurroundSpotInfo> cache_spots = new ArrayList<>();
    public String errorMsg = "";
    public int errorNo = 0;
    public String moreUrl = "";
    public SurroundSearchParams searchParams = null;
    public ArrayList<SurroundSpotInfo> spots = null;

    public SurroundSearchResults() {
    }

    public SurroundSearchResults(int errorNo2, String errorMsg2, ArrayList<SurroundSpotInfo> spots2, SurroundSearchParams searchParams2, String moreUrl2) {
        this.errorNo = errorNo2;
        this.errorMsg = errorMsg2;
        this.spots = spots2;
        this.searchParams = searchParams2;
        this.moreUrl = moreUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.errorNo, 0);
        _os.write(this.errorMsg, 1);
        _os.write((Collection) this.spots, 2);
        if (this.searchParams != null) {
            _os.write((JceStruct) this.searchParams, 3);
        }
        if (this.moreUrl != null) {
            _os.write(this.moreUrl, 4);
        }
    }

    static {
        cache_spots.add(new SurroundSpotInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.errorNo = _is.read(this.errorNo, 0, true);
        this.errorMsg = _is.readString(1, true);
        this.spots = (ArrayList) _is.read((Object) cache_spots, 2, true);
        this.searchParams = (SurroundSearchParams) _is.read((JceStruct) cache_searchParams, 3, false);
        this.moreUrl = _is.readString(4, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SurroundSearchResults temp = (SurroundSearchResults) a.parseObject(text, SurroundSearchResults.class);
        this.errorNo = temp.errorNo;
        this.errorMsg = temp.errorMsg;
        this.spots = temp.spots;
        this.searchParams = temp.searchParams;
        this.moreUrl = temp.moreUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
