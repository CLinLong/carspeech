package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.HashMap;
import java.util.Map;

public final class ElementItem extends JceStruct {
    static int cache_eType = 0;
    static Map<String, String> cache_mapProperty = new HashMap();
    public int eType = 0;
    public Map<String, String> mapProperty = null;
    public String strValue = "";

    public ElementItem() {
    }

    public ElementItem(int eType2, String strValue2, Map<String, String> mapProperty2) {
        this.eType = eType2;
        this.strValue = strValue2;
        this.mapProperty = mapProperty2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eType, 0);
        if (this.strValue != null) {
            _os.write(this.strValue, 1);
        }
        if (this.mapProperty != null) {
            _os.write((Map) this.mapProperty, 2);
        }
    }

    static {
        cache_mapProperty.put("", "");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eType = _is.read(this.eType, 0, true);
        this.strValue = _is.readString(1, false);
        this.mapProperty = (Map) _is.read((Object) cache_mapProperty, 2, false);
    }
}
