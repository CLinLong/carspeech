package SmartService;

import java.io.Serializable;

public final class AIVoiceCompressType implements Serializable {
    public static final int _E_AIVOICECOMPRESS_AMR = 5;
    public static final int _E_AIVOICECOMPRESS_OPUS = 7;
    public static final int _E_AIVOICECOMPRESS_PCM = 1;
    public static final int _E_AIVOICECOMPRESS_SPEEX = 4;
    public static final int _E_AIVOICECOMPRESS_WAV = 2;
}
