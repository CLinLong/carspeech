package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIVoiceMeta extends JceStruct {
    public boolean bAllowDebugResultOutput = false;
    public boolean bGetbackRawAudio = false;
    public boolean bMultipleRes = false;
    public boolean bNeedIntermediateRes = true;
    public boolean bNeedNoiseReduction = false;
    public boolean bNeedPunc = true;
    public boolean bOpenItn = true;
    public boolean bOpenParticalPhnAlignment = false;
    public boolean bUseCloudVad = false;
    public float fMicDistance = 0.09f;
    public float fTheta = 220.0f;
    public int iAsrDomain = 10;
    public int iChannels = 1;
    public int iCompressType = 0;
    public int iDecodeGraphTimeOffset = 0;
    public int iEngineType = 0;
    public int iLangType = 0;
    public int iMaxResultNum = 20;
    public int iNoiseReducer = 0;
    public int iOffset = 0;
    public int iReqType = 0;
    public int iSampleRate = 0;
    public int iVadThreshold = 500;
    public String strSessionId = "";

    public AIVoiceMeta() {
    }

    public AIVoiceMeta(int iCompressType2, int iSampleRate2, int iEngineType2, int iOffset2, int iReqType2, String strSessionId2, int iLangType2, boolean bNeedIntermediateRes2, boolean bNeedPunc2, boolean bMultipleRes2, boolean bOpenItn2, int iAsrDomain2, boolean bNeedNoiseReduction2, int iNoiseReducer2, boolean bGetbackRawAudio2, boolean bUseCloudVad2, int iChannels2, boolean bAllowDebugResultOutput2, boolean bOpenParticalPhnAlignment2, int iMaxResultNum2, float fTheta2, int iDecodeGraphTimeOffset2, float fMicDistance2, int iVadThreshold2) {
        this.iCompressType = iCompressType2;
        this.iSampleRate = iSampleRate2;
        this.iEngineType = iEngineType2;
        this.iOffset = iOffset2;
        this.iReqType = iReqType2;
        this.strSessionId = strSessionId2;
        this.iLangType = iLangType2;
        this.bNeedIntermediateRes = bNeedIntermediateRes2;
        this.bNeedPunc = bNeedPunc2;
        this.bMultipleRes = bMultipleRes2;
        this.bOpenItn = bOpenItn2;
        this.iAsrDomain = iAsrDomain2;
        this.bNeedNoiseReduction = bNeedNoiseReduction2;
        this.iNoiseReducer = iNoiseReducer2;
        this.bGetbackRawAudio = bGetbackRawAudio2;
        this.bUseCloudVad = bUseCloudVad2;
        this.iChannels = iChannels2;
        this.bAllowDebugResultOutput = bAllowDebugResultOutput2;
        this.bOpenParticalPhnAlignment = bOpenParticalPhnAlignment2;
        this.iMaxResultNum = iMaxResultNum2;
        this.fTheta = fTheta2;
        this.iDecodeGraphTimeOffset = iDecodeGraphTimeOffset2;
        this.fMicDistance = fMicDistance2;
        this.iVadThreshold = iVadThreshold2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iCompressType, 0);
        _os.write(this.iSampleRate, 1);
        _os.write(this.iEngineType, 2);
        _os.write(this.iOffset, 3);
        _os.write(this.iReqType, 4);
        if (this.strSessionId != null) {
            _os.write(this.strSessionId, 5);
        }
        _os.write(this.iLangType, 6);
        _os.write(this.bNeedIntermediateRes, 7);
        _os.write(this.bNeedPunc, 8);
        _os.write(this.bMultipleRes, 9);
        _os.write(this.bOpenItn, 10);
        _os.write(this.iAsrDomain, 11);
        _os.write(this.bNeedNoiseReduction, 12);
        _os.write(this.iNoiseReducer, 13);
        _os.write(this.bGetbackRawAudio, 14);
        _os.write(this.bUseCloudVad, 15);
        _os.write(this.iChannels, 16);
        _os.write(this.bAllowDebugResultOutput, 17);
        _os.write(this.bOpenParticalPhnAlignment, 18);
        _os.write(this.iMaxResultNum, 19);
        _os.write(this.fTheta, 20);
        _os.write(this.iDecodeGraphTimeOffset, 21);
        _os.write(this.fMicDistance, 22);
        _os.write(this.iVadThreshold, 23);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iCompressType = _is.read(this.iCompressType, 0, true);
        this.iSampleRate = _is.read(this.iSampleRate, 1, true);
        this.iEngineType = _is.read(this.iEngineType, 2, false);
        this.iOffset = _is.read(this.iOffset, 3, false);
        this.iReqType = _is.read(this.iReqType, 4, false);
        this.strSessionId = _is.readString(5, false);
        this.iLangType = _is.read(this.iLangType, 6, false);
        this.bNeedIntermediateRes = _is.read(this.bNeedIntermediateRes, 7, false);
        this.bNeedPunc = _is.read(this.bNeedPunc, 8, false);
        this.bMultipleRes = _is.read(this.bMultipleRes, 9, false);
        this.bOpenItn = _is.read(this.bOpenItn, 10, false);
        this.iAsrDomain = _is.read(this.iAsrDomain, 11, false);
        this.bNeedNoiseReduction = _is.read(this.bNeedNoiseReduction, 12, false);
        this.iNoiseReducer = _is.read(this.iNoiseReducer, 13, false);
        this.bGetbackRawAudio = _is.read(this.bGetbackRawAudio, 14, false);
        this.bUseCloudVad = _is.read(this.bUseCloudVad, 15, false);
        this.iChannels = _is.read(this.iChannels, 16, false);
        this.bAllowDebugResultOutput = _is.read(this.bAllowDebugResultOutput, 17, false);
        this.bOpenParticalPhnAlignment = _is.read(this.bOpenParticalPhnAlignment, 18, false);
        this.iMaxResultNum = _is.read(this.iMaxResultNum, 19, false);
        this.fTheta = _is.read(this.fTheta, 20, false);
        this.iDecodeGraphTimeOffset = _is.read(this.iDecodeGraphTimeOffset, 21, false);
        this.fMicDistance = _is.read(this.fMicDistance, 22, false);
        this.iVadThreshold = _is.read(this.iVadThreshold, 23, false);
    }
}
