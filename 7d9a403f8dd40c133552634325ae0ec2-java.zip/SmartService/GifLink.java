package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class GifLink extends JceStruct {
    public String dateTime = "";
    public String href = "";
    public String title = "";

    public GifLink() {
    }

    public GifLink(String title2, String href2, String dateTime2) {
        this.title = title2;
        this.href = href2;
        this.dateTime = dateTime2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.title, 0);
        _os.write(this.href, 1);
        _os.write(this.dateTime, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.title = _is.readString(0, true);
        this.href = _is.readString(1, true);
        this.dateTime = _is.readString(2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        GifLink temp = (GifLink) a.parseObject(text, GifLink.class);
        this.title = temp.title;
        this.href = temp.href;
        this.dateTime = temp.dateTime;
    }
}
