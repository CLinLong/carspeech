package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class NewsRequest extends JceStruct {
    static int cache_clientType = 0;
    static NewsDimensionParam cache_sDimensionParam = new NewsDimensionParam();
    public int clientType = 1;
    public NewsDimensionParam sDimensionParam = null;
    public String sGuid = "";
    public String sSession = "";

    public NewsRequest() {
    }

    public NewsRequest(String sGuid2, int clientType2, NewsDimensionParam sDimensionParam2, String sSession2) {
        this.sGuid = sGuid2;
        this.clientType = clientType2;
        this.sDimensionParam = sDimensionParam2;
        this.sSession = sSession2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        _os.write(this.clientType, 1);
        _os.write((JceStruct) this.sDimensionParam, 2);
        if (this.sSession != null) {
            _os.write(this.sSession, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.clientType = _is.read(this.clientType, 1, true);
        this.sDimensionParam = (NewsDimensionParam) _is.read((JceStruct) cache_sDimensionParam, 2, true);
        this.sSession = _is.readString(3, false);
    }
}
