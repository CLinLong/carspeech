package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIAccountBaseInfo extends JceStruct {
    static int cache_eAcctType = 0;
    public int eAcctType = 0;
    public String strAccessToken = "";
    public String strAcctId = "";
    public String strAppId = "";

    public AIAccountBaseInfo() {
    }

    public AIAccountBaseInfo(int eAcctType2, String strAcctId2, String strAccessToken2, String strAppId2) {
        this.eAcctType = eAcctType2;
        this.strAcctId = strAcctId2;
        this.strAccessToken = strAccessToken2;
        this.strAppId = strAppId2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eAcctType, 0);
        if (this.strAcctId != null) {
            _os.write(this.strAcctId, 1);
        }
        if (this.strAccessToken != null) {
            _os.write(this.strAccessToken, 2);
        }
        if (this.strAppId != null) {
            _os.write(this.strAppId, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eAcctType = _is.read(this.eAcctType, 0, false);
        this.strAcctId = _is.readString(1, false);
        this.strAccessToken = _is.readString(2, false);
        this.strAppId = _is.readString(3, false);
    }
}
