package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class GetGeneralMsgResponse extends JceStruct {
    static int cache_eMsgType = 0;
    static ArrayList<GeneralMsgItem> cache_msgVec = new ArrayList<>();
    public int eMsgType = 0;
    public String errMsg = "";
    public ArrayList<GeneralMsgItem> msgVec = null;
    public int retCode = 0;

    public GetGeneralMsgResponse() {
    }

    public GetGeneralMsgResponse(int retCode2, String errMsg2, int eMsgType2, ArrayList<GeneralMsgItem> msgVec2) {
        this.retCode = retCode2;
        this.errMsg = errMsg2;
        this.eMsgType = eMsgType2;
        this.msgVec = msgVec2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.retCode, 0);
        if (this.errMsg != null) {
            _os.write(this.errMsg, 1);
        }
        _os.write(this.eMsgType, 2);
        if (this.msgVec != null) {
            _os.write((Collection) this.msgVec, 3);
        }
    }

    static {
        cache_msgVec.add(new GeneralMsgItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.retCode = _is.read(this.retCode, 0, false);
        this.errMsg = _is.readString(1, false);
        this.eMsgType = _is.read(this.eMsgType, 2, false);
        this.msgVec = (ArrayList) _is.read((Object) cache_msgVec, 3, false);
    }
}
