package SmartService;

import SmartAssistant.Semantic;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AISemanticMetaV2 extends JceStruct {
    static Semantic cache_sSemantic = new Semantic();
    public int iSemanticCmd = 0;
    public Semantic sSemantic = null;

    public AISemanticMetaV2() {
    }

    public AISemanticMetaV2(Semantic sSemantic2, int iSemanticCmd2) {
        this.sSemantic = sSemantic2;
        this.iSemanticCmd = iSemanticCmd2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sSemantic != null) {
            _os.write((JceStruct) this.sSemantic, 0);
        }
        _os.write(this.iSemanticCmd, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sSemantic = (Semantic) _is.read((JceStruct) cache_sSemantic, 0, false);
        this.iSemanticCmd = _is.read(this.iSemanticCmd, 1, false);
    }
}
