package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SportsStatisticsResponse extends JceStruct {
    static ArrayList<String> cache_sportsStatisticsObjs = new ArrayList<>();
    public String noSupport = "";
    public String replyWords = "";
    public String sGuid = "";
    public String speakerReplyWords = "";
    public ArrayList<String> sportsStatisticsObjs = null;

    public SportsStatisticsResponse() {
    }

    public SportsStatisticsResponse(String sGuid2, ArrayList<String> sportsStatisticsObjs2, String noSupport2, String replyWords2, String speakerReplyWords2) {
        this.sGuid = sGuid2;
        this.sportsStatisticsObjs = sportsStatisticsObjs2;
        this.noSupport = noSupport2;
        this.replyWords = replyWords2;
        this.speakerReplyWords = speakerReplyWords2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        if (this.sportsStatisticsObjs != null) {
            _os.write((Collection) this.sportsStatisticsObjs, 1);
        }
        if (this.noSupport != null) {
            _os.write(this.noSupport, 2);
        }
        if (this.replyWords != null) {
            _os.write(this.replyWords, 3);
        }
        if (this.speakerReplyWords != null) {
            _os.write(this.speakerReplyWords, 4);
        }
    }

    static {
        cache_sportsStatisticsObjs.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.sportsStatisticsObjs = (ArrayList) _is.read((Object) cache_sportsStatisticsObjs, 1, false);
        this.noSupport = _is.readString(2, false);
        this.replyWords = _is.readString(3, false);
        this.speakerReplyWords = _is.readString(4, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SportsStatisticsResponse temp = (SportsStatisticsResponse) a.parseObject(text, SportsStatisticsResponse.class);
        this.sGuid = temp.sGuid;
        this.sportsStatisticsObjs = temp.sportsStatisticsObjs;
        this.noSupport = temp.noSupport;
        this.replyWords = temp.replyWords;
        this.speakerReplyWords = temp.speakerReplyWords;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
