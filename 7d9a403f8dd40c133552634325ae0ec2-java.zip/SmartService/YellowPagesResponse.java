package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class YellowPagesResponse extends JceStruct {
    static ArrayList<YellowPagesItem> cache_data = new ArrayList<>();
    static int cache_resStatus = 0;
    public ArrayList<YellowPagesItem> data = null;
    public int resStatus = 0;
    public String strSpeakText = "";
    public String strSpeakTipsText = "";
    public String strTipsText = "";
    public String strWxText = "";

    public YellowPagesResponse() {
    }

    public YellowPagesResponse(int resStatus2, ArrayList<YellowPagesItem> data2, String strTipsText2, String strSpeakTipsText2, String strSpeakText2, String strWxText2) {
        this.resStatus = resStatus2;
        this.data = data2;
        this.strTipsText = strTipsText2;
        this.strSpeakTipsText = strSpeakTipsText2;
        this.strSpeakText = strSpeakText2;
        this.strWxText = strWxText2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.resStatus, 0);
        if (this.data != null) {
            _os.write((Collection) this.data, 1);
        }
        if (this.strTipsText != null) {
            _os.write(this.strTipsText, 2);
        }
        if (this.strSpeakTipsText != null) {
            _os.write(this.strSpeakTipsText, 3);
        }
        if (this.strSpeakText != null) {
            _os.write(this.strSpeakText, 4);
        }
        if (this.strWxText != null) {
            _os.write(this.strWxText, 5);
        }
    }

    static {
        cache_data.add(new YellowPagesItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.resStatus = _is.read(this.resStatus, 0, true);
        this.data = (ArrayList) _is.read((Object) cache_data, 1, false);
        this.strTipsText = _is.readString(2, false);
        this.strSpeakTipsText = _is.readString(3, false);
        this.strSpeakText = _is.readString(4, false);
        this.strWxText = _is.readString(5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        YellowPagesResponse temp = (YellowPagesResponse) a.parseObject(text, YellowPagesResponse.class);
        this.resStatus = temp.resStatus;
        this.data = temp.data;
        this.strTipsText = temp.strTipsText;
        this.strSpeakTipsText = temp.strSpeakTipsText;
        this.strSpeakText = temp.strSpeakText;
        this.strWxText = temp.strWxText;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
