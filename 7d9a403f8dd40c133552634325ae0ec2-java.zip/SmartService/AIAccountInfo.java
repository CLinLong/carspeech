package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIAccountInfo extends JceStruct {
    static IDCenterIdStruct cache_sIdSt = new IDCenterIdStruct();
    static IDCenterTokenStruct cache_sTokenSt = new IDCenterTokenStruct();
    public int iTokenType = 0;
    public IDCenterIdStruct sIdSt = null;
    public IDCenterTokenStruct sTokenSt = null;
    public String strPhoneNumber = "";
    public String strPushInfo = "";
    public String strQBId = "";

    public AIAccountInfo() {
    }

    public AIAccountInfo(String strQBId2, IDCenterIdStruct sIdSt2, int iTokenType2, IDCenterTokenStruct sTokenSt2, String strPhoneNumber2, String strPushInfo2) {
        this.strQBId = strQBId2;
        this.sIdSt = sIdSt2;
        this.iTokenType = iTokenType2;
        this.sTokenSt = sTokenSt2;
        this.strPhoneNumber = strPhoneNumber2;
        this.strPushInfo = strPushInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strQBId != null) {
            _os.write(this.strQBId, 0);
        }
        if (this.sIdSt != null) {
            _os.write((JceStruct) this.sIdSt, 1);
        }
        _os.write(this.iTokenType, 2);
        if (this.sTokenSt != null) {
            _os.write((JceStruct) this.sTokenSt, 3);
        }
        if (this.strPhoneNumber != null) {
            _os.write(this.strPhoneNumber, 4);
        }
        if (this.strPushInfo != null) {
            _os.write(this.strPushInfo, 5);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strQBId = _is.readString(0, false);
        this.sIdSt = (IDCenterIdStruct) _is.read((JceStruct) cache_sIdSt, 1, false);
        this.iTokenType = _is.read(this.iTokenType, 2, false);
        this.sTokenSt = (IDCenterTokenStruct) _is.read((JceStruct) cache_sTokenSt, 3, false);
        this.strPhoneNumber = _is.readString(4, false);
        this.strPushInfo = _is.readString(5, false);
    }
}
