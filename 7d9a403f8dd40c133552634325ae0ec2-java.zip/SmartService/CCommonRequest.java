package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class CCommonRequest extends JceStruct {
    public String strRequest = "";

    public CCommonRequest() {
    }

    public CCommonRequest(String strRequest2) {
        this.strRequest = strRequest2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strRequest, 0);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strRequest = _is.readString(0, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        this.strRequest = ((CCommonRequest) a.parseObject(text, CCommonRequest.class)).strRequest;
    }
}
