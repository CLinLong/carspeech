package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class QBGameLiveItem extends JceStruct {
    public int iIsValid = 0;
    public int iType = 0;
    public long lStartTime = 0;
    public long lViewCount = 0;
    public String strCoverUrl = "";
    public String strHeadUrl = "";
    public String strHost = "";
    public String strLiveDesc = "";
    public String strLiveId = "";
    public String strLiveUrl = "";
    public String strTag = "";
    public String strTitle = "";

    public QBGameLiveItem() {
    }

    public QBGameLiveItem(int iIsValid2, int iType2, long lStartTime2, long lViewCount2, String strHost2, String strCoverUrl2, String strHeadUrl2, String strLiveUrl2, String strTag2, String strLiveDesc2, String strLiveId2, String strTitle2) {
        this.iIsValid = iIsValid2;
        this.iType = iType2;
        this.lStartTime = lStartTime2;
        this.lViewCount = lViewCount2;
        this.strHost = strHost2;
        this.strCoverUrl = strCoverUrl2;
        this.strHeadUrl = strHeadUrl2;
        this.strLiveUrl = strLiveUrl2;
        this.strTag = strTag2;
        this.strLiveDesc = strLiveDesc2;
        this.strLiveId = strLiveId2;
        this.strTitle = strTitle2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iIsValid, 0);
        _os.write(this.iType, 1);
        _os.write(this.lStartTime, 2);
        _os.write(this.lViewCount, 3);
        _os.write(this.strHost, 4);
        if (this.strCoverUrl != null) {
            _os.write(this.strCoverUrl, 5);
        }
        if (this.strHeadUrl != null) {
            _os.write(this.strHeadUrl, 6);
        }
        if (this.strLiveUrl != null) {
            _os.write(this.strLiveUrl, 7);
        }
        if (this.strTag != null) {
            _os.write(this.strTag, 8);
        }
        if (this.strLiveDesc != null) {
            _os.write(this.strLiveDesc, 9);
        }
        if (this.strLiveId != null) {
            _os.write(this.strLiveId, 10);
        }
        if (this.strTitle != null) {
            _os.write(this.strTitle, 11);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iIsValid = _is.read(this.iIsValid, 0, true);
        this.iType = _is.read(this.iType, 1, true);
        this.lStartTime = _is.read(this.lStartTime, 2, true);
        this.lViewCount = _is.read(this.lViewCount, 3, true);
        this.strHost = _is.readString(4, true);
        this.strCoverUrl = _is.readString(5, false);
        this.strHeadUrl = _is.readString(6, false);
        this.strLiveUrl = _is.readString(7, false);
        this.strTag = _is.readString(8, false);
        this.strLiveDesc = _is.readString(9, false);
        this.strLiveId = _is.readString(10, false);
        this.strTitle = _is.readString(11, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QBGameLiveItem temp = (QBGameLiveItem) a.parseObject(text, QBGameLiveItem.class);
        this.iIsValid = temp.iIsValid;
        this.iType = temp.iType;
        this.lStartTime = temp.lStartTime;
        this.lViewCount = temp.lViewCount;
        this.strHost = temp.strHost;
        this.strCoverUrl = temp.strCoverUrl;
        this.strHeadUrl = temp.strHeadUrl;
        this.strLiveUrl = temp.strLiveUrl;
        this.strTag = temp.strTag;
        this.strLiveDesc = temp.strLiveDesc;
        this.strLiveId = temp.strLiveId;
        this.strTitle = temp.strTitle;
    }
}
