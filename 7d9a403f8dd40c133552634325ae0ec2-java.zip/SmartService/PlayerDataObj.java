package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class PlayerDataObj extends JceStruct {
    public String gTeamCnName = "";
    public String playerName = "";
    public String teamCnName = "";

    public PlayerDataObj() {
    }

    public PlayerDataObj(String playerName2, String gTeamCnName2, String teamCnName2) {
        this.playerName = playerName2;
        this.gTeamCnName = gTeamCnName2;
        this.teamCnName = teamCnName2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.playerName, 0);
        _os.write(this.gTeamCnName, 1);
        _os.write(this.teamCnName, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.playerName = _is.readString(0, true);
        this.gTeamCnName = _is.readString(1, true);
        this.teamCnName = _is.readString(2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        PlayerDataObj temp = (PlayerDataObj) a.parseObject(text, PlayerDataObj.class);
        this.playerName = temp.playerName;
        this.gTeamCnName = temp.gTeamCnName;
        this.teamCnName = temp.teamCnName;
    }
}
