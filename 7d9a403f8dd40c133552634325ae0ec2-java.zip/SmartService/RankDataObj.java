package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class RankDataObj extends JceStruct {
    public String belongs = "";
    public String logo = "";
    public String name = "";
    public String requestField = "";
    public String requestFieldValue = "";

    public RankDataObj() {
    }

    public RankDataObj(String name2, String belongs2, String logo2, String requestField2, String requestFieldValue2) {
        this.name = name2;
        this.belongs = belongs2;
        this.logo = logo2;
        this.requestField = requestField2;
        this.requestFieldValue = requestFieldValue2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.name, 0);
        if (this.belongs != null) {
            _os.write(this.belongs, 1);
        }
        _os.write(this.logo, 2);
        _os.write(this.requestField, 3);
        _os.write(this.requestFieldValue, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.name = _is.readString(0, true);
        this.belongs = _is.readString(1, false);
        this.logo = _is.readString(2, true);
        this.requestField = _is.readString(3, true);
        this.requestFieldValue = _is.readString(4, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        RankDataObj temp = (RankDataObj) a.parseObject(text, RankDataObj.class);
        this.name = temp.name;
        this.belongs = temp.belongs;
        this.logo = temp.logo;
        this.requestField = temp.requestField;
        this.requestFieldValue = temp.requestFieldValue;
    }
}
