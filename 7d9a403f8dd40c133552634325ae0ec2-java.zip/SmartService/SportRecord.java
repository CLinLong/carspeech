package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SportRecord extends JceStruct {
    static int cache_sportsType = 0;
    static ArrayList<TeamSeasonStat> cache_teamStatVec = new ArrayList<>();
    public String competition = "";
    public String group = "";
    public int sportsType = 0;
    public ArrayList<TeamSeasonStat> teamStatVec = null;

    public SportRecord() {
    }

    public SportRecord(String competition2, ArrayList<TeamSeasonStat> teamStatVec2, String group2, int sportsType2) {
        this.competition = competition2;
        this.teamStatVec = teamStatVec2;
        this.group = group2;
        this.sportsType = sportsType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.competition, 0);
        _os.write((Collection) this.teamStatVec, 1);
        if (this.group != null) {
            _os.write(this.group, 2);
        }
        _os.write(this.sportsType, 3);
    }

    static {
        cache_teamStatVec.add(new TeamSeasonStat());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.competition = _is.readString(0, true);
        this.teamStatVec = (ArrayList) _is.read((Object) cache_teamStatVec, 1, true);
        this.group = _is.readString(2, false);
        this.sportsType = _is.read(this.sportsType, 3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SportRecord temp = (SportRecord) a.parseObject(text, SportRecord.class);
        this.competition = temp.competition;
        this.teamStatVec = temp.teamStatVec;
        this.group = temp.group;
        this.sportsType = temp.sportsType;
    }
}
