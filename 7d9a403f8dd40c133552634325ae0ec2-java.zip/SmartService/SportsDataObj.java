package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SportsDataObj extends JceStruct {
    static Team cache_awayTeam = new Team();
    static LinkObj cache_detailObj = new LinkObj();
    static Team cache_homeTeam = new Team();
    static ArrayList<LinkObj> cache_livesobjs = new ArrayList<>();
    static LinkObj cache_notityObj = new LinkObj();
    static int cache_sportsType = 0;
    public Team awayTeam = null;
    public String cancelNotify = "";
    public String channel = "";
    public String competition = "";
    public LinkObj detailObj = null;
    public String groupName = "";
    public Team homeTeam = null;
    public ArrayList<LinkObj> livesobjs = null;
    public String matchId = "";
    public LinkObj notityObj = null;
    public String period = "";
    public String roundNumber = "";
    public String roundType = "";
    public String sportsStartTime = "";
    public int sportsType = 0;

    public SportsDataObj() {
    }

    public SportsDataObj(String sportsStartTime2, Team homeTeam2, Team awayTeam2, String channel2, int sportsType2, ArrayList<LinkObj> livesobjs2, String period2, String competition2, String matchId2, LinkObj notityObj2, String groupName2, String roundNumber2, String roundType2, LinkObj detailObj2, String cancelNotify2) {
        this.sportsStartTime = sportsStartTime2;
        this.homeTeam = homeTeam2;
        this.awayTeam = awayTeam2;
        this.channel = channel2;
        this.sportsType = sportsType2;
        this.livesobjs = livesobjs2;
        this.period = period2;
        this.competition = competition2;
        this.matchId = matchId2;
        this.notityObj = notityObj2;
        this.groupName = groupName2;
        this.roundNumber = roundNumber2;
        this.roundType = roundType2;
        this.detailObj = detailObj2;
        this.cancelNotify = cancelNotify2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sportsStartTime, 0);
        _os.write((JceStruct) this.homeTeam, 1);
        _os.write((JceStruct) this.awayTeam, 2);
        if (this.channel != null) {
            _os.write(this.channel, 3);
        }
        _os.write(this.sportsType, 4);
        if (this.livesobjs != null) {
            _os.write((Collection) this.livesobjs, 5);
        }
        _os.write(this.period, 6);
        if (this.competition != null) {
            _os.write(this.competition, 7);
        }
        if (this.matchId != null) {
            _os.write(this.matchId, 8);
        }
        if (this.notityObj != null) {
            _os.write((JceStruct) this.notityObj, 9);
        }
        if (this.groupName != null) {
            _os.write(this.groupName, 10);
        }
        if (this.roundNumber != null) {
            _os.write(this.roundNumber, 11);
        }
        if (this.roundType != null) {
            _os.write(this.roundType, 12);
        }
        if (this.detailObj != null) {
            _os.write((JceStruct) this.detailObj, 13);
        }
        if (this.cancelNotify != null) {
            _os.write(this.cancelNotify, 14);
        }
    }

    static {
        cache_livesobjs.add(new LinkObj());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sportsStartTime = _is.readString(0, true);
        this.homeTeam = (Team) _is.read((JceStruct) cache_homeTeam, 1, true);
        this.awayTeam = (Team) _is.read((JceStruct) cache_awayTeam, 2, true);
        this.channel = _is.readString(3, false);
        this.sportsType = _is.read(this.sportsType, 4, true);
        this.livesobjs = (ArrayList) _is.read((Object) cache_livesobjs, 5, false);
        this.period = _is.readString(6, true);
        this.competition = _is.readString(7, false);
        this.matchId = _is.readString(8, false);
        this.notityObj = (LinkObj) _is.read((JceStruct) cache_notityObj, 9, false);
        this.groupName = _is.readString(10, false);
        this.roundNumber = _is.readString(11, false);
        this.roundType = _is.readString(12, false);
        this.detailObj = (LinkObj) _is.read((JceStruct) cache_detailObj, 13, false);
        this.cancelNotify = _is.readString(14, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SportsDataObj temp = (SportsDataObj) a.parseObject(text, SportsDataObj.class);
        this.sportsStartTime = temp.sportsStartTime;
        this.homeTeam = temp.homeTeam;
        this.awayTeam = temp.awayTeam;
        this.channel = temp.channel;
        this.sportsType = temp.sportsType;
        this.livesobjs = temp.livesobjs;
        this.period = temp.period;
        this.competition = temp.competition;
        this.matchId = temp.matchId;
        this.notityObj = temp.notityObj;
        this.groupName = temp.groupName;
        this.roundNumber = temp.roundNumber;
        this.roundType = temp.roundType;
        this.detailObj = temp.detailObj;
        this.cancelNotify = temp.cancelNotify;
    }
}
