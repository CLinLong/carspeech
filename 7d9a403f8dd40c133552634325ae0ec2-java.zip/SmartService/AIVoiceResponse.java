package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AIVoiceResponse extends JceStruct {
    static int cache_iCompressType = 0;
    static ErrCodeStatus cache_sRet = new ErrCodeStatus();
    static ArrayList<RecoTextInfo> cache_vRecoTextInfos = new ArrayList<>();
    static ArrayList<CostTimeInfo> cache_vecCostTime = new ArrayList<>();
    static ArrayList<String> cache_vecResult = new ArrayList<>();
    static byte[] cache_vecVoiceData = new byte[1];
    public boolean bFinalResult = true;
    public double dAcousticWeight = 0.0d;
    public double dConfidence = 0.0d;
    public double dGraphWeight = 0.0d;
    public double dParticalDecodedTime = 0.0d;
    public double dSilenceTime = 0.0d;
    public int iCompressType = 0;
    public int iResultSeq = 0;
    public String sModelName = "";
    public String sPreItnResult = "";
    public String sPreRescoreResult = "";
    public ErrCodeStatus sRet = null;
    public String sSegmentText = "";
    public String sVersionInfo = "";
    public String strSessionId = "";
    public ArrayList<RecoTextInfo> vRecoTextInfos = null;
    public ArrayList<CostTimeInfo> vecCostTime = null;
    public ArrayList<String> vecResult = null;
    public byte[] vecVoiceData = null;

    public AIVoiceResponse() {
    }

    public AIVoiceResponse(ArrayList<String> vecResult2, String strSessionId2, int iResultSeq2, boolean bFinalResult2, double dConfidence2, double dSilenceTime2, String sModelName2, String sVersionInfo2, ArrayList<CostTimeInfo> vecCostTime2, int iCompressType2, byte[] vecVoiceData2, double dParticalDecodedTime2, double dGraphWeight2, double dAcousticWeight2, String sPreItnResult2, String sPreRescoreResult2, ArrayList<RecoTextInfo> vRecoTextInfos2, String sSegmentText2, ErrCodeStatus sRet2) {
        this.vecResult = vecResult2;
        this.strSessionId = strSessionId2;
        this.iResultSeq = iResultSeq2;
        this.bFinalResult = bFinalResult2;
        this.dConfidence = dConfidence2;
        this.dSilenceTime = dSilenceTime2;
        this.sModelName = sModelName2;
        this.sVersionInfo = sVersionInfo2;
        this.vecCostTime = vecCostTime2;
        this.iCompressType = iCompressType2;
        this.vecVoiceData = vecVoiceData2;
        this.dParticalDecodedTime = dParticalDecodedTime2;
        this.dGraphWeight = dGraphWeight2;
        this.dAcousticWeight = dAcousticWeight2;
        this.sPreItnResult = sPreItnResult2;
        this.sPreRescoreResult = sPreRescoreResult2;
        this.vRecoTextInfos = vRecoTextInfos2;
        this.sSegmentText = sSegmentText2;
        this.sRet = sRet2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vecResult, 0);
        if (this.strSessionId != null) {
            _os.write(this.strSessionId, 1);
        }
        _os.write(this.iResultSeq, 2);
        _os.write(this.bFinalResult, 3);
        _os.write(this.dConfidence, 4);
        _os.write(this.dSilenceTime, 5);
        if (this.sModelName != null) {
            _os.write(this.sModelName, 6);
        }
        if (this.sVersionInfo != null) {
            _os.write(this.sVersionInfo, 7);
        }
        if (this.vecCostTime != null) {
            _os.write((Collection) this.vecCostTime, 8);
        }
        _os.write(this.iCompressType, 9);
        if (this.vecVoiceData != null) {
            _os.write(this.vecVoiceData, 10);
        }
        _os.write(this.dParticalDecodedTime, 11);
        _os.write(this.dGraphWeight, 12);
        _os.write(this.dAcousticWeight, 13);
        if (this.sPreItnResult != null) {
            _os.write(this.sPreItnResult, 14);
        }
        if (this.sPreRescoreResult != null) {
            _os.write(this.sPreRescoreResult, 15);
        }
        if (this.vRecoTextInfos != null) {
            _os.write((Collection) this.vRecoTextInfos, 16);
        }
        if (this.sSegmentText != null) {
            _os.write(this.sSegmentText, 17);
        }
        if (this.sRet != null) {
            _os.write((JceStruct) this.sRet, 18);
        }
    }

    static {
        cache_vecResult.add("");
        cache_vecCostTime.add(new CostTimeInfo());
        cache_vecVoiceData[0] = 0;
        cache_vRecoTextInfos.add(new RecoTextInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecResult = (ArrayList) _is.read((Object) cache_vecResult, 0, true);
        this.strSessionId = _is.readString(1, false);
        this.iResultSeq = _is.read(this.iResultSeq, 2, false);
        this.bFinalResult = _is.read(this.bFinalResult, 3, false);
        this.dConfidence = _is.read(this.dConfidence, 4, false);
        this.dSilenceTime = _is.read(this.dSilenceTime, 5, false);
        this.sModelName = _is.readString(6, false);
        this.sVersionInfo = _is.readString(7, false);
        this.vecCostTime = (ArrayList) _is.read((Object) cache_vecCostTime, 8, false);
        this.iCompressType = _is.read(this.iCompressType, 9, false);
        this.vecVoiceData = _is.read(cache_vecVoiceData, 10, false);
        this.dParticalDecodedTime = _is.read(this.dParticalDecodedTime, 11, false);
        this.dGraphWeight = _is.read(this.dGraphWeight, 12, false);
        this.dAcousticWeight = _is.read(this.dAcousticWeight, 13, false);
        this.sPreItnResult = _is.readString(14, false);
        this.sPreRescoreResult = _is.readString(15, false);
        this.vRecoTextInfos = (ArrayList) _is.read((Object) cache_vRecoTextInfos, 16, false);
        this.sSegmentText = _is.readString(17, false);
        this.sRet = (ErrCodeStatus) _is.read((JceStruct) cache_sRet, 18, false);
    }
}
