package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.HashMap;
import java.util.Map;

public final class AIEventRequest extends JceStruct {
    static Map<Integer, String> cache_mapEventData = new HashMap();
    static WXIDVerifty cache_sAccountInfo = new WXIDVerifty();
    public int eRequestType = 0;
    public Map<Integer, String> mapEventData = null;
    public WXIDVerifty sAccountInfo = null;
    public String strGUID = "";
    public String strQUA = "";

    public AIEventRequest() {
    }

    public AIEventRequest(String strGUID2, String strQUA2, WXIDVerifty sAccountInfo2, int eRequestType2, Map<Integer, String> mapEventData2) {
        this.strGUID = strGUID2;
        this.strQUA = strQUA2;
        this.sAccountInfo = sAccountInfo2;
        this.eRequestType = eRequestType2;
        this.mapEventData = mapEventData2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strGUID, 0);
        _os.write(this.strQUA, 1);
        if (this.sAccountInfo != null) {
            _os.write((JceStruct) this.sAccountInfo, 2);
        }
        _os.write(this.eRequestType, 3);
        if (this.mapEventData != null) {
            _os.write((Map) this.mapEventData, 4);
        }
    }

    static {
        cache_mapEventData.put(0, "");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strGUID = _is.readString(0, true);
        this.strQUA = _is.readString(1, true);
        this.sAccountInfo = (WXIDVerifty) _is.read((JceStruct) cache_sAccountInfo, 2, false);
        this.eRequestType = _is.read(this.eRequestType, 3, true);
        this.mapEventData = (Map) _is.read((Object) cache_mapEventData, 4, false);
    }
}
