package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class YellowPagesItem extends JceStruct {
    public String department = "";
    public String phone = "";
    public String title = "";

    public YellowPagesItem() {
    }

    public YellowPagesItem(String title2, String department2, String phone2) {
        this.title = title2;
        this.department = department2;
        this.phone = phone2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.title != null) {
            _os.write(this.title, 0);
        }
        if (this.department != null) {
            _os.write(this.department, 1);
        }
        if (this.phone != null) {
            _os.write(this.phone, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.title = _is.readString(0, false);
        this.department = _is.readString(1, false);
        this.phone = _is.readString(2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        YellowPagesItem temp = (YellowPagesItem) a.parseObject(text, YellowPagesItem.class);
        this.title = temp.title;
        this.department = temp.department;
        this.phone = temp.phone;
    }
}
