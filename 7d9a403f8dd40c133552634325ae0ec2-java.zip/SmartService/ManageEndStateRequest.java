package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ManageEndStateRequest extends JceStruct {
    static int cache_eOperType = 0;
    static AIAccountBaseInfo cache_sAccountBaseInfo = new AIAccountBaseInfo();
    static AIDeviceBaseInfo cache_sDeviceBaseInfo = new AIDeviceBaseInfo();
    public int eOperType = 0;
    public AIAccountBaseInfo sAccountBaseInfo = null;
    public AIDeviceBaseInfo sDeviceBaseInfo = null;
    public String strDstEndPushInfo = "";

    public ManageEndStateRequest() {
    }

    public ManageEndStateRequest(AIAccountBaseInfo sAccountBaseInfo2, AIDeviceBaseInfo sDeviceBaseInfo2, int eOperType2, String strDstEndPushInfo2) {
        this.sAccountBaseInfo = sAccountBaseInfo2;
        this.sDeviceBaseInfo = sDeviceBaseInfo2;
        this.eOperType = eOperType2;
        this.strDstEndPushInfo = strDstEndPushInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sAccountBaseInfo != null) {
            _os.write((JceStruct) this.sAccountBaseInfo, 0);
        }
        if (this.sDeviceBaseInfo != null) {
            _os.write((JceStruct) this.sDeviceBaseInfo, 1);
        }
        _os.write(this.eOperType, 2);
        if (this.strDstEndPushInfo != null) {
            _os.write(this.strDstEndPushInfo, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAccountBaseInfo = (AIAccountBaseInfo) _is.read((JceStruct) cache_sAccountBaseInfo, 0, false);
        this.sDeviceBaseInfo = (AIDeviceBaseInfo) _is.read((JceStruct) cache_sDeviceBaseInfo, 1, false);
        this.eOperType = _is.read(this.eOperType, 2, false);
        this.strDstEndPushInfo = _is.readString(3, false);
    }
}
