package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class GetGeneralMsgRequest extends JceStruct {
    static int cache_eMsgType = 0;
    static AIAccountBaseInfo cache_sAccountBaseInfo = new AIAccountBaseInfo();
    static AIDeviceBaseInfo cache_sDeviceBaseInfo = new AIDeviceBaseInfo();
    public int eMsgType = 0;
    public AIAccountBaseInfo sAccountBaseInfo = null;
    public AIDeviceBaseInfo sDeviceBaseInfo = null;
    public String strJsonBlobInfo = "";

    public GetGeneralMsgRequest() {
    }

    public GetGeneralMsgRequest(AIAccountBaseInfo sAccountBaseInfo2, AIDeviceBaseInfo sDeviceBaseInfo2, int eMsgType2, String strJsonBlobInfo2) {
        this.sAccountBaseInfo = sAccountBaseInfo2;
        this.sDeviceBaseInfo = sDeviceBaseInfo2;
        this.eMsgType = eMsgType2;
        this.strJsonBlobInfo = strJsonBlobInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sAccountBaseInfo != null) {
            _os.write((JceStruct) this.sAccountBaseInfo, 0);
        }
        if (this.sDeviceBaseInfo != null) {
            _os.write((JceStruct) this.sDeviceBaseInfo, 1);
        }
        _os.write(this.eMsgType, 2);
        if (this.strJsonBlobInfo != null) {
            _os.write(this.strJsonBlobInfo, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAccountBaseInfo = (AIAccountBaseInfo) _is.read((JceStruct) cache_sAccountBaseInfo, 0, false);
        this.sDeviceBaseInfo = (AIDeviceBaseInfo) _is.read((JceStruct) cache_sDeviceBaseInfo, 1, false);
        this.eMsgType = _is.read(this.eMsgType, 2, false);
        this.strJsonBlobInfo = _is.readString(3, false);
    }
}
