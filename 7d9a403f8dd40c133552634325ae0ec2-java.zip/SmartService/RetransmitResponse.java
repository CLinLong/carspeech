package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class RetransmitResponse extends JceStruct {
    static byte[] cache_vAnonymousResponseBuffer = new byte[1];
    public byte[] vAnonymousResponseBuffer = null;

    public RetransmitResponse() {
    }

    public RetransmitResponse(byte[] vAnonymousResponseBuffer2) {
        this.vAnonymousResponseBuffer = vAnonymousResponseBuffer2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.vAnonymousResponseBuffer, 0);
    }

    static {
        cache_vAnonymousResponseBuffer[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vAnonymousResponseBuffer = _is.read(cache_vAnonymousResponseBuffer, 0, true);
    }
}
