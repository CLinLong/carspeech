package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class WXIDVerifty extends JceStruct {
    public String strAToken = "";
    public String strOpenID = "";
    public String strUniID = "";

    public WXIDVerifty() {
    }

    public WXIDVerifty(String strUniID2, String strAToken2, String strOpenID2) {
        this.strUniID = strUniID2;
        this.strAToken = strAToken2;
        this.strOpenID = strOpenID2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strUniID, 0);
        _os.write(this.strAToken, 1);
        if (this.strOpenID != null) {
            _os.write(this.strOpenID, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strUniID = _is.readString(0, true);
        this.strAToken = _is.readString(1, true);
        this.strOpenID = _is.readString(2, false);
    }
}
