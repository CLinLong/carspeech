package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class BuyResponse extends JceStruct {
    public String errMsg = "";
    public int retCode = 0;
    public String strJsonBlobInfo = "";

    public BuyResponse() {
    }

    public BuyResponse(int retCode2, String errMsg2, String strJsonBlobInfo2) {
        this.retCode = retCode2;
        this.errMsg = errMsg2;
        this.strJsonBlobInfo = strJsonBlobInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.retCode, 0);
        if (this.errMsg != null) {
            _os.write(this.errMsg, 1);
        }
        if (this.strJsonBlobInfo != null) {
            _os.write(this.strJsonBlobInfo, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.retCode = _is.read(this.retCode, 0, false);
        this.errMsg = _is.readString(1, false);
        this.strJsonBlobInfo = _is.readString(2, false);
    }
}
