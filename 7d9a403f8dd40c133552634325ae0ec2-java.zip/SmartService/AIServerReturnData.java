package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public final class AIServerReturnData extends JceStruct {
    static Map<Integer, String> cache_mapText = new HashMap();
    static CommonRspData cache_sCommRspData = new CommonRspData();
    static ArrayList<AIResponseDataItem> cache_vecResponseData = new ArrayList<>();
    public Map<Integer, String> mapText = null;
    public CommonRspData sCommRspData = null;
    public ArrayList<AIResponseDataItem> vecResponseData = null;

    public AIServerReturnData() {
    }

    public AIServerReturnData(CommonRspData sCommRspData2, ArrayList<AIResponseDataItem> vecResponseData2, Map<Integer, String> mapText2) {
        this.sCommRspData = sCommRspData2;
        this.vecResponseData = vecResponseData2;
        this.mapText = mapText2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sCommRspData != null) {
            _os.write((JceStruct) this.sCommRspData, 0);
        }
        if (this.vecResponseData != null) {
            _os.write((Collection) this.vecResponseData, 1);
        }
        if (this.mapText != null) {
            _os.write((Map) this.mapText, 2);
        }
    }

    static {
        cache_vecResponseData.add(new AIResponseDataItem());
        cache_mapText.put(0, "");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sCommRspData = (CommonRspData) _is.read((JceStruct) cache_sCommRspData, 0, false);
        this.vecResponseData = (ArrayList) _is.read((Object) cache_vecResponseData, 1, false);
        this.mapText = (Map) _is.read((Object) cache_mapText, 2, false);
    }
}
