package SmartService;

import java.io.Serializable;

public final class AIRspContentType implements Serializable {
    public static final int _E_AIRSPCONTENTTYPE_DATA_ONLY = 0;
    public static final int _E_AIRSPCONTENTTYPE_DATA_TEXT = 2;
    public static final int _E_AIRSPCONTENTTYPE_SEMANTIC_ONLY = 3;
    public static final int _E_AIRSPCONTENTTYPE_TEXT_ONLY = 1;
}
