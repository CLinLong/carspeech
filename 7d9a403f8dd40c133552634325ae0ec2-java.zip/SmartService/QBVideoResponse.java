package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QBVideoResponse extends JceStruct {
    static ArrayList<ShortVideoDataItem> cache_vecShortVideoData = new ArrayList<>();
    static ArrayList<VideoDataItem> cache_vecVideoData = new ArrayList<>();
    public int iVideoClass = 0;
    public String sGuid = "";
    public String sMoreUrl = "";
    public ArrayList<ShortVideoDataItem> vecShortVideoData = null;
    public ArrayList<VideoDataItem> vecVideoData = null;

    public QBVideoResponse() {
    }

    public QBVideoResponse(String sGuid2, int iVideoClass2, ArrayList<VideoDataItem> vecVideoData2, ArrayList<ShortVideoDataItem> vecShortVideoData2, String sMoreUrl2) {
        this.sGuid = sGuid2;
        this.iVideoClass = iVideoClass2;
        this.vecVideoData = vecVideoData2;
        this.vecShortVideoData = vecShortVideoData2;
        this.sMoreUrl = sMoreUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        _os.write(this.iVideoClass, 1);
        if (this.vecVideoData != null) {
            _os.write((Collection) this.vecVideoData, 2);
        }
        if (this.vecShortVideoData != null) {
            _os.write((Collection) this.vecShortVideoData, 3);
        }
        if (this.sMoreUrl != null) {
            _os.write(this.sMoreUrl, 4);
        }
    }

    static {
        cache_vecVideoData.add(new VideoDataItem());
        cache_vecShortVideoData.add(new ShortVideoDataItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.iVideoClass = _is.read(this.iVideoClass, 1, false);
        this.vecVideoData = (ArrayList) _is.read((Object) cache_vecVideoData, 2, false);
        this.vecShortVideoData = (ArrayList) _is.read((Object) cache_vecShortVideoData, 3, false);
        this.sMoreUrl = _is.readString(4, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QBVideoResponse temp = (QBVideoResponse) a.parseObject(text, QBVideoResponse.class);
        this.sGuid = temp.sGuid;
        this.iVideoClass = temp.iVideoClass;
        this.vecVideoData = temp.vecVideoData;
        this.vecShortVideoData = temp.vecShortVideoData;
        this.sMoreUrl = temp.sMoreUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
