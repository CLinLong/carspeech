package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIResponseDataItem extends JceStruct {
    public int eDataType = 0;
    public String strContentData = "";
    public String strContentID = "";
    public String strContentURL = "";
    public String strData = "";
    public String strDescription = "";
    public String strDestURL = "";
    public String strDownloadURL = "";
    public String strShareURL = "";
    public String strTitle = "";

    public AIResponseDataItem() {
    }

    public AIResponseDataItem(int eDataType2, String strTitle2, String strDescription2, String strContentURL2, String strDestURL2, String strDownloadURL2, String strContentData2, String strContentID2, String strShareURL2, String strData2) {
        this.eDataType = eDataType2;
        this.strTitle = strTitle2;
        this.strDescription = strDescription2;
        this.strContentURL = strContentURL2;
        this.strDestURL = strDestURL2;
        this.strDownloadURL = strDownloadURL2;
        this.strContentData = strContentData2;
        this.strContentID = strContentID2;
        this.strShareURL = strShareURL2;
        this.strData = strData2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eDataType, 0);
        if (this.strTitle != null) {
            _os.write(this.strTitle, 1);
        }
        if (this.strDescription != null) {
            _os.write(this.strDescription, 2);
        }
        if (this.strContentURL != null) {
            _os.write(this.strContentURL, 3);
        }
        if (this.strDestURL != null) {
            _os.write(this.strDestURL, 4);
        }
        if (this.strDownloadURL != null) {
            _os.write(this.strDownloadURL, 5);
        }
        if (this.strContentData != null) {
            _os.write(this.strContentData, 6);
        }
        if (this.strContentID != null) {
            _os.write(this.strContentID, 7);
        }
        if (this.strShareURL != null) {
            _os.write(this.strShareURL, 8);
        }
        if (this.strData != null) {
            _os.write(this.strData, 9);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eDataType = _is.read(this.eDataType, 0, true);
        this.strTitle = _is.readString(1, false);
        this.strDescription = _is.readString(2, false);
        this.strContentURL = _is.readString(3, false);
        this.strDestURL = _is.readString(4, false);
        this.strDownloadURL = _is.readString(5, false);
        this.strContentData = _is.readString(6, false);
        this.strContentID = _is.readString(7, false);
        this.strShareURL = _is.readString(8, false);
        this.strData = _is.readString(9, false);
    }
}
