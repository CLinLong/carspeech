package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class IDCenterQBIdStruct extends JceStruct {
    static ArrayList<IDCenterIdStruct> cache_vId = new ArrayList<>();
    public String sIdInfo = "";
    public String sPhoneNumber = "";
    public String sQBId = "";
    public ArrayList<IDCenterIdStruct> vId = null;

    public IDCenterQBIdStruct() {
    }

    public IDCenterQBIdStruct(String sQBId2, ArrayList<IDCenterIdStruct> vId2, String sIdInfo2, String sPhoneNumber2) {
        this.sQBId = sQBId2;
        this.vId = vId2;
        this.sIdInfo = sIdInfo2;
        this.sPhoneNumber = sPhoneNumber2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sQBId, 0);
        if (this.vId != null) {
            _os.write((Collection) this.vId, 1);
        }
        if (this.sIdInfo != null) {
            _os.write(this.sIdInfo, 2);
        }
        if (this.sPhoneNumber != null) {
            _os.write(this.sPhoneNumber, 3);
        }
    }

    static {
        cache_vId.add(new IDCenterIdStruct());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sQBId = _is.readString(0, true);
        this.vId = (ArrayList) _is.read((Object) cache_vId, 1, false);
        this.sIdInfo = _is.readString(2, false);
        this.sPhoneNumber = _is.readString(3, false);
    }
}
