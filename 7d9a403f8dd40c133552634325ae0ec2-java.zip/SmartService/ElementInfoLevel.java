package SmartService;

import java.io.Serializable;

public final class ElementInfoLevel implements Serializable {
    public static final int _E_ELEMENTINFOLVL_DEFAULT = 0;
    public static final int _E_ELEMENTINFOLVL_EMERGENCY = 3;
    public static final int _E_ELEMENTINFOLVL_NORMAL = 1;
    public static final int _E_ELEMENTINFOLVL_WARMMING = 2;
}
