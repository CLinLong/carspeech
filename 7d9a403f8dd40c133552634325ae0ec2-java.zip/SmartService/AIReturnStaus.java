package SmartService;

import java.io.Serializable;

public final class AIReturnStaus implements Serializable {
    public static final int _E_AIRETURNSTAUS_ASR = 1;
    public static final int _E_AIRETURNSTAUS_NORMAL = 0;
    public static final int _E_AIRETURNSTAUS_TTS = 2;
}
