package SmartService;

import java.io.Serializable;

public final class EIDCenterImageType implements Serializable {
    public static final int _IDCENTER_IMAGE_132 = 1;
    public static final int _IDCENTER_IMAGE_46 = 4;
    public static final int _IDCENTER_IMAGE_64 = 3;
    public static final int _IDCENTER_IMAGE_96 = 2;
    public static final int _IDCENTER_IMAGE_DEFAULT = 0;
}
