package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AITicketInfo extends JceStruct {
    static int cache_eAcctType = 0;
    public int eAcctType = 3;
    public int expiredTimeInSeconds = 0;
    public String strAccessToken = "";
    public String strAcctAppId = "";
    public String strAcctId = "";
    public String strAuthScope = "";
    public String strRefreshToken = "";

    public AITicketInfo() {
    }

    public AITicketInfo(int eAcctType2, String strAcctId2, String strAcctAppId2, String strAccessToken2, String strRefreshToken2, int expiredTimeInSeconds2, String strAuthScope2) {
        this.eAcctType = eAcctType2;
        this.strAcctId = strAcctId2;
        this.strAcctAppId = strAcctAppId2;
        this.strAccessToken = strAccessToken2;
        this.strRefreshToken = strRefreshToken2;
        this.expiredTimeInSeconds = expiredTimeInSeconds2;
        this.strAuthScope = strAuthScope2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eAcctType, 0);
        _os.write(this.strAcctId, 1);
        _os.write(this.strAcctAppId, 2);
        _os.write(this.strAccessToken, 3);
        _os.write(this.strRefreshToken, 4);
        _os.write(this.expiredTimeInSeconds, 6);
        _os.write(this.strAuthScope, 7);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eAcctType = _is.read(this.eAcctType, 0, true);
        this.strAcctId = _is.readString(1, true);
        this.strAcctAppId = _is.readString(2, true);
        this.strAccessToken = _is.readString(3, true);
        this.strRefreshToken = _is.readString(4, true);
        this.expiredTimeInSeconds = _is.read(this.expiredTimeInSeconds, 6, true);
        this.strAuthScope = _is.readString(7, true);
    }
}
