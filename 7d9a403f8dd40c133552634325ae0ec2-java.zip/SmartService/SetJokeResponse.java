package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SetJokeResponse extends JceStruct {
    public int hateScore = 0;
    public long jokeId = 0;
    public int likeScore = 0;
    public int pushTimes = 0;
    public String replyText = "";
    public int userScore = 0;

    public SetJokeResponse() {
    }

    public SetJokeResponse(long jokeId2, String replyText2, int userScore2, int likeScore2, int hateScore2, int pushTimes2) {
        this.jokeId = jokeId2;
        this.replyText = replyText2;
        this.userScore = userScore2;
        this.likeScore = likeScore2;
        this.hateScore = hateScore2;
        this.pushTimes = pushTimes2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.jokeId, 0);
        _os.write(this.replyText, 1);
        _os.write(this.userScore, 2);
        _os.write(this.likeScore, 3);
        _os.write(this.hateScore, 4);
        _os.write(this.pushTimes, 5);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.jokeId = _is.read(this.jokeId, 0, true);
        this.replyText = _is.readString(1, true);
        this.userScore = _is.read(this.userScore, 2, true);
        this.likeScore = _is.read(this.likeScore, 3, false);
        this.hateScore = _is.read(this.hateScore, 4, false);
        this.pushTimes = _is.read(this.pushTimes, 5, false);
    }
}
