package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NewsDimensionParam extends JceStruct {
    static ArrayList<NewsDimensionUnit> cache_units = new ArrayList<>();
    public ArrayList<NewsDimensionUnit> units = null;

    public NewsDimensionParam() {
    }

    public NewsDimensionParam(ArrayList<NewsDimensionUnit> units2) {
        this.units = units2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.units, 0);
    }

    static {
        cache_units.add(new NewsDimensionUnit());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.units = (ArrayList) _is.read((Object) cache_units, 0, true);
    }
}
