package SmartService;

import java.io.Serializable;

public final class EAcctType implements Serializable {
    public static final int _EPhoneNumber = 4;
    public static final int _EQQNumber = 1;
    public static final int _EQQOpenId = 2;
    public static final int _EQbId = 5;
    public static final int _EUnknownAcctType = -1;
    public static final int _EWechatOpenId = 3;
}
