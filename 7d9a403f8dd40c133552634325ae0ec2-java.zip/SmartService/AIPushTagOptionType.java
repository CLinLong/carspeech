package SmartService;

import java.io.Serializable;

public final class AIPushTagOptionType implements Serializable {
    public static final int _E_AIPUSHMSG_OR = 1;
    public static final int _E_AIPUSHTAGOPT_AND = 0;
}
