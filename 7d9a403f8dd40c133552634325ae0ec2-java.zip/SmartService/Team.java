package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class Team extends JceStruct {
    public int teamGoal = 0;
    public String teamLogo = "";
    public String teamName = "";

    public Team() {
    }

    public Team(String teamName2, String teamLogo2, int teamGoal2) {
        this.teamName = teamName2;
        this.teamLogo = teamLogo2;
        this.teamGoal = teamGoal2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.teamName, 0);
        if (this.teamLogo != null) {
            _os.write(this.teamLogo, 1);
        }
        _os.write(this.teamGoal, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.teamName = _is.readString(0, true);
        this.teamLogo = _is.readString(1, false);
        this.teamGoal = _is.read(this.teamGoal, 2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        Team temp = (Team) a.parseObject(text, Team.class);
        this.teamName = temp.teamName;
        this.teamLogo = temp.teamLogo;
        this.teamGoal = temp.teamGoal;
    }
}
