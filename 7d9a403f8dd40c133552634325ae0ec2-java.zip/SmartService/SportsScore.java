package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class SportsScore extends JceStruct {
    static Team cache_awayTeam = new Team();
    static LinkObj cache_detailObj = new LinkObj();
    static ArrayList<GifLink> cache_gifLinks = new ArrayList<>();
    static LinkObj cache_gifObj = new LinkObj();
    static Team cache_homeTeam = new Team();
    static int cache_sportsType = 0;
    public Team awayTeam = null;
    public String competition = "";
    public LinkObj detailObj = null;
    public ArrayList<GifLink> gifLinks = null;
    public LinkObj gifObj = null;
    public String groupName = "";
    public Team homeTeam = null;
    public String matchId = "";
    public String period = "";
    public String roundNumber = "";
    public String roundType = "";
    public String sportsStartTime = "";
    public int sportsType = 0;

    public SportsScore() {
    }

    public SportsScore(String sportsStartTime2, Team homeTeam2, Team awayTeam2, int sportsType2, LinkObj detailObj2, LinkObj gifObj2, ArrayList<GifLink> gifLinks2, String competition2, String matchId2, String period2, String groupName2, String roundNumber2, String roundType2) {
        this.sportsStartTime = sportsStartTime2;
        this.homeTeam = homeTeam2;
        this.awayTeam = awayTeam2;
        this.sportsType = sportsType2;
        this.detailObj = detailObj2;
        this.gifObj = gifObj2;
        this.gifLinks = gifLinks2;
        this.competition = competition2;
        this.matchId = matchId2;
        this.period = period2;
        this.groupName = groupName2;
        this.roundNumber = roundNumber2;
        this.roundType = roundType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sportsStartTime, 0);
        _os.write((JceStruct) this.homeTeam, 1);
        _os.write((JceStruct) this.awayTeam, 2);
        _os.write(this.sportsType, 3);
        _os.write((JceStruct) this.detailObj, 5);
        if (this.gifObj != null) {
            _os.write((JceStruct) this.gifObj, 6);
        }
        if (this.gifLinks != null) {
            _os.write((Collection) this.gifLinks, 7);
        }
        if (this.competition != null) {
            _os.write(this.competition, 8);
        }
        if (this.matchId != null) {
            _os.write(this.matchId, 9);
        }
        if (this.period != null) {
            _os.write(this.period, 10);
        }
        if (this.groupName != null) {
            _os.write(this.groupName, 11);
        }
        if (this.roundNumber != null) {
            _os.write(this.roundNumber, 12);
        }
        if (this.roundType != null) {
            _os.write(this.roundType, 13);
        }
    }

    static {
        cache_gifLinks.add(new GifLink());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sportsStartTime = _is.readString(0, true);
        this.homeTeam = (Team) _is.read((JceStruct) cache_homeTeam, 1, true);
        this.awayTeam = (Team) _is.read((JceStruct) cache_awayTeam, 2, true);
        this.sportsType = _is.read(this.sportsType, 3, false);
        this.detailObj = (LinkObj) _is.read((JceStruct) cache_detailObj, 5, true);
        this.gifObj = (LinkObj) _is.read((JceStruct) cache_gifObj, 6, false);
        this.gifLinks = (ArrayList) _is.read((Object) cache_gifLinks, 7, false);
        this.competition = _is.readString(8, false);
        this.matchId = _is.readString(9, false);
        this.period = _is.readString(10, false);
        this.groupName = _is.readString(11, false);
        this.roundNumber = _is.readString(12, false);
        this.roundType = _is.readString(13, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SportsScore temp = (SportsScore) a.parseObject(text, SportsScore.class);
        this.sportsStartTime = temp.sportsStartTime;
        this.homeTeam = temp.homeTeam;
        this.awayTeam = temp.awayTeam;
        this.sportsType = temp.sportsType;
        this.detailObj = temp.detailObj;
        this.gifObj = temp.gifObj;
        this.gifLinks = temp.gifLinks;
        this.competition = temp.competition;
        this.matchId = temp.matchId;
        this.period = temp.period;
        this.groupName = temp.groupName;
        this.roundNumber = temp.roundNumber;
        this.roundType = temp.roundType;
    }
}
