package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class TvProgramsResponse extends JceStruct {
    static int cache_resStatus = 0;
    static ArrayList<TvProgramsList> cache_vecTvProgramsList = new ArrayList<>();
    public int resStatus = 0;
    public String strSpeakText = "";
    public String strSpeakTipsText = "";
    public String strTipsText = "";
    public String strWxText = "";
    public ArrayList<TvProgramsList> vecTvProgramsList = null;

    public TvProgramsResponse() {
    }

    public TvProgramsResponse(int resStatus2, ArrayList<TvProgramsList> vecTvProgramsList2, String strTipsText2, String strSpeakTipsText2, String strSpeakText2, String strWxText2) {
        this.resStatus = resStatus2;
        this.vecTvProgramsList = vecTvProgramsList2;
        this.strTipsText = strTipsText2;
        this.strSpeakTipsText = strSpeakTipsText2;
        this.strSpeakText = strSpeakText2;
        this.strWxText = strWxText2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.resStatus, 0);
        if (this.vecTvProgramsList != null) {
            _os.write((Collection) this.vecTvProgramsList, 1);
        }
        if (this.strTipsText != null) {
            _os.write(this.strTipsText, 2);
        }
        if (this.strSpeakTipsText != null) {
            _os.write(this.strSpeakTipsText, 3);
        }
        if (this.strSpeakText != null) {
            _os.write(this.strSpeakText, 4);
        }
        if (this.strWxText != null) {
            _os.write(this.strWxText, 5);
        }
    }

    static {
        cache_vecTvProgramsList.add(new TvProgramsList());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.resStatus = _is.read(this.resStatus, 0, false);
        this.vecTvProgramsList = (ArrayList) _is.read((Object) cache_vecTvProgramsList, 1, false);
        this.strTipsText = _is.readString(2, false);
        this.strSpeakTipsText = _is.readString(3, false);
        this.strSpeakText = _is.readString(4, false);
        this.strWxText = _is.readString(5, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        TvProgramsResponse temp = (TvProgramsResponse) a.parseObject(text, TvProgramsResponse.class);
        this.resStatus = temp.resStatus;
        this.vecTvProgramsList = temp.vecTvProgramsList;
        this.strTipsText = temp.strTipsText;
        this.strSpeakTipsText = temp.strSpeakTipsText;
        this.strSpeakText = temp.strSpeakText;
        this.strWxText = temp.strWxText;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
