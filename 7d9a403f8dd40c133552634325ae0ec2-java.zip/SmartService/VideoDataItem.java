package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class VideoDataItem extends JceStruct {
    static ArrayList<String> cache_vecActor = new ArrayList<>();
    static ArrayList<String> cache_vecDirector = new ArrayList<>();
    public int iVideoType = 0;
    public String sArea = "";
    public String sBrief = "";
    public String sCurSetNum = "";
    public String sEdition = "";
    public String sName = "";
    public String sNickName = "";
    public String sPicUrl = "";
    public String sPlayUrl = "";
    public String sScore = "";
    public String sSevenCount = "";
    public String sSubType = "";
    public String sToTalSetNum = "";
    public String sType = "";
    public String sVideoId = "";
    public String sYear = "";
    public ArrayList<String> vecActor = null;
    public ArrayList<String> vecDirector = null;

    public VideoDataItem() {
    }

    public VideoDataItem(String sName2, String sNickName2, String sVideoId2, String sPicUrl2, String sPlayUrl2, String sArea2, String sBrief2, String sEdition2, String sType2, String sSubType2, String sScore2, String sYear2, ArrayList<String> vecDirector2, ArrayList<String> vecActor2, String sCurSetNum2, String sToTalSetNum2, String sSevenCount2, int iVideoType2) {
        this.sName = sName2;
        this.sNickName = sNickName2;
        this.sVideoId = sVideoId2;
        this.sPicUrl = sPicUrl2;
        this.sPlayUrl = sPlayUrl2;
        this.sArea = sArea2;
        this.sBrief = sBrief2;
        this.sEdition = sEdition2;
        this.sType = sType2;
        this.sSubType = sSubType2;
        this.sScore = sScore2;
        this.sYear = sYear2;
        this.vecDirector = vecDirector2;
        this.vecActor = vecActor2;
        this.sCurSetNum = sCurSetNum2;
        this.sToTalSetNum = sToTalSetNum2;
        this.sSevenCount = sSevenCount2;
        this.iVideoType = iVideoType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sName, 0);
        if (this.sNickName != null) {
            _os.write(this.sNickName, 1);
        }
        if (this.sVideoId != null) {
            _os.write(this.sVideoId, 2);
        }
        if (this.sPicUrl != null) {
            _os.write(this.sPicUrl, 3);
        }
        if (this.sPlayUrl != null) {
            _os.write(this.sPlayUrl, 4);
        }
        if (this.sArea != null) {
            _os.write(this.sArea, 5);
        }
        if (this.sBrief != null) {
            _os.write(this.sBrief, 6);
        }
        if (this.sEdition != null) {
            _os.write(this.sEdition, 7);
        }
        if (this.sType != null) {
            _os.write(this.sType, 8);
        }
        if (this.sSubType != null) {
            _os.write(this.sSubType, 9);
        }
        if (this.sScore != null) {
            _os.write(this.sScore, 10);
        }
        if (this.sYear != null) {
            _os.write(this.sYear, 11);
        }
        if (this.vecDirector != null) {
            _os.write((Collection) this.vecDirector, 12);
        }
        if (this.vecActor != null) {
            _os.write((Collection) this.vecActor, 13);
        }
        if (this.sCurSetNum != null) {
            _os.write(this.sCurSetNum, 14);
        }
        if (this.sToTalSetNum != null) {
            _os.write(this.sToTalSetNum, 15);
        }
        if (this.sSevenCount != null) {
            _os.write(this.sSevenCount, 16);
        }
        _os.write(this.iVideoType, 17);
    }

    static {
        cache_vecDirector.add("");
        cache_vecActor.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sName = _is.readString(0, true);
        this.sNickName = _is.readString(1, false);
        this.sVideoId = _is.readString(2, false);
        this.sPicUrl = _is.readString(3, false);
        this.sPlayUrl = _is.readString(4, false);
        this.sArea = _is.readString(5, false);
        this.sBrief = _is.readString(6, false);
        this.sEdition = _is.readString(7, false);
        this.sType = _is.readString(8, false);
        this.sSubType = _is.readString(9, false);
        this.sScore = _is.readString(10, false);
        this.sYear = _is.readString(11, false);
        this.vecDirector = (ArrayList) _is.read((Object) cache_vecDirector, 12, false);
        this.vecActor = (ArrayList) _is.read((Object) cache_vecActor, 13, false);
        this.sCurSetNum = _is.readString(14, false);
        this.sToTalSetNum = _is.readString(15, false);
        this.sSevenCount = _is.readString(16, false);
        this.iVideoType = _is.read(this.iVideoType, 17, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        VideoDataItem temp = (VideoDataItem) a.parseObject(text, VideoDataItem.class);
        this.sName = temp.sName;
        this.sNickName = temp.sNickName;
        this.sVideoId = temp.sVideoId;
        this.sPicUrl = temp.sPicUrl;
        this.sPlayUrl = temp.sPlayUrl;
        this.sArea = temp.sArea;
        this.sBrief = temp.sBrief;
        this.sEdition = temp.sEdition;
        this.sType = temp.sType;
        this.sSubType = temp.sSubType;
        this.sScore = temp.sScore;
        this.sYear = temp.sYear;
        this.vecDirector = temp.vecDirector;
        this.vecActor = temp.vecActor;
        this.sCurSetNum = temp.sCurSetNum;
        this.sToTalSetNum = temp.sToTalSetNum;
        this.sSevenCount = temp.sSevenCount;
        this.iVideoType = temp.iVideoType;
    }
}
