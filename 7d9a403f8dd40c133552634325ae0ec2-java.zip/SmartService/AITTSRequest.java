package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AITTSRequest extends JceStruct {
    static AIAccountInfo cache_sUserAccount = new AIAccountInfo();
    public int iEngineType = 0;
    public int iIndex = 0;
    public int iLanguageType = 0;
    public int iSingleRequest = 1;
    public int iSpeechFormat = 1;
    public int iSpeechPitch = 50;
    public int iSpeechSpeed = 50;
    public int iSpeechType = 0;
    public int iSpeechVolume = 50;
    public int iTextFormat = 0;
    public AIAccountInfo sUserAccount = null;
    public String strAppAccessToken = "";
    public String strAppKey = "";
    public String strBusineseName = "";
    public String strGUID = "";
    public String strQUA = "";
    public String strSessionId = "";
    public String strText = "";

    public AITTSRequest() {
    }

    public AITTSRequest(String strText2, String strQUA2, String strGUID2, int iEngineType2, int iTextFormat2, int iSpeechFormat2, int iSpeechType2, String strBusineseName2, String strSessionId2, int iSpeechVolume2, int iSpeechSpeed2, int iSpeechPitch2, int iIndex2, int iSingleRequest2, int iLanguageType2, String strAppKey2, String strAppAccessToken2, AIAccountInfo sUserAccount2) {
        this.strText = strText2;
        this.strQUA = strQUA2;
        this.strGUID = strGUID2;
        this.iEngineType = iEngineType2;
        this.iTextFormat = iTextFormat2;
        this.iSpeechFormat = iSpeechFormat2;
        this.iSpeechType = iSpeechType2;
        this.strBusineseName = strBusineseName2;
        this.strSessionId = strSessionId2;
        this.iSpeechVolume = iSpeechVolume2;
        this.iSpeechSpeed = iSpeechSpeed2;
        this.iSpeechPitch = iSpeechPitch2;
        this.iIndex = iIndex2;
        this.iSingleRequest = iSingleRequest2;
        this.iLanguageType = iLanguageType2;
        this.strAppKey = strAppKey2;
        this.strAppAccessToken = strAppAccessToken2;
        this.sUserAccount = sUserAccount2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.strText, 0);
        if (this.strQUA != null) {
            _os.write(this.strQUA, 1);
        }
        if (this.strGUID != null) {
            _os.write(this.strGUID, 2);
        }
        _os.write(this.iEngineType, 3);
        _os.write(this.iTextFormat, 4);
        _os.write(this.iSpeechFormat, 5);
        _os.write(this.iSpeechType, 6);
        if (this.strBusineseName != null) {
            _os.write(this.strBusineseName, 7);
        }
        if (this.strSessionId != null) {
            _os.write(this.strSessionId, 8);
        }
        _os.write(this.iSpeechVolume, 9);
        _os.write(this.iSpeechSpeed, 10);
        _os.write(this.iSpeechPitch, 11);
        _os.write(this.iIndex, 12);
        _os.write(this.iSingleRequest, 13);
        _os.write(this.iLanguageType, 14);
        if (this.strAppKey != null) {
            _os.write(this.strAppKey, 15);
        }
        if (this.strAppAccessToken != null) {
            _os.write(this.strAppAccessToken, 16);
        }
        if (this.sUserAccount != null) {
            _os.write((JceStruct) this.sUserAccount, 17);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strText = _is.readString(0, true);
        this.strQUA = _is.readString(1, false);
        this.strGUID = _is.readString(2, false);
        this.iEngineType = _is.read(this.iEngineType, 3, false);
        this.iTextFormat = _is.read(this.iTextFormat, 4, false);
        this.iSpeechFormat = _is.read(this.iSpeechFormat, 5, false);
        this.iSpeechType = _is.read(this.iSpeechType, 6, false);
        this.strBusineseName = _is.readString(7, false);
        this.strSessionId = _is.readString(8, false);
        this.iSpeechVolume = _is.read(this.iSpeechVolume, 9, false);
        this.iSpeechSpeed = _is.read(this.iSpeechSpeed, 10, false);
        this.iSpeechPitch = _is.read(this.iSpeechPitch, 11, false);
        this.iIndex = _is.read(this.iIndex, 12, false);
        this.iSingleRequest = _is.read(this.iSingleRequest, 13, false);
        this.iLanguageType = _is.read(this.iLanguageType, 14, false);
        this.strAppKey = _is.readString(15, false);
        this.strAppAccessToken = _is.readString(16, false);
        this.sUserAccount = (AIAccountInfo) _is.read((JceStruct) cache_sUserAccount, 17, false);
    }
}
