package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class CCookMaterial extends JceStruct {
    public String strName = "";
    public String strNote = "";

    public CCookMaterial() {
    }

    public CCookMaterial(String strName2, String strNote2) {
        this.strName = strName2;
        this.strNote = strNote2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strName != null) {
            _os.write(this.strName, 0);
        }
        if (this.strNote != null) {
            _os.write(this.strNote, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strName = _is.readString(0, false);
        this.strNote = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        CCookMaterial temp = (CCookMaterial) a.parseObject(text, CCookMaterial.class);
        this.strName = temp.strName;
        this.strNote = temp.strNote;
    }
}
