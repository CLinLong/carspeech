package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AISpeakerPushInfo extends JceStruct {
    public String strData = "";
    public int type = 1;

    public AISpeakerPushInfo() {
    }

    public AISpeakerPushInfo(int type2, String strData2) {
        this.type = type2;
        this.strData = strData2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.type, 0);
        _os.write(this.strData, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.type = _is.read(this.type, 0, true);
        this.strData = _is.readString(1, true);
    }
}
