package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AIRequestParam extends JceStruct {
    static int cache_iOutputType = 0;
    static AISemanticMetaV2 cache_sSemanticMeta = new AISemanticMetaV2();
    static AITTSMeta cache_sTTSMeta = new AITTSMeta();
    static AIVoiceMetaV2 cache_sVoiceMeta = new AIVoiceMetaV2();
    static ArrayList<AISDKContent> cache_vecDataEx = new ArrayList<>();
    public int iOutputType = 0;
    public AISemanticMetaV2 sSemanticMeta = null;
    public AITTSMeta sTTSMeta = null;
    public AIVoiceMetaV2 sVoiceMeta = null;
    public ArrayList<AISDKContent> vecDataEx = null;

    public AIRequestParam() {
    }

    public AIRequestParam(AIVoiceMetaV2 sVoiceMeta2, AISemanticMetaV2 sSemanticMeta2, AITTSMeta sTTSMeta2, int iOutputType2, ArrayList<AISDKContent> vecDataEx2) {
        this.sVoiceMeta = sVoiceMeta2;
        this.sSemanticMeta = sSemanticMeta2;
        this.sTTSMeta = sTTSMeta2;
        this.iOutputType = iOutputType2;
        this.vecDataEx = vecDataEx2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sVoiceMeta != null) {
            _os.write((JceStruct) this.sVoiceMeta, 0);
        }
        if (this.sSemanticMeta != null) {
            _os.write((JceStruct) this.sSemanticMeta, 1);
        }
        if (this.sTTSMeta != null) {
            _os.write((JceStruct) this.sTTSMeta, 2);
        }
        _os.write(this.iOutputType, 3);
        if (this.vecDataEx != null) {
            _os.write((Collection) this.vecDataEx, 4);
        }
    }

    static {
        cache_vecDataEx.add(new AISDKContent());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sVoiceMeta = (AIVoiceMetaV2) _is.read((JceStruct) cache_sVoiceMeta, 0, false);
        this.sSemanticMeta = (AISemanticMetaV2) _is.read((JceStruct) cache_sSemanticMeta, 1, false);
        this.sTTSMeta = (AITTSMeta) _is.read((JceStruct) cache_sTTSMeta, 2, false);
        this.iOutputType = _is.read(this.iOutputType, 3, false);
        this.vecDataEx = (ArrayList) _is.read((Object) cache_vecDataEx, 4, false);
    }
}
