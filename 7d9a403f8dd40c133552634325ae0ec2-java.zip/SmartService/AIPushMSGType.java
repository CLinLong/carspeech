package SmartService;

import java.io.Serializable;

public final class AIPushMSGType implements Serializable {
    public static final int _E_AIPUSHMSGTYPE_COMMON = 0;
    public static final int _E_AIPUSHMSGTYPE_NOTIFY = 1;
    public static final int _E_AIPUSHMSGTYPE_PASSTHROUGH = 2;
}
