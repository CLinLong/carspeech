package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class newsLink extends JceStruct {
    public String href = "";
    public String name = "";

    public newsLink() {
    }

    public newsLink(String name2, String href2) {
        this.name = name2;
        this.href = href2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.name, 0);
        _os.write(this.href, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.name = _is.readString(0, true);
        this.href = _is.readString(1, true);
    }
}
