package SmartService;

import java.io.Serializable;

public final class EnumYellowPagesStatus implements Serializable {
    public static final int _RES_YELLOWPAGE_ERROR = -1;
    public static final int _RES_YELLOWPAGE_OK = 0;
}
