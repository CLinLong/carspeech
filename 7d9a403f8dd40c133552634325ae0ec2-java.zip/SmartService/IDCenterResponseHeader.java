package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class IDCenterResponseHeader extends JceStruct {
    public int iCode = 0;
    public int retCode = 0;
    public String sErrMessage = "";

    public IDCenterResponseHeader() {
    }

    public IDCenterResponseHeader(int iCode2, String sErrMessage2, int retCode2) {
        this.iCode = iCode2;
        this.sErrMessage = sErrMessage2;
        this.retCode = retCode2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iCode, 0);
        if (this.sErrMessage != null) {
            _os.write(this.sErrMessage, 1);
        }
        _os.write(this.retCode, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iCode = _is.read(this.iCode, 0, true);
        this.sErrMessage = _is.readString(1, false);
        this.retCode = _is.read(this.retCode, 2, false);
    }
}
