package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class StockAnswerResponse extends JceStruct {
    public String answer = "";
    public String sGuid = "";

    public StockAnswerResponse() {
    }

    public StockAnswerResponse(String sGuid2, String answer2) {
        this.sGuid = sGuid2;
        this.answer = answer2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        if (this.answer != null) {
            _os.write(this.answer, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.answer = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        StockAnswerResponse temp = (StockAnswerResponse) a.parseObject(text, StockAnswerResponse.class);
        this.sGuid = temp.sGuid;
        this.answer = temp.answer;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
