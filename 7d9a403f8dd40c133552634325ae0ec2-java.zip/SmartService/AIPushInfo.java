package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIPushInfo extends JceStruct {
    static int cache_ePlatformType = 0;
    static int cache_ePushType = 0;
    public int ePlatformType = 1;
    public int ePushType = 0;
    public String strGuid = "";
    public String strId = "";
    public String strIdExtra = "";

    public AIPushInfo() {
    }

    public AIPushInfo(int ePushType2, int ePlatformType2, String strId2, String strIdExtra2, String strGuid2) {
        this.ePushType = ePushType2;
        this.ePlatformType = ePlatformType2;
        this.strId = strId2;
        this.strIdExtra = strIdExtra2;
        this.strGuid = strGuid2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.ePushType, 0);
        _os.write(this.ePlatformType, 1);
        _os.write(this.strId, 2);
        _os.write(this.strIdExtra, 3);
        _os.write(this.strGuid, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.ePushType = _is.read(this.ePushType, 0, true);
        this.ePlatformType = _is.read(this.ePlatformType, 1, true);
        this.strId = _is.readString(2, true);
        this.strIdExtra = _is.readString(3, true);
        this.strGuid = _is.readString(4, true);
    }
}
