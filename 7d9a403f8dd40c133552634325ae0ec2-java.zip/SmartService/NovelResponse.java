package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NovelResponse extends JceStruct {
    static ArrayList<NovelData> cache_novelDataVec = new ArrayList<>();
    public ArrayList<NovelData> novelDataVec = null;
    public String strMoreUrl = "";

    public NovelResponse() {
    }

    public NovelResponse(ArrayList<NovelData> novelDataVec2, String strMoreUrl2) {
        this.novelDataVec = novelDataVec2;
        this.strMoreUrl = strMoreUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.novelDataVec != null) {
            _os.write((Collection) this.novelDataVec, 0);
        }
        if (this.strMoreUrl != null) {
            _os.write(this.strMoreUrl, 1);
        }
    }

    static {
        cache_novelDataVec.add(new NovelData());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.novelDataVec = (ArrayList) _is.read((Object) cache_novelDataVec, 0, false);
        this.strMoreUrl = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        NovelResponse temp = (NovelResponse) a.parseObject(text, NovelResponse.class);
        this.novelDataVec = temp.novelDataVec;
        this.strMoreUrl = temp.strMoreUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
