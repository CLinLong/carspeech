package SmartService;

import java.io.Serializable;

public final class AIDataType implements Serializable {
    static final /* synthetic */ boolean $assertionsDisabled = (!AIDataType.class.desiredAssertionStatus());
    public static final AIDataType E_AIDATATYPE_ALLURL = new AIDataType(8, 8, "E_AIDATATYPE_ALLURL");
    public static final AIDataType E_AIDATATYPE_CP_RAW_DATA = new AIDataType(16, 16, "E_AIDATATYPE_CP_RAW_DATA");
    public static final AIDataType E_AIDATATYPE_EN_TEXT_MEDIA = new AIDataType(15, 15, "E_AIDATATYPE_EN_TEXT_MEDIA");
    public static final AIDataType E_AIDATATYPE_IMAGE = new AIDataType(2, 2, "E_AIDATATYPE_IMAGE");
    public static final AIDataType E_AIDATATYPE_IMAGE_TEXT_TEMPLATE_CARD = new AIDataType(9, 9, "E_AIDATATYPE_IMAGE_TEXT_TEMPLATE_CARD");
    public static final AIDataType E_AIDATATYPE_MUSIC = new AIDataType(5, 5, "E_AIDATATYPE_MUSIC");
    public static final AIDataType E_AIDATATYPE_NATIVE = new AIDataType(7, 7, "E_AIDATATYPE_NATIVE");
    public static final AIDataType E_AIDATATYPE_NEWS = new AIDataType(6, 6, "E_AIDATATYPE_NEWS");
    public static final AIDataType E_AIDATATYPE_OPTION_TEMPLATE_CARD = new AIDataType(13, 13, "E_AIDATATYPE_OPTION_TEMPLATE_CARD");
    public static final AIDataType E_AIDATATYPE_SHARE = new AIDataType(14, 14, "E_AIDATATYPE_SHARE");
    public static final AIDataType E_AIDATATYPE_TAB_TEXT_TEMPLATE_CARD = new AIDataType(10, 10, "E_AIDATATYPE_TAB_TEXT_TEMPLATE_CARD");
    public static final AIDataType E_AIDATATYPE_TEXT = new AIDataType(1, 1, "E_AIDATATYPE_TEXT");
    public static final AIDataType E_AIDATATYPE_TEXT_MEDIA = new AIDataType(11, 11, "E_AIDATATYPE_TEXT_MEDIA");
    public static final AIDataType E_AIDATATYPE_TRAVEL_TEMPLATE_CARD = new AIDataType(12, 12, "E_AIDATATYPE_TRAVEL_TEMPLATE_CARD");
    public static final AIDataType E_AIDATATYPE_UNKNOWN = new AIDataType(0, 0, "E_AIDATATYPE_UNKNOWN");
    public static final AIDataType E_AIDATATYPE_VIDEO = new AIDataType(4, 4, "E_AIDATATYPE_VIDEO");
    public static final AIDataType E_AIDATATYPE_VOICE = new AIDataType(3, 3, "E_AIDATATYPE_VOICE");
    public static final int _E_AIDATATYPE_ALLURL = 8;
    public static final int _E_AIDATATYPE_CP_RAW_DATA = 16;
    public static final int _E_AIDATATYPE_EN_TEXT_MEDIA = 15;
    public static final int _E_AIDATATYPE_IMAGE = 2;
    public static final int _E_AIDATATYPE_IMAGE_TEXT_TEMPLATE_CARD = 9;
    public static final int _E_AIDATATYPE_MUSIC = 5;
    public static final int _E_AIDATATYPE_NATIVE = 7;
    public static final int _E_AIDATATYPE_NEWS = 6;
    public static final int _E_AIDATATYPE_OPTION_TEMPLATE_CARD = 13;
    public static final int _E_AIDATATYPE_SHARE = 14;
    public static final int _E_AIDATATYPE_TAB_TEXT_TEMPLATE_CARD = 10;
    public static final int _E_AIDATATYPE_TEXT = 1;
    public static final int _E_AIDATATYPE_TEXT_MEDIA = 11;
    public static final int _E_AIDATATYPE_TRAVEL_TEMPLATE_CARD = 12;
    public static final int _E_AIDATATYPE_UNKNOWN = 0;
    public static final int _E_AIDATATYPE_VIDEO = 4;
    public static final int _E_AIDATATYPE_VOICE = 3;
    private static AIDataType[] __values = new AIDataType[17];
    private String __T = new String();
    private int __value;

    public static AIDataType convert(int val) {
        for (int __i = 0; __i < __values.length; __i++) {
            if (__values[__i].value() == val) {
                return __values[__i];
            }
        }
        if ($assertionsDisabled) {
            return null;
        }
        throw new AssertionError();
    }

    public static AIDataType convert(String val) {
        for (int __i = 0; __i < __values.length; __i++) {
            if (__values[__i].toString().equals(val)) {
                return __values[__i];
            }
        }
        if ($assertionsDisabled) {
            return null;
        }
        throw new AssertionError();
    }

    public int value() {
        return this.__value;
    }

    public String toString() {
        return this.__T;
    }

    private AIDataType(int index, int val, String s) {
        this.__T = s;
        this.__value = val;
        __values[index] = this;
    }
}
