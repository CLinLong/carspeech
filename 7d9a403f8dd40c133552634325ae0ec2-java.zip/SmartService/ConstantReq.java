package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ConstantReq extends JceStruct {
    static int cache_clientType = 0;
    public int clientType = 0;
    public int constantType = 0;
    public String sGuid = "";

    public ConstantReq() {
    }

    public ConstantReq(String sGuid2, int clientType2, int constantType2) {
        this.sGuid = sGuid2;
        this.clientType = clientType2;
        this.constantType = constantType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        _os.write(this.clientType, 1);
        _os.write(this.constantType, 2);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.clientType = _is.read(this.clientType, 1, true);
        this.constantType = _is.read(this.constantType, 2, true);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        ConstantReq temp = (ConstantReq) a.parseObject(text, ConstantReq.class);
        this.sGuid = temp.sGuid;
        this.clientType = temp.clientType;
        this.constantType = temp.constantType;
    }
}
