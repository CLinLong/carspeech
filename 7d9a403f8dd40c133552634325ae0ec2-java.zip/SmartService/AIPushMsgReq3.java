package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import com.tencent.android.tpush.common.MessageKey;

public final class AIPushMsgReq3 extends JceStruct {
    public int expiredTime = 259200;
    public int isUrgent = 0;
    public String strDomain = "";
    public String strIntent = "";
    public String strMessage = "";
    public String strMsgTitle = MessageKey.MSG_TITLE;
    public String strMsgType = "";
    public String strPushInfo = "";
    public String strSrcGuid = "";
    public String strSrcQua = "";
    public String strVoiceSpeakText = "";

    public AIPushMsgReq3() {
    }

    public AIPushMsgReq3(String strPushInfo2, String strDomain2, String strIntent2, int isUrgent2, int expiredTime2, String strMsgType2, String strMsgTitle2, String strMessage2, String strSrcGuid2, String strSrcQua2, String strVoiceSpeakText2) {
        this.strPushInfo = strPushInfo2;
        this.strDomain = strDomain2;
        this.strIntent = strIntent2;
        this.isUrgent = isUrgent2;
        this.expiredTime = expiredTime2;
        this.strMsgType = strMsgType2;
        this.strMsgTitle = strMsgTitle2;
        this.strMessage = strMessage2;
        this.strSrcGuid = strSrcGuid2;
        this.strSrcQua = strSrcQua2;
        this.strVoiceSpeakText = strVoiceSpeakText2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strPushInfo != null) {
            _os.write(this.strPushInfo, 0);
        }
        if (this.strDomain != null) {
            _os.write(this.strDomain, 1);
        }
        if (this.strIntent != null) {
            _os.write(this.strIntent, 2);
        }
        _os.write(this.isUrgent, 3);
        _os.write(this.expiredTime, 4);
        if (this.strMsgType != null) {
            _os.write(this.strMsgType, 5);
        }
        if (this.strMsgTitle != null) {
            _os.write(this.strMsgTitle, 6);
        }
        if (this.strMessage != null) {
            _os.write(this.strMessage, 7);
        }
        if (this.strSrcGuid != null) {
            _os.write(this.strSrcGuid, 8);
        }
        if (this.strSrcQua != null) {
            _os.write(this.strSrcQua, 9);
        }
        if (this.strVoiceSpeakText != null) {
            _os.write(this.strVoiceSpeakText, 10);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strPushInfo = _is.readString(0, false);
        this.strDomain = _is.readString(1, false);
        this.strIntent = _is.readString(2, false);
        this.isUrgent = _is.read(this.isUrgent, 3, false);
        this.expiredTime = _is.read(this.expiredTime, 4, false);
        this.strMsgType = _is.readString(5, false);
        this.strMsgTitle = _is.readString(6, false);
        this.strMessage = _is.readString(7, false);
        this.strSrcGuid = _is.readString(8, false);
        this.strSrcQua = _is.readString(9, false);
        this.strVoiceSpeakText = _is.readString(10, false);
    }
}
