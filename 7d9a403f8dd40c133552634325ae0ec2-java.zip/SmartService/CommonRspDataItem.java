package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class CommonRspDataItem extends JceStruct {
    static int cache_eDataType = 0;
    static byte[] cache_vecCommDataBytes = new byte[1];
    public int eDataType = 0;
    public byte[] vecCommDataBytes = null;

    public CommonRspDataItem() {
    }

    public CommonRspDataItem(int eDataType2, byte[] vecCommDataBytes2) {
        this.eDataType = eDataType2;
        this.vecCommDataBytes = vecCommDataBytes2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.eDataType, 0);
        if (this.vecCommDataBytes != null) {
            _os.write(this.vecCommDataBytes, 1);
        }
    }

    static {
        cache_vecCommDataBytes[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.eDataType = _is.read(this.eDataType, 0, true);
        this.vecCommDataBytes = _is.read(cache_vecCommDataBytes, 1, false);
    }
}
