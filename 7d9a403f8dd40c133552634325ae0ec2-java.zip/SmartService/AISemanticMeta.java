package SmartService;

import SmartAssistant.Semantic;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AISemanticMeta extends JceStruct {
    static Semantic cache_sSemantic = new Semantic();
    public int iSemanticCmd = 0;
    public Semantic sSemantic = null;
    public String strAppAccessToken = "";
    public String strAppKey = "";

    public AISemanticMeta() {
    }

    public AISemanticMeta(String strAppKey2, String strAppAccessToken2, Semantic sSemantic2, int iSemanticCmd2) {
        this.strAppKey = strAppKey2;
        this.strAppAccessToken = strAppAccessToken2;
        this.sSemantic = sSemantic2;
        this.iSemanticCmd = iSemanticCmd2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strAppKey != null) {
            _os.write(this.strAppKey, 0);
        }
        if (this.strAppAccessToken != null) {
            _os.write(this.strAppAccessToken, 1);
        }
        if (this.sSemantic != null) {
            _os.write((JceStruct) this.sSemantic, 2);
        }
        _os.write(this.iSemanticCmd, 3);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strAppKey = _is.readString(0, false);
        this.strAppAccessToken = _is.readString(1, false);
        this.sSemantic = (Semantic) _is.read((JceStruct) cache_sSemantic, 2, false);
        this.iSemanticCmd = _is.read(this.iSemanticCmd, 3, false);
    }
}
