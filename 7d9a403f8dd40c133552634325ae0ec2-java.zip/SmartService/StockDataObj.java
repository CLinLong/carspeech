package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class StockDataObj extends JceStruct {
    public String market = "";
    public String marketValue = "";
    public String peRatio = "";
    public String priceChangeRatio = "";
    public String recentPrice = "";
    public String stockCode = "";
    public String stockName = "";
    public String tradeVol = "";
    public String turnOver = "";
    public String turnRatio = "";

    public StockDataObj() {
    }

    public StockDataObj(String market2, String stockName2, String stockCode2, String recentPrice2, String priceChangeRatio2, String tradeVol2, String turnOver2, String marketValue2, String turnRatio2, String peRatio2) {
        this.market = market2;
        this.stockName = stockName2;
        this.stockCode = stockCode2;
        this.recentPrice = recentPrice2;
        this.priceChangeRatio = priceChangeRatio2;
        this.tradeVol = tradeVol2;
        this.turnOver = turnOver2;
        this.marketValue = marketValue2;
        this.turnRatio = turnRatio2;
        this.peRatio = peRatio2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.market, 0);
        _os.write(this.stockName, 1);
        _os.write(this.stockCode, 2);
        _os.write(this.recentPrice, 3);
        _os.write(this.priceChangeRatio, 4);
        _os.write(this.tradeVol, 5);
        _os.write(this.turnOver, 6);
        if (this.marketValue != null) {
            _os.write(this.marketValue, 7);
        }
        if (this.turnRatio != null) {
            _os.write(this.turnRatio, 8);
        }
        if (this.peRatio != null) {
            _os.write(this.peRatio, 9);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.market = _is.readString(0, true);
        this.stockName = _is.readString(1, true);
        this.stockCode = _is.readString(2, true);
        this.recentPrice = _is.readString(3, true);
        this.priceChangeRatio = _is.readString(4, true);
        this.tradeVol = _is.readString(5, true);
        this.turnOver = _is.readString(6, true);
        this.marketValue = _is.readString(7, false);
        this.turnRatio = _is.readString(8, false);
        this.peRatio = _is.readString(9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        StockDataObj temp = (StockDataObj) a.parseObject(text, StockDataObj.class);
        this.market = temp.market;
        this.stockName = temp.stockName;
        this.stockCode = temp.stockCode;
        this.recentPrice = temp.recentPrice;
        this.priceChangeRatio = temp.priceChangeRatio;
        this.tradeVol = temp.tradeVol;
        this.turnOver = temp.turnOver;
        this.marketValue = temp.marketValue;
        this.turnRatio = temp.turnRatio;
        this.peRatio = temp.peRatio;
    }
}
