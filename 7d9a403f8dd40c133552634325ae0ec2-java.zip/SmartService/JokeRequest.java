package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class JokeRequest extends JceStruct {
    public long jokeId = 0;
    public int setUserScore = 0;
    public String userId = "";

    public JokeRequest() {
    }

    public JokeRequest(long jokeId2, int setUserScore2, String userId2) {
        this.jokeId = jokeId2;
        this.setUserScore = setUserScore2;
        this.userId = userId2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.jokeId, 0);
        _os.write(this.setUserScore, 1);
        if (this.userId != null) {
            _os.write(this.userId, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.jokeId = _is.read(this.jokeId, 0, true);
        this.setUserScore = _is.read(this.setUserScore, 1, true);
        this.userId = _is.readString(2, false);
    }
}
