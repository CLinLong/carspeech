package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class LotteryDataResponse extends JceStruct {
    static ArrayList<LotteryData> cache_dataVec = new ArrayList<>();
    public ArrayList<LotteryData> dataVec = null;
    public int retCode = 0;
    public String strJumpUrl = "";
    public String strTips = "";

    public LotteryDataResponse() {
    }

    public LotteryDataResponse(int retCode2, ArrayList<LotteryData> dataVec2, String strTips2, String strJumpUrl2) {
        this.retCode = retCode2;
        this.dataVec = dataVec2;
        this.strTips = strTips2;
        this.strJumpUrl = strJumpUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.retCode, 0);
        if (this.dataVec != null) {
            _os.write((Collection) this.dataVec, 1);
        }
        if (this.strTips != null) {
            _os.write(this.strTips, 2);
        }
        if (this.strJumpUrl != null) {
            _os.write(this.strJumpUrl, 3);
        }
    }

    static {
        cache_dataVec.add(new LotteryData());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.retCode = _is.read(this.retCode, 0, true);
        this.dataVec = (ArrayList) _is.read((Object) cache_dataVec, 1, false);
        this.strTips = _is.readString(2, false);
        this.strJumpUrl = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        LotteryDataResponse temp = (LotteryDataResponse) a.parseObject(text, LotteryDataResponse.class);
        this.retCode = temp.retCode;
        this.dataVec = temp.dataVec;
        this.strTips = temp.strTips;
        this.strJumpUrl = temp.strJumpUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
