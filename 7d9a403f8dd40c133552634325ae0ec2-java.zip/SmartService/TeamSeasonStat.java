package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class TeamSeasonStat extends JceStruct {
    public String competition = "";
    public float gamesBack = 0.0f;
    public int lostMatchCount = 0;
    public int matchCount = 0;
    public int planishMatchCount = 0;
    public String rank = "";
    public String score = "";
    public String teamLogo = "";
    public String teamName = "";
    public int winMatchCount = 0;

    public TeamSeasonStat() {
    }

    public TeamSeasonStat(String teamName2, String score2, String competition2, String rank2, String teamLogo2, int winMatchCount2, int planishMatchCount2, int lostMatchCount2, int matchCount2, float gamesBack2) {
        this.teamName = teamName2;
        this.score = score2;
        this.competition = competition2;
        this.rank = rank2;
        this.teamLogo = teamLogo2;
        this.winMatchCount = winMatchCount2;
        this.planishMatchCount = planishMatchCount2;
        this.lostMatchCount = lostMatchCount2;
        this.matchCount = matchCount2;
        this.gamesBack = gamesBack2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.teamName, 0);
        _os.write(this.score, 1);
        _os.write(this.competition, 2);
        if (this.rank != null) {
            _os.write(this.rank, 3);
        }
        if (this.teamLogo != null) {
            _os.write(this.teamLogo, 4);
        }
        _os.write(this.winMatchCount, 5);
        _os.write(this.planishMatchCount, 6);
        _os.write(this.lostMatchCount, 7);
        _os.write(this.matchCount, 8);
        _os.write(this.gamesBack, 9);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.teamName = _is.readString(0, true);
        this.score = _is.readString(1, true);
        this.competition = _is.readString(2, true);
        this.rank = _is.readString(3, false);
        this.teamLogo = _is.readString(4, false);
        this.winMatchCount = _is.read(this.winMatchCount, 5, false);
        this.planishMatchCount = _is.read(this.planishMatchCount, 6, false);
        this.lostMatchCount = _is.read(this.lostMatchCount, 7, false);
        this.matchCount = _is.read(this.matchCount, 8, false);
        this.gamesBack = _is.read(this.gamesBack, 9, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        TeamSeasonStat temp = (TeamSeasonStat) a.parseObject(text, TeamSeasonStat.class);
        this.teamName = temp.teamName;
        this.score = temp.score;
        this.competition = temp.competition;
        this.rank = temp.rank;
        this.teamLogo = temp.teamLogo;
        this.winMatchCount = temp.winMatchCount;
        this.planishMatchCount = temp.planishMatchCount;
        this.lostMatchCount = temp.lostMatchCount;
        this.matchCount = temp.matchCount;
        this.gamesBack = temp.gamesBack;
    }
}
