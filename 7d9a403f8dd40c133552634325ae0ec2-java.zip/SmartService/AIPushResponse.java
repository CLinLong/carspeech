package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIPushResponse extends JceStruct {
    public int nErrorCode = 0;
    public String strErrorMessage = "";

    public AIPushResponse() {
    }

    public AIPushResponse(int nErrorCode2, String strErrorMessage2) {
        this.nErrorCode = nErrorCode2;
        this.strErrorMessage = strErrorMessage2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.nErrorCode, 0);
        if (this.strErrorMessage != null) {
            _os.write(this.strErrorMessage, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.nErrorCode = _is.read(this.nErrorCode, 0, true);
        this.strErrorMessage = _is.readString(1, false);
    }
}
