package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class CCookStep extends JceStruct {
    public String stepContent = "";
    public String stepLargeImageUrl = "";
    public int stepNo = 0;
    public String stepSmallImageUrl = "";

    public CCookStep() {
    }

    public CCookStep(int stepNo2, String stepContent2, String stepSmallImageUrl2, String stepLargeImageUrl2) {
        this.stepNo = stepNo2;
        this.stepContent = stepContent2;
        this.stepSmallImageUrl = stepSmallImageUrl2;
        this.stepLargeImageUrl = stepLargeImageUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.stepNo, 0);
        if (this.stepContent != null) {
            _os.write(this.stepContent, 1);
        }
        if (this.stepSmallImageUrl != null) {
            _os.write(this.stepSmallImageUrl, 2);
        }
        if (this.stepLargeImageUrl != null) {
            _os.write(this.stepLargeImageUrl, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.stepNo = _is.read(this.stepNo, 0, false);
        this.stepContent = _is.readString(1, false);
        this.stepSmallImageUrl = _is.readString(2, false);
        this.stepLargeImageUrl = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        CCookStep temp = (CCookStep) a.parseObject(text, CCookStep.class);
        this.stepNo = temp.stepNo;
        this.stepContent = temp.stepContent;
        this.stepSmallImageUrl = temp.stepSmallImageUrl;
        this.stepLargeImageUrl = temp.stepLargeImageUrl;
    }
}
