package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public final class ComplexCommCardItem extends JceStruct {
    static ArrayList<Map<Integer, CardElement>> cache_vecContentElements = new ArrayList<>();
    public String strDestURL = "";
    public String strOptionValue = "";
    public ArrayList<Map<Integer, CardElement>> vecContentElements = null;

    public ComplexCommCardItem() {
    }

    public ComplexCommCardItem(String strDestURL2, ArrayList<Map<Integer, CardElement>> vecContentElements2, String strOptionValue2) {
        this.strDestURL = strDestURL2;
        this.vecContentElements = vecContentElements2;
        this.strOptionValue = strOptionValue2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strDestURL != null) {
            _os.write(this.strDestURL, 0);
        }
        if (this.vecContentElements != null) {
            _os.write((Collection) this.vecContentElements, 1);
        }
        if (this.strOptionValue != null) {
            _os.write(this.strOptionValue, 2);
        }
    }

    static {
        Map<Integer, CardElement> __var_8 = new HashMap<>();
        __var_8.put(0, new CardElement());
        cache_vecContentElements.add(__var_8);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strDestURL = _is.readString(0, false);
        this.vecContentElements = (ArrayList) _is.read((Object) cache_vecContentElements, 1, false);
        this.strOptionValue = _is.readString(2, false);
    }
}
