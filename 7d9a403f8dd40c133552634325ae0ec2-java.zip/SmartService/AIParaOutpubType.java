package SmartService;

import java.io.Serializable;

public final class AIParaOutpubType implements Serializable {
    public static final int _E_AIPARAOUTPUBTYPE_TEXT = 1;
    public static final int _E_AIPARAOUTPUBTYPE_VOICE_TTS = 0;
}
