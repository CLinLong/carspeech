package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class NewsDimensionUnit extends JceStruct {
    static int cache_field = 0;
    static ArrayList<String> cache_values = new ArrayList<>();
    public int field = 0;
    public ArrayList<String> values = null;

    public NewsDimensionUnit() {
    }

    public NewsDimensionUnit(int field2, ArrayList<String> values2) {
        this.field = field2;
        this.values = values2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.field, 0);
        _os.write((Collection) this.values, 1);
    }

    static {
        cache_values.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.field = _is.read(this.field, 0, true);
        this.values = (ArrayList) _is.read((Object) cache_values, 1, true);
    }
}
