package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SurroundSearchParams extends JceStruct {
    static SurroundLocation cache_location = new SurroundLocation();
    public int distance = 0;
    public int index = 1;
    public String keyword = "";
    public SurroundLocation location = null;
    public String locationType = "";
    public String position = "";
    public String region = "";
    public String userId = "";

    public SurroundSearchParams() {
    }

    public SurroundSearchParams(String keyword2, String region2, String position2, int distance2, String locationType2, SurroundLocation location2, int index2, String userId2) {
        this.keyword = keyword2;
        this.region = region2;
        this.position = position2;
        this.distance = distance2;
        this.locationType = locationType2;
        this.location = location2;
        this.index = index2;
        this.userId = userId2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.keyword != null) {
            _os.write(this.keyword, 0);
        }
        if (this.region != null) {
            _os.write(this.region, 1);
        }
        if (this.position != null) {
            _os.write(this.position, 2);
        }
        _os.write(this.distance, 3);
        _os.write(this.locationType, 4);
        if (this.location != null) {
            _os.write((JceStruct) this.location, 5);
        }
        _os.write(this.index, 6);
        if (this.userId != null) {
            _os.write(this.userId, 7);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.keyword = _is.readString(0, false);
        this.region = _is.readString(1, false);
        this.position = _is.readString(2, false);
        this.distance = _is.read(this.distance, 3, false);
        this.locationType = _is.readString(4, true);
        this.location = (SurroundLocation) _is.read((JceStruct) cache_location, 5, false);
        this.index = _is.read(this.index, 6, false);
        this.userId = _is.readString(7, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SurroundSearchParams temp = (SurroundSearchParams) a.parseObject(text, SurroundSearchParams.class);
        this.keyword = temp.keyword;
        this.region = temp.region;
        this.position = temp.position;
        this.distance = temp.distance;
        this.locationType = temp.locationType;
        this.location = temp.location;
        this.index = temp.index;
        this.userId = temp.userId;
    }
}
