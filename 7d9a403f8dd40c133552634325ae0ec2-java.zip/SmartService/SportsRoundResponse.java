package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SportsRoundResponse extends JceStruct {
    public String noSupport = "";
    public String replyWords = "";
    public String sGuid = "";
    public String speakerReplyWords = "";

    public SportsRoundResponse() {
    }

    public SportsRoundResponse(String sGuid2, String noSupport2, String replyWords2, String speakerReplyWords2) {
        this.sGuid = sGuid2;
        this.noSupport = noSupport2;
        this.replyWords = replyWords2;
        this.speakerReplyWords = speakerReplyWords2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sGuid, 0);
        if (this.noSupport != null) {
            _os.write(this.noSupport, 1);
        }
        if (this.replyWords != null) {
            _os.write(this.replyWords, 2);
        }
        if (this.speakerReplyWords != null) {
            _os.write(this.speakerReplyWords, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sGuid = _is.readString(0, true);
        this.noSupport = _is.readString(1, false);
        this.replyWords = _is.readString(2, false);
        this.speakerReplyWords = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SportsRoundResponse temp = (SportsRoundResponse) a.parseObject(text, SportsRoundResponse.class);
        this.sGuid = temp.sGuid;
        this.noSupport = temp.noSupport;
        this.replyWords = temp.replyWords;
        this.speakerReplyWords = temp.speakerReplyWords;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
