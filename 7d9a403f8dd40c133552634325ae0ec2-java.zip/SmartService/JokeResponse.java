package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class JokeResponse extends JceStruct {
    static int cache_eJokeStatus = 0;
    public int eJokeStatus = 0;
    public int hateScore = 0;
    public int iQuestionType = 0;
    public int iUserType = 0;
    public long jokeId = 0;
    public String jokeText = "";
    public String jokeUrl = "";
    public int likeScore = 0;
    public int picLength = 0;
    public int picWidth = 0;
    public int setUserScore = 0;
    public String strSpeakTipsText = "";
    public String strTipsText = "";
    public int userScore = 0;

    public JokeResponse() {
    }

    public JokeResponse(long jokeId2, String jokeText2, String jokeUrl2, int eJokeStatus2, int userScore2, int likeScore2, int hateScore2, int setUserScore2, int picLength2, int picWidth2, String strTipsText2, String strSpeakTipsText2, int iUserType2, int iQuestionType2) {
        this.jokeId = jokeId2;
        this.jokeText = jokeText2;
        this.jokeUrl = jokeUrl2;
        this.eJokeStatus = eJokeStatus2;
        this.userScore = userScore2;
        this.likeScore = likeScore2;
        this.hateScore = hateScore2;
        this.setUserScore = setUserScore2;
        this.picLength = picLength2;
        this.picWidth = picWidth2;
        this.strTipsText = strTipsText2;
        this.strSpeakTipsText = strSpeakTipsText2;
        this.iUserType = iUserType2;
        this.iQuestionType = iQuestionType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.jokeId, 0);
        _os.write(this.jokeText, 1);
        _os.write(this.jokeUrl, 2);
        _os.write(this.eJokeStatus, 3);
        _os.write(this.userScore, 4);
        _os.write(this.likeScore, 5);
        _os.write(this.hateScore, 6);
        _os.write(this.setUserScore, 7);
        _os.write(this.picLength, 8);
        _os.write(this.picWidth, 9);
        if (this.strTipsText != null) {
            _os.write(this.strTipsText, 10);
        }
        if (this.strSpeakTipsText != null) {
            _os.write(this.strSpeakTipsText, 11);
        }
        _os.write(this.iUserType, 12);
        _os.write(this.iQuestionType, 13);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.jokeId = _is.read(this.jokeId, 0, true);
        this.jokeText = _is.readString(1, true);
        this.jokeUrl = _is.readString(2, true);
        this.eJokeStatus = _is.read(this.eJokeStatus, 3, true);
        this.userScore = _is.read(this.userScore, 4, false);
        this.likeScore = _is.read(this.likeScore, 5, false);
        this.hateScore = _is.read(this.hateScore, 6, false);
        this.setUserScore = _is.read(this.setUserScore, 7, false);
        this.picLength = _is.read(this.picLength, 8, false);
        this.picWidth = _is.read(this.picWidth, 9, false);
        this.strTipsText = _is.readString(10, false);
        this.strSpeakTipsText = _is.readString(11, false);
        this.iUserType = _is.read(this.iUserType, 12, false);
        this.iQuestionType = _is.read(this.iQuestionType, 13, false);
    }
}
