package SmartService;

import java.io.Serializable;

public final class EnumJokeScore implements Serializable {
    public static final int _E_JOKE_CANCLE_HATE = 3;
    public static final int _E_JOKE_CANCLE_LIKE = 4;
    public static final int _E_JOKE_SCORE_H2L = 6;
    public static final int _E_JOKE_SCORE_HATE = 1;
    public static final int _E_JOKE_SCORE_L2H = 5;
    public static final int _E_JOKE_SCORE_LIKE = 2;
    public static final int _E_JOKE_SCORE_NONE = 0;
}
