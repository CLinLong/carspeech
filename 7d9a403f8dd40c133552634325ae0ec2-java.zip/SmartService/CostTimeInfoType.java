package SmartService;

import java.io.Serializable;

public final class CostTimeInfoType implements Serializable {
    public static final int _E_COSTTIMETYPE_AIPROXY = 1;
    public static final int _E_COSTTIMETYPE_SEMANTIC = 2;
    public static final int _E_COSTTIMETYPE_SERVER = 5;
    public static final int _E_COSTTIMETYPE_TTS = 4;
    public static final int _E_COSTTIMETYPE_VOICE = 3;
}
