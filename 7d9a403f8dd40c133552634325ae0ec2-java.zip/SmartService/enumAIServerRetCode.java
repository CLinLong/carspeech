package SmartService;

import java.io.Serializable;

public final class enumAIServerRetCode implements Serializable {
    public static final int _ENUM_AI_SERVER_RET_CODE_CUSTOM = 100;
    public static final int _ENUM_AI_SERVER_RET_CODE_DCACHE_FAILED = -3;
    public static final int _ENUM_AI_SERVER_RET_CODE_DEFAULT_ERROR = -1;
    public static final int _ENUM_AI_SERVER_RET_CODE_MDB_FAILED = -2;
    public static final int _ENUM_AI_SERVER_RET_CODE_NOT_FOUND = 1;
    public static final int _ENUM_AI_SERVER_RET_CODE_NOT_SUPPORT = 4;
    public static final int _ENUM_AI_SERVER_RET_CODE_OK = 0;
    public static final int _ENUM_AI_SERVER_RET_CODE_PARAM_FAILED = 3;
    public static final int _ENUM_AI_SERVER_RET_CODE_REQUIRE_LOGIN = 2;
    public static final int _ENUM_AI_SERVER_RET_CODE_RPC_FAILED = -100;
}
