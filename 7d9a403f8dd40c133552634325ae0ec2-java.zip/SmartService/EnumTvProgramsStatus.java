package SmartService;

import java.io.Serializable;

public final class EnumTvProgramsStatus implements Serializable {
    public static final int _RES_TVPROGRAMS_ERROR = -1;
    public static final int _RES_TVPROGRAMS_NO_CHANNEL = 101;
    public static final int _RES_TVPROGRAMS_NO_NAME = 102;
    public static final int _RES_TVPROGRAMS_OK = 0;
}
