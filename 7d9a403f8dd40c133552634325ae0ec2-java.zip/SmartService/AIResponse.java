package SmartService;

import SmartAssistant.Response;
import SmartAssistant.SemanticResponse;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class AIResponse extends JceStruct {
    static CommonRspData cache_sCommRspData = new CommonRspData();
    static ErrCodeStatus cache_sRet = new ErrCodeStatus();
    static Response cache_sSemanticRsp = new Response();
    static SemanticResponse cache_sSemanticRspData = new SemanticResponse();
    static AIVoiceResponse cache_sVoice2TextRsp = new AIVoiceResponse();
    static ArrayList<CostTimeInfo> cache_vecCostTime = new ArrayList<>();
    static byte[] cache_vecDomainRawData = new byte[1];
    static ArrayList<AIResponseDataItem> cache_vectResponseData = new ArrayList<>();
    public int iDataType = 0;
    public String jsonResponseData = "";
    public CommonRspData sCommRspData = null;
    public ErrCodeStatus sRet = null;
    public Response sSemanticRsp = null;
    public SemanticResponse sSemanticRspData = null;
    public AIVoiceResponse sVoice2TextRsp = null;
    public String strJsonToSemantic = "";
    public String strRequestText = "";
    public String strResponseText = "";
    public String strSpeakText = "";
    public String strSpeakTipsText = "";
    public String strTipsText = "";
    public ArrayList<CostTimeInfo> vecCostTime = null;
    public byte[] vecDomainRawData = null;
    public ArrayList<AIResponseDataItem> vectResponseData = null;

    public AIResponse() {
    }

    public AIResponse(ArrayList<AIResponseDataItem> vectResponseData2, String strResponseText2, String jsonResponseData2, Response sSemanticRsp2, int iDataType2, String strRequestText2, String strTipsText2, String strSpeakText2, SemanticResponse sSemanticRspData2, byte[] vecDomainRawData2, String strSpeakTipsText2, CommonRspData sCommRspData2, String strJsonToSemantic2, AIVoiceResponse sVoice2TextRsp2, ArrayList<CostTimeInfo> vecCostTime2, ErrCodeStatus sRet2) {
        this.vectResponseData = vectResponseData2;
        this.strResponseText = strResponseText2;
        this.jsonResponseData = jsonResponseData2;
        this.sSemanticRsp = sSemanticRsp2;
        this.iDataType = iDataType2;
        this.strRequestText = strRequestText2;
        this.strTipsText = strTipsText2;
        this.strSpeakText = strSpeakText2;
        this.sSemanticRspData = sSemanticRspData2;
        this.vecDomainRawData = vecDomainRawData2;
        this.strSpeakTipsText = strSpeakTipsText2;
        this.sCommRspData = sCommRspData2;
        this.strJsonToSemantic = strJsonToSemantic2;
        this.sVoice2TextRsp = sVoice2TextRsp2;
        this.vecCostTime = vecCostTime2;
        this.sRet = sRet2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vectResponseData, 0);
        if (this.strResponseText != null) {
            _os.write(this.strResponseText, 1);
        }
        if (this.jsonResponseData != null) {
            _os.write(this.jsonResponseData, 2);
        }
        if (this.sSemanticRsp != null) {
            _os.write((JceStruct) this.sSemanticRsp, 3);
        }
        _os.write(this.iDataType, 4);
        if (this.strRequestText != null) {
            _os.write(this.strRequestText, 5);
        }
        if (this.strTipsText != null) {
            _os.write(this.strTipsText, 6);
        }
        if (this.strSpeakText != null) {
            _os.write(this.strSpeakText, 7);
        }
        if (this.sSemanticRspData != null) {
            _os.write((JceStruct) this.sSemanticRspData, 8);
        }
        if (this.vecDomainRawData != null) {
            _os.write(this.vecDomainRawData, 9);
        }
        if (this.strSpeakTipsText != null) {
            _os.write(this.strSpeakTipsText, 10);
        }
        if (this.sCommRspData != null) {
            _os.write((JceStruct) this.sCommRspData, 11);
        }
        if (this.strJsonToSemantic != null) {
            _os.write(this.strJsonToSemantic, 12);
        }
        if (this.sVoice2TextRsp != null) {
            _os.write((JceStruct) this.sVoice2TextRsp, 13);
        }
        if (this.vecCostTime != null) {
            _os.write((Collection) this.vecCostTime, 14);
        }
        if (this.sRet != null) {
            _os.write((JceStruct) this.sRet, 15);
        }
    }

    static {
        cache_vectResponseData.add(new AIResponseDataItem());
        cache_vecDomainRawData[0] = 0;
        cache_vecCostTime.add(new CostTimeInfo());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vectResponseData = (ArrayList) _is.read((Object) cache_vectResponseData, 0, true);
        this.strResponseText = _is.readString(1, false);
        this.jsonResponseData = _is.readString(2, false);
        this.sSemanticRsp = (Response) _is.read((JceStruct) cache_sSemanticRsp, 3, false);
        this.iDataType = _is.read(this.iDataType, 4, false);
        this.strRequestText = _is.readString(5, false);
        this.strTipsText = _is.readString(6, false);
        this.strSpeakText = _is.readString(7, false);
        this.sSemanticRspData = (SemanticResponse) _is.read((JceStruct) cache_sSemanticRspData, 8, false);
        this.vecDomainRawData = _is.read(cache_vecDomainRawData, 9, false);
        this.strSpeakTipsText = _is.readString(10, false);
        this.sCommRspData = (CommonRspData) _is.read((JceStruct) cache_sCommRspData, 11, false);
        this.strJsonToSemantic = _is.readString(12, false);
        this.sVoice2TextRsp = (AIVoiceResponse) _is.read((JceStruct) cache_sVoice2TextRsp, 13, false);
        this.vecCostTime = (ArrayList) _is.read((Object) cache_vecCostTime, 14, false);
        this.sRet = (ErrCodeStatus) _is.read((JceStruct) cache_sRet, 15, false);
    }
}
