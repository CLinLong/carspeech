package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class CRecipeDataResponse extends JceStruct {
    static ArrayList<CRecipeData> cache_dataVec = new ArrayList<>();
    public ArrayList<CRecipeData> dataVec = null;
    public int pageSize = 0;
    public String strMoreUrl = "";

    public CRecipeDataResponse() {
    }

    public CRecipeDataResponse(ArrayList<CRecipeData> dataVec2, String strMoreUrl2, int pageSize2) {
        this.dataVec = dataVec2;
        this.strMoreUrl = strMoreUrl2;
        this.pageSize = pageSize2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.dataVec != null) {
            _os.write((Collection) this.dataVec, 0);
        }
        if (this.strMoreUrl != null) {
            _os.write(this.strMoreUrl, 1);
        }
        _os.write(this.pageSize, 2);
    }

    static {
        cache_dataVec.add(new CRecipeData());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.dataVec = (ArrayList) _is.read((Object) cache_dataVec, 0, false);
        this.strMoreUrl = _is.readString(1, false);
        this.pageSize = _is.read(this.pageSize, 2, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        CRecipeDataResponse temp = (CRecipeDataResponse) a.parseObject(text, CRecipeDataResponse.class);
        this.dataVec = temp.dataVec;
        this.strMoreUrl = temp.strMoreUrl;
        this.pageSize = temp.pageSize;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
