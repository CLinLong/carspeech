package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class SurroundSpotInfo extends JceStruct {
    static SurroundLocation cache_location = new SurroundLocation();
    public String addr = "";
    public String category = "";
    public String detailUrl = "";
    public int distance = 0;
    public SurroundLocation location = null;
    public String naviUrl = "";
    public String tel = "";
    public String title = "";
    public int type = 0;

    public SurroundSpotInfo() {
    }

    public SurroundSpotInfo(String title2, String addr2, String tel2, String category2, int type2, SurroundLocation location2, int distance2, String detailUrl2, String naviUrl2) {
        this.title = title2;
        this.addr = addr2;
        this.tel = tel2;
        this.category = category2;
        this.type = type2;
        this.location = location2;
        this.distance = distance2;
        this.detailUrl = detailUrl2;
        this.naviUrl = naviUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.title, 0);
        _os.write(this.addr, 1);
        if (this.tel != null) {
            _os.write(this.tel, 2);
        }
        _os.write(this.category, 3);
        _os.write(this.type, 4);
        _os.write((JceStruct) this.location, 5);
        _os.write(this.distance, 6);
        if (this.detailUrl != null) {
            _os.write(this.detailUrl, 7);
        }
        if (this.naviUrl != null) {
            _os.write(this.naviUrl, 8);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.title = _is.readString(0, true);
        this.addr = _is.readString(1, true);
        this.tel = _is.readString(2, false);
        this.category = _is.readString(3, true);
        this.type = _is.read(this.type, 4, true);
        this.location = (SurroundLocation) _is.read((JceStruct) cache_location, 5, true);
        this.distance = _is.read(this.distance, 6, true);
        this.detailUrl = _is.readString(7, false);
        this.naviUrl = _is.readString(8, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        SurroundSpotInfo temp = (SurroundSpotInfo) a.parseObject(text, SurroundSpotInfo.class);
        this.title = temp.title;
        this.addr = temp.addr;
        this.tel = temp.tel;
        this.category = temp.category;
        this.type = temp.type;
        this.location = temp.location;
        this.distance = temp.distance;
        this.detailUrl = temp.detailUrl;
        this.naviUrl = temp.naviUrl;
    }
}
