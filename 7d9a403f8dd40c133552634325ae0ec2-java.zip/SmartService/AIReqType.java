package SmartService;

import java.io.Serializable;

public final class AIReqType implements Serializable {
    public static final int _E_AIREQTYPE_CONTINUOUS_END = 3;
    public static final int _E_AIREQTYPE_CONTINUOUS_ING = 2;
    public static final int _E_AIREQTYPE_CONTINUOUS_START = 1;
    public static final int _E_AIREQTYPE_NORMAL = 0;
    public static final int _E_AIREQTYPE_TTS = 4;
}
