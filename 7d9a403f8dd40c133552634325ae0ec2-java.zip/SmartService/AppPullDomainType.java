package SmartService;

import java.io.Serializable;

public final class AppPullDomainType implements Serializable {
    public static final int _EUnknownPullDomainType = -1;
    public static final int _E_ADVERTISEMENT = 9;
    public static final int _E_ALL_DOMAIN = 0;
    public static final int _E_FM_RECOMMEND = 4;
    public static final int _E_MEDIA_PLAYER = 2;
    public static final int _E_MUSIC_RECOMMEND = 1;
    public static final int _E_NEWS = 8;
    public static final int _E_PAYMENT = 5;
    public static final int _E_REMIND = 7;
    public static final int _E_TAXI = 6;
    public static final int _E_WEATHER = 3;
}
