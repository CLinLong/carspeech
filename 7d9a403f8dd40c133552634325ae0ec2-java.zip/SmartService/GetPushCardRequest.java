package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class GetPushCardRequest extends JceStruct {
    static AIAccountBaseInfo cache_sAccountBaseInfo = new AIAccountBaseInfo();
    static ArrayList<String> cache_strIdVec = new ArrayList<>();
    public AIAccountBaseInfo sAccountBaseInfo = null;
    public ArrayList<String> strIdVec = null;

    public GetPushCardRequest() {
    }

    public GetPushCardRequest(AIAccountBaseInfo sAccountBaseInfo2, ArrayList<String> strIdVec2) {
        this.sAccountBaseInfo = sAccountBaseInfo2;
        this.strIdVec = strIdVec2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sAccountBaseInfo != null) {
            _os.write((JceStruct) this.sAccountBaseInfo, 0);
        }
        if (this.strIdVec != null) {
            _os.write((Collection) this.strIdVec, 1);
        }
    }

    static {
        cache_strIdVec.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAccountBaseInfo = (AIAccountBaseInfo) _is.read((JceStruct) cache_sAccountBaseInfo, 0, false);
        this.strIdVec = (ArrayList) _is.read((Object) cache_strIdVec, 1, false);
    }
}
