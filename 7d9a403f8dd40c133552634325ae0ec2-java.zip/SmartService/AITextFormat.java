package SmartService;

import java.io.Serializable;

public final class AITextFormat implements Serializable {
    public static final int _E_AITextFormat_GBK = 0;
    public static final int _E_AITextFormat_UTF8 = 1;
}
