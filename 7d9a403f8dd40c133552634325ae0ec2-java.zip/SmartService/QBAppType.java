package SmartService;

import java.io.Serializable;

public final class QBAppType implements Serializable {
    public static final int _E_QBAPPTYPE_H5GAME = 1;
    public static final int _E_QBAPPTYPE_NATIVE = 0;
}
