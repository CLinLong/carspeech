package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIParseContent extends JceStruct {
    static AIASRResponse cache_sASRRes = new AIASRResponse();
    public AIASRResponse sASRRes = null;
    public String strSessionId = "";

    public AIParseContent() {
    }

    public AIParseContent(String strSessionId2, AIASRResponse sASRRes2) {
        this.strSessionId = strSessionId2;
        this.sASRRes = sASRRes2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strSessionId != null) {
            _os.write(this.strSessionId, 0);
        }
        if (this.sASRRes != null) {
            _os.write((JceStruct) this.sASRRes, 1);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strSessionId = _is.readString(0, false);
        this.sASRRes = (AIASRResponse) _is.read((JceStruct) cache_sASRRes, 1, false);
    }
}
