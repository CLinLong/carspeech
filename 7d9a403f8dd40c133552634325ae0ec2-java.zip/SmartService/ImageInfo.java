package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ImageInfo extends JceStruct {
    public boolean bCorner = true;
    public int nHight = 0;
    public int nRadius = 0;
    public int nWidth = 0;
    public String strImageUrl = "";

    public ImageInfo() {
    }

    public ImageInfo(String strImageUrl2, int nHight2, int nWidth2, int nRadius2, boolean bCorner2) {
        this.strImageUrl = strImageUrl2;
        this.nHight = nHight2;
        this.nWidth = nWidth2;
        this.nRadius = nRadius2;
        this.bCorner = bCorner2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strImageUrl != null) {
            _os.write(this.strImageUrl, 0);
        }
        _os.write(this.nHight, 1);
        _os.write(this.nWidth, 2);
        _os.write(this.nRadius, 3);
        _os.write(this.bCorner, 4);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strImageUrl = _is.readString(0, false);
        this.nHight = _is.read(this.nHight, 1, false);
        this.nWidth = _is.read(this.nWidth, 2, false);
        this.nRadius = _is.read(this.nRadius, 3, false);
        this.bCorner = _is.read(this.bCorner, 4, false);
    }
}
