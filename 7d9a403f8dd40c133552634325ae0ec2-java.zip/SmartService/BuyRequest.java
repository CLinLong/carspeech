package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.HashMap;
import java.util.Map;

public final class BuyRequest extends JceStruct {
    static Map<String, String> cache_data_slot = new HashMap();
    static AIAccountBaseInfo cache_sAccountBaseInfo = new AIAccountBaseInfo();
    static AIDeviceBaseInfo cache_sDeviceBaseInfo = new AIDeviceBaseInfo();
    public Map<String, String> data_slot = null;
    public AIAccountBaseInfo sAccountBaseInfo = null;
    public AIDeviceBaseInfo sDeviceBaseInfo = null;
    public String strDomain = "";
    public String strIntent = "";
    public String strOperType = "";

    public BuyRequest() {
    }

    public BuyRequest(AIAccountBaseInfo sAccountBaseInfo2, AIDeviceBaseInfo sDeviceBaseInfo2, String strDomain2, String strIntent2, String strOperType2, Map<String, String> data_slot2) {
        this.sAccountBaseInfo = sAccountBaseInfo2;
        this.sDeviceBaseInfo = sDeviceBaseInfo2;
        this.strDomain = strDomain2;
        this.strIntent = strIntent2;
        this.strOperType = strOperType2;
        this.data_slot = data_slot2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sAccountBaseInfo != null) {
            _os.write((JceStruct) this.sAccountBaseInfo, 0);
        }
        if (this.sDeviceBaseInfo != null) {
            _os.write((JceStruct) this.sDeviceBaseInfo, 1);
        }
        if (this.strDomain != null) {
            _os.write(this.strDomain, 2);
        }
        if (this.strIntent != null) {
            _os.write(this.strIntent, 3);
        }
        if (this.strOperType != null) {
            _os.write(this.strOperType, 4);
        }
        if (this.data_slot != null) {
            _os.write((Map) this.data_slot, 5);
        }
    }

    static {
        cache_data_slot.put("", "");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sAccountBaseInfo = (AIAccountBaseInfo) _is.read((JceStruct) cache_sAccountBaseInfo, 0, false);
        this.sDeviceBaseInfo = (AIDeviceBaseInfo) _is.read((JceStruct) cache_sDeviceBaseInfo, 1, false);
        this.strDomain = _is.readString(2, false);
        this.strIntent = _is.readString(3, false);
        this.strOperType = _is.readString(4, false);
        this.data_slot = (Map) _is.read((Object) cache_data_slot, 5, false);
    }
}
