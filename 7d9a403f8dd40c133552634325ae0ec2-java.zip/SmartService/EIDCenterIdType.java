package SmartService;

import java.io.Serializable;

public final class EIDCenterIdType implements Serializable {
    public static final int _IDCENTER_ID_DV = 3;
    public static final int _IDCENTER_ID_QQ = 1;
    public static final int _IDCENTER_ID_QQOPEN = 4;
    public static final int _IDCENTER_ID_WX = 2;
}
