package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIVoiceRequest extends JceStruct {
    static AIVoiceUserInfo cache_sUserInfo = new AIVoiceUserInfo();
    static AIVoiceMeta cache_sVoiceMeta = new AIVoiceMeta();
    static byte[] cache_vecVoiceData = new byte[1];
    public int iOrder = 0;
    public int iReqType = 0;
    public AIVoiceUserInfo sUserInfo = null;
    public AIVoiceMeta sVoiceMeta = null;
    public String strGUID = "";
    public String strQUA = "";
    public String strSessionId = "";
    public byte[] vecVoiceData = null;

    public AIVoiceRequest() {
    }

    public AIVoiceRequest(byte[] vecVoiceData2, String strQUA2, String strGUID2, int iReqType2, int iOrder2, AIVoiceMeta sVoiceMeta2, String strSessionId2, AIVoiceUserInfo sUserInfo2) {
        this.vecVoiceData = vecVoiceData2;
        this.strQUA = strQUA2;
        this.strGUID = strGUID2;
        this.iReqType = iReqType2;
        this.iOrder = iOrder2;
        this.sVoiceMeta = sVoiceMeta2;
        this.strSessionId = strSessionId2;
        this.sUserInfo = sUserInfo2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.vecVoiceData, 0);
        if (this.strQUA != null) {
            _os.write(this.strQUA, 1);
        }
        if (this.strGUID != null) {
            _os.write(this.strGUID, 2);
        }
        _os.write(this.iReqType, 3);
        _os.write(this.iOrder, 4);
        if (this.sVoiceMeta != null) {
            _os.write((JceStruct) this.sVoiceMeta, 5);
        }
        if (this.strSessionId != null) {
            _os.write(this.strSessionId, 6);
        }
        if (this.sUserInfo != null) {
            _os.write((JceStruct) this.sUserInfo, 7);
        }
    }

    static {
        cache_vecVoiceData[0] = 0;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecVoiceData = _is.read(cache_vecVoiceData, 0, true);
        this.strQUA = _is.readString(1, false);
        this.strGUID = _is.readString(2, false);
        this.iReqType = _is.read(this.iReqType, 3, false);
        this.iOrder = _is.read(this.iOrder, 4, false);
        this.sVoiceMeta = (AIVoiceMeta) _is.read((JceStruct) cache_sVoiceMeta, 5, false);
        this.strSessionId = _is.readString(6, false);
        this.sUserInfo = (AIVoiceUserInfo) _is.read((JceStruct) cache_sUserInfo, 7, false);
    }
}
