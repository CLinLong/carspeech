package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class IDCenterTokenStruct extends JceStruct {
    public String sAppID = "";
    public String sOpenID = "";
    public String sToken = "";

    public IDCenterTokenStruct() {
    }

    public IDCenterTokenStruct(String sToken2, String sAppID2, String sOpenID2) {
        this.sToken = sToken2;
        this.sAppID = sAppID2;
        this.sOpenID = sOpenID2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sToken, 0);
        if (this.sAppID != null) {
            _os.write(this.sAppID, 1);
        }
        if (this.sOpenID != null) {
            _os.write(this.sOpenID, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sToken = _is.readString(0, true);
        this.sAppID = _is.readString(1, false);
        this.sOpenID = _is.readString(2, false);
    }
}
