package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class DirectSearchData extends JceStruct {
    public String sDescribeInfo = "";
    public String sDstURL = "";
    public String sIconURL = "";
    public String sTitle = "";

    public DirectSearchData() {
    }

    public DirectSearchData(String sIconURL2, String sTitle2, String sDescribeInfo2, String sDstURL2) {
        this.sIconURL = sIconURL2;
        this.sTitle = sTitle2;
        this.sDescribeInfo = sDescribeInfo2;
        this.sDstURL = sDstURL2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.sIconURL != null) {
            _os.write(this.sIconURL, 0);
        }
        if (this.sTitle != null) {
            _os.write(this.sTitle, 1);
        }
        if (this.sDescribeInfo != null) {
            _os.write(this.sDescribeInfo, 2);
        }
        if (this.sDstURL != null) {
            _os.write(this.sDstURL, 3);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sIconURL = _is.readString(0, false);
        this.sTitle = _is.readString(1, false);
        this.sDescribeInfo = _is.readString(2, false);
        this.sDstURL = _is.readString(3, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        DirectSearchData temp = (DirectSearchData) a.parseObject(text, DirectSearchData.class);
        this.sIconURL = temp.sIconURL;
        this.sTitle = temp.sTitle;
        this.sDescribeInfo = temp.sDescribeInfo;
        this.sDstURL = temp.sDstURL;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
