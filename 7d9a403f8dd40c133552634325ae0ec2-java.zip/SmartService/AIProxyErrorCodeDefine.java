package SmartService;

import java.io.Serializable;

public final class AIProxyErrorCodeDefine implements Serializable {
    public static final int _E_AIPROXYERRORCODEDEFINE_PARA_ERROR = 101;
    public static final int _E_AIPROXYERRORCODEDEFINE_SUCC = 0;
}
