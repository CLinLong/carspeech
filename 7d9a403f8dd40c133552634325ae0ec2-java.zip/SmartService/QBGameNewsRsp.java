package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class QBGameNewsRsp extends JceStruct {
    static ArrayList<QBGameNewsItem> cache_vecGameNews = new ArrayList<>();
    public String strMoreUrl = "";
    public ArrayList<QBGameNewsItem> vecGameNews = null;

    public QBGameNewsRsp() {
    }

    public QBGameNewsRsp(ArrayList<QBGameNewsItem> vecGameNews2, String strMoreUrl2) {
        this.vecGameNews = vecGameNews2;
        this.strMoreUrl = strMoreUrl2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.vecGameNews, 0);
        if (this.strMoreUrl != null) {
            _os.write(this.strMoreUrl, 1);
        }
    }

    static {
        cache_vecGameNews.add(new QBGameNewsItem());
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.vecGameNews = (ArrayList) _is.read((Object) cache_vecGameNews, 0, true);
        this.strMoreUrl = _is.readString(1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        QBGameNewsRsp temp = (QBGameNewsRsp) a.parseObject(text, QBGameNewsRsp.class);
        this.vecGameNews = temp.vecGameNews;
        this.strMoreUrl = temp.strMoreUrl;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
