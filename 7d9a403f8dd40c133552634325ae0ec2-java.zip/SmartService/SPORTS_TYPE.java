package SmartService;

import java.io.Serializable;

public final class SPORTS_TYPE implements Serializable {
    public static final int _SPORTS_FOOTBALL = 2;
    public static final int _SPORTS_NBA = 1;
}
