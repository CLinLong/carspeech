package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class ErrCodeStatus extends JceStruct {
    public int iModuleId = 0;
    public int iRet = 0;
    public String strMsg = "";

    public ErrCodeStatus() {
    }

    public ErrCodeStatus(int iRet2, int iModuleId2, String strMsg2) {
        this.iRet = iRet2;
        this.iModuleId = iModuleId2;
        this.strMsg = strMsg2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.iRet, 0);
        _os.write(this.iModuleId, 1);
        if (this.strMsg != null) {
            _os.write(this.strMsg, 2);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.iRet = _is.read(this.iRet, 0, false);
        this.iModuleId = _is.read(this.iModuleId, 1, false);
        this.strMsg = _is.readString(2, false);
    }
}
