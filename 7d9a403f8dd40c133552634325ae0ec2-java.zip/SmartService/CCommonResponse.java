package SmartService;

import com.qq.component.json.JSONException;
import com.qq.component.json.a;
import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;
import java.util.ArrayList;
import java.util.Collection;

public final class CCommonResponse extends JceStruct {
    static ArrayList<String> cache_strReservedVec = new ArrayList<>();
    static ArrayList<String> cache_strResponseVec = new ArrayList<>();
    public ArrayList<String> strReservedVec = null;
    public ArrayList<String> strResponseVec = null;

    public CCommonResponse() {
    }

    public CCommonResponse(ArrayList<String> strResponseVec2, ArrayList<String> strReservedVec2) {
        this.strResponseVec = strResponseVec2;
        this.strReservedVec = strReservedVec2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write((Collection) this.strResponseVec, 0);
        if (this.strReservedVec != null) {
            _os.write((Collection) this.strReservedVec, 1);
        }
    }

    static {
        cache_strResponseVec.add("");
        cache_strReservedVec.add("");
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strResponseVec = (ArrayList) _is.read((Object) cache_strResponseVec, 0, true);
        this.strReservedVec = (ArrayList) _is.read((Object) cache_strReservedVec, 1, false);
    }

    public String writeToJsonString() throws JSONException {
        return a.toJSONString(this);
    }

    public void readFromJsonString(String text) throws JSONException {
        CCommonResponse temp = (CCommonResponse) a.parseObject(text, CCommonResponse.class);
        this.strResponseVec = temp.strResponseVec;
        this.strReservedVec = temp.strReservedVec;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void display(StringBuilder sb, int level) {
        sb.append(writeToJsonString());
    }
}
