package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class IDCenterIdStruct extends JceStruct {
    static int cache_eType = 0;
    public int eType = 0;
    public String sId = "";

    public IDCenterIdStruct() {
    }

    public IDCenterIdStruct(String sId2, int eType2) {
        this.sId = sId2;
        this.eType = eType2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        _os.write(this.sId, 0);
        _os.write(this.eType, 1);
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.sId = _is.readString(0, true);
        this.eType = _is.read(this.eType, 1, true);
    }
}
