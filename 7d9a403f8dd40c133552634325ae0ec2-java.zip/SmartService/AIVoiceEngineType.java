package SmartService;

import java.io.Serializable;

public final class AIVoiceEngineType implements Serializable {
    public static final int _E_AIVOICEENGINETYPE_BAIDU = 1;
    public static final int _E_AIVOICEENGINETYPE_BETA = 5;
    public static final int _E_AIVOICEENGINETYPE_IFLY = 3;
    public static final int _E_AIVOICEENGINETYPE_NONE = 0;
    public static final int _E_AIVOICEENGINETYPE_WX = 2;
    public static final int _E_AIVOICEENGINETYPE_YIYA = 4;
}
