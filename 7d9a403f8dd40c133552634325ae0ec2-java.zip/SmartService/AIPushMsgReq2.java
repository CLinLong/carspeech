package SmartService;

import com.tencent.ai.dobby.x.taf.JceInputStream;
import com.tencent.ai.dobby.x.taf.JceOutputStream;
import com.tencent.ai.dobby.x.taf.JceStruct;

public final class AIPushMsgReq2 extends JceStruct {
    static int cache_eDstAcctType = 0;
    static int cache_eDstPushIdType = 0;
    public int eDstAcctType = 0;
    public int eDstPushIdType = 0;
    public String strDomain = "";
    public String strDstAcctAppId = "";
    public String strDstPushIdExtra = "";
    public String strIntent = "";
    public String strMessage = "";
    public String strMsgType = "";
    public String strPushInfo = "";

    public AIPushMsgReq2() {
    }

    public AIPushMsgReq2(String strPushInfo2, int eDstAcctType2, String strDstAcctAppId2, int eDstPushIdType2, String strDstPushIdExtra2, String strDomain2, String strIntent2, String strMsgType2, String strMessage2) {
        this.strPushInfo = strPushInfo2;
        this.eDstAcctType = eDstAcctType2;
        this.strDstAcctAppId = strDstAcctAppId2;
        this.eDstPushIdType = eDstPushIdType2;
        this.strDstPushIdExtra = strDstPushIdExtra2;
        this.strDomain = strDomain2;
        this.strIntent = strIntent2;
        this.strMsgType = strMsgType2;
        this.strMessage = strMessage2;
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void writeTo(JceOutputStream _os) {
        if (this.strPushInfo != null) {
            _os.write(this.strPushInfo, 0);
        }
        _os.write(this.eDstAcctType, 1);
        if (this.strDstAcctAppId != null) {
            _os.write(this.strDstAcctAppId, 2);
        }
        _os.write(this.eDstPushIdType, 3);
        if (this.strDstPushIdExtra != null) {
            _os.write(this.strDstPushIdExtra, 4);
        }
        if (this.strDomain != null) {
            _os.write(this.strDomain, 5);
        }
        if (this.strIntent != null) {
            _os.write(this.strIntent, 6);
        }
        if (this.strMsgType != null) {
            _os.write(this.strMsgType, 7);
        }
        if (this.strMessage != null) {
            _os.write(this.strMessage, 8);
        }
    }

    @Override // com.tencent.ai.dobby.x.taf.JceStruct
    public void readFrom(JceInputStream _is) {
        this.strPushInfo = _is.readString(0, false);
        this.eDstAcctType = _is.read(this.eDstAcctType, 1, false);
        this.strDstAcctAppId = _is.readString(2, false);
        this.eDstPushIdType = _is.read(this.eDstPushIdType, 3, false);
        this.strDstPushIdExtra = _is.readString(4, false);
        this.strDomain = _is.readString(5, false);
        this.strIntent = _is.readString(6, false);
        this.strMsgType = _is.readString(7, false);
        this.strMessage = _is.readString(8, false);
    }
}
