package SmartService;

import java.io.Serializable;

public final class ElementType implements Serializable {
    public static final int _E_ELEMENTTYPE_ADDRESS = 2;
    public static final int _E_ELEMENTTYPE_BUTTON = 3;
    public static final int _E_ELEMENTTYPE_ICON = 5;
    public static final int _E_ELEMENTTYPE_PHONE = 1;
    public static final int _E_ELEMENTTYPE_STAR = 0;
    public static final int _E_ELEMENTTYPE_TEXT1 = 100;
    public static final int _E_ELEMENTTYPE_TEXT2 = 101;
    public static final int _E_ELEMENTTYPE_TEXT3 = 102;
    public static final int _E_ELEMENTTYPE_TEXT4 = 103;
    public static final int _E_ELEMENTTYPE_UPDOWN = 4;
}
