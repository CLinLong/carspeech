package SmartService;

import java.io.Serializable;

public final class NEWS_CLIENT_TYPE implements Serializable {
    public static final int _APP = 3;
    public static final int _SPKEARS = 2;
    public static final int _WEIXIN = 1;
}
